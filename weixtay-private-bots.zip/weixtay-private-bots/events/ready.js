const { ActivityType, EmbedBuilder } = require('discord.js');
const { joinVoiceChannel } = require('@discordjs/voice');
const config = require('../config');
const Invite = require('../models/Invite');
const Settings = require('../models/Settings');

// Jail çıkarma fonksiyonu
async function releaseJailUser(client, userId, guildId, settings) {
    try {
        const guild = client.guilds.cache.get(guildId);
        const user = guild.members.cache.get(userId);
        
        if (!user) return;

        // Jail kaydını bul ve güncelle
        const Jail = require('../models/Jail');
        const jailRecord = await Jail.findOne({
            userId: userId,
            guildId: guildId,
            isReleased: false
        });

        if (!jailRecord) return;

        // Yetkili olmayan rolleri geri ver
        const rolesToAdd = jailRecord.roles.filter(roleId => 
            !jailRecord.adminRoles.includes(roleId)
        );
        await user.roles.add(rolesToAdd);
        await user.roles.remove(settings.jailRole);

        // Jail kaydını güncelle
        jailRecord.isReleased = true;
        await jailRecord.save();

        // Log mesajı
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'jail-log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('Kullanıcı Jail\'den Çıkarıldı')
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: 'Kullanıcı', value: `${user.user.tag} (${user.id})`, inline: true },
                    { name: 'Sebep', value: 'Süre Doldu', inline: true }
                )
                .setFooter({ text: 'Jail Sistemi' });

            await logChannel.send({ embeds: [logEmbed] });
        }
    } catch (error) {
        console.error('Jail çıkarma hatası:', error);
    }
}

// Chat mute kaldır fonksiyonu
async function unmuteChatUser(client, userId, guildId, settings) {
    try {
        const guild = client.guilds.cache.get(guildId);
        const user = guild.members.cache.get(userId);
        
        if (!user) return;

        // Chat mute kaydını güncelle
        const ChatMute = require('../models/ChatMute');
        await ChatMute.findOneAndUpdate(
            { guildId, userId, isActive: true },
            { isActive: false }
        );

        // Chat mute kaldır
        if (settings.muteRole && user.roles.cache.has(settings.muteRole)) {
            await user.roles.remove(settings.muteRole, 'Chat mute süresi doldu');
        }

        // Log gönder
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'mute-log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setTitle('✅ Chat Mute Kaldırıldı')
                .setDescription(`${user} kullanıcısının chat mute süresi doldu`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                    { name: '⏰ Mute Türü', value: 'Chat', inline: true }
                )
                .setColor(0x00ff00)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    } catch (error) {
        console.error('Chat unmute hatası:', error);
    }
}

// Voice mute kaldır fonksiyonu
async function unmuteVoiceUser(client, userId, guildId, settings) {
    try {
        const guild = client.guilds.cache.get(guildId);
        const user = guild.members.cache.get(userId);
        
        if (!user) return;

        // Voice mute kaydını güncelle
        const VoiceMute = require('../models/VoiceMute');
        await VoiceMute.findOneAndUpdate(
            { guildId, userId, isActive: true },
            { isActive: false }
        );

        // Voice mute kaldır
        if (user.voice.channel) {
            await user.voice.setMute(false, 'Voice mute süresi doldu');
        }

        // Log gönder
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'mute-log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setTitle('✅ Voice Mute Kaldırıldı')
                .setDescription(`${user} kullanıcısının voice mute süresi doldu`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                    { name: '⏰ Mute Türü', value: 'Voice', inline: true }
                )
                .setColor(0x00ff00)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    } catch (error) {
        console.error('Voice unmute hatası:', error);
    }
}

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`${client.user.tag} olarak giriş yapıldı!`);
        
        client.user.setPresence({
            activities: [{ name: config.botStatus, type: ActivityType.Playing }],
            status: 'online'
        });

        const channel = await client.channels.fetch(config.voiceChannelId).catch(() => null);
        if (channel) {
            try {
                const connection = joinVoiceChannel({
                    channelId: channel.id,
                    guildId: channel.guild.id,
                    adapterCreator: channel.guild.voiceAdapterCreator,
                });
                console.log('Ses kanalına bağlanıldı!');
            } catch (error) {
                console.error('Ses kanalına bağlanırken hata:', error);
            }
        }

        // Davet takibi için mevcut davetleri yükle
        try {
            for (const guild of client.guilds.cache.values()) {
                const invites = await guild.invites.fetch();
                for (const [code, invite] of invites) {
                    // Mevcut daveti kontrol et
                    const existingInvite = await Invite.findOne({ guildId: guild.id, code: code });
                    if (!existingInvite) {
                        // Yeni davet, kaydet
                        const newInvite = new Invite({
                            guildId: guild.id,
                            code: code,
                            inviterId: invite.inviter.id,
                            uses: invite.uses,
                            maxUses: invite.maxUses,
                            expiresAt: invite.expiresAt,
                            isTemporary: invite.temporary
                        });
                        await newInvite.save();
                    } else {
                        // Mevcut daveti güncelle
                        existingInvite.uses = invite.uses;
                        existingInvite.maxUses = invite.maxUses;
                        existingInvite.expiresAt = invite.expiresAt;
                        existingInvite.isTemporary = invite.temporary;
                        await existingInvite.save();
                    }
                }
            }
            console.log('Davet takibi başlatıldı!');
        } catch (error) {
            console.error('Davet takibi başlatılırken hata:', error);
        }

        // Chat mute takibi için mevcut chat mute'ları kontrol et
        try {
            const ChatMute = require('../models/ChatMute');
            const Settings = require('../models/Settings');
            
            for (const guild of client.guilds.cache.values()) {
                const activeChatMutes = await ChatMute.find({ guildId: guild.id, isActive: true });
                const settings = await Settings.findOne({ id: guild.id });
                
                for (const mute of activeChatMutes) {
                    const now = new Date();
                    if (mute.endTime <= now) {
                        // Süresi dolmuş chat mute'u kaldır
                        mute.isActive = false;
                        await mute.save();
                        
                        const user = guild.members.cache.get(mute.userId);
                        if (user && settings.muteRole && user.roles.cache.has(settings.muteRole)) {
                            await user.roles.remove(settings.muteRole, 'Chat mute süresi doldu');
                        }
                    } else {
                        // Süresi dolmamış chat mute için timeout ayarla
                        const remainingTime = mute.endTime.getTime() - now.getTime();
                        setTimeout(async () => {
                            const currentMute = await ChatMute.findOne({ _id: mute._id, isActive: true });
                            if (currentMute) {
                                await unmuteChatUser(client, mute.userId, guild.id, settings);
                            }
                        }, remainingTime);
                    }
                }
            }
            console.log('Chat mute takibi başlatıldı!');
        } catch (error) {
            console.error('Chat mute takibi başlatılırken hata:', error);
        }

        // Voice mute takibi için mevcut voice mute'ları kontrol et
        try {
            const VoiceMute = require('../models/VoiceMute');
            const Settings = require('../models/Settings');
            
            for (const guild of client.guilds.cache.values()) {
                const activeVoiceMutes = await VoiceMute.find({ guildId: guild.id, isActive: true });
                const settings = await Settings.findOne({ id: guild.id });
                
                for (const mute of activeVoiceMutes) {
                    const now = new Date();
                    if (mute.endTime <= now) {
                        // Süresi dolmuş voice mute'u kaldır
                        mute.isActive = false;
                        await mute.save();
                        
                        const user = guild.members.cache.get(mute.userId);
                        if (user && settings.voiceMuteRole && user.roles.cache.has(settings.voiceMuteRole)) {
                            await user.roles.remove(settings.voiceMuteRole, 'Voice mute süresi doldu');
                        }
                    } else {
                        // Süresi dolmamış voice mute için timeout ayarla
                        const remainingTime = mute.endTime.getTime() - now.getTime();
                        setTimeout(async () => {
                            const currentMute = await VoiceMute.findOne({ _id: mute._id, isActive: true });
                            if (currentMute) {
                                await unmuteVoiceUser(client, mute.userId, guild.id, settings);
                            }
                        }, remainingTime);
                    }
                }
            }
            console.log('Voice mute takibi başlatıldı!');
        } catch (error) {
            console.error('Voice mute takibi başlatılırken hata:', error);
        }



        // Jail takibi için mevcut jail'leri kontrol et
        try {
            const Jail = require('../models/Jail');
            
            for (const guild of client.guilds.cache.values()) {
                const activeJails = await Jail.find({ guildId: guild.id, isReleased: false });
                const settings = await Settings.findOne({ id: guild.id });
                
                for (const jail of activeJails) {
                    if (jail.releaseAt) {
                        const now = new Date();
                        if (jail.releaseAt <= now) {
                            // Süresi dolmuş jail'i kaldır
                            await releaseJailUser(client, jail.userId, guild.id, settings);
                        } else {
                            // Süresi dolmamış jail için timeout ayarla
                            const remainingTime = jail.releaseAt.getTime() - now.getTime();
                            setTimeout(async () => {
                                const currentJail = await Jail.findOne({ _id: jail._id, isReleased: false });
                                if (currentJail) {
                                    await releaseJailUser(client, jail.userId, guild.id, settings);
                                }
                            }, remainingTime);
                        }
                    }
                }
            }
            console.log('Jail takibi başlatıldı!');
        } catch (error) {
            console.error('Jail takibi başlatılırken hata:', error);
        }
    }
}; 