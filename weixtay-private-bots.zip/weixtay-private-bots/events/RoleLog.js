const RoleLog = require('../models/RoleLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildMemberUpdate',
    async execute(oldMember, newMember, client) {
        try {
           
            // Get added roles
            const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
            // Get removed roles
            const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));

            if (addedRoles.size === 0 && removedRoles.size === 0) {
               
            }

            // Fetch audit logs
            const auditLogs = await newMember.guild.fetchAuditLogs({
                type: AuditLogEvent.MemberRoleUpdate,
                limit: 1
            });

            const roleLog = auditLogs.entries.first();
            const executor = roleLog ? roleLog.executor : { username: 'Unknown' };

            // Log added roles
            for (const role of addedRoles.values()) {
                await RoleLog.create({
                    userId: newMember.id,
                    roleId: role.id,
                    roleName: role.name,
                    action: 'add',
                    executorName: executor.username,
                    timestamp: new Date()
                });
            }

            // Log removed roles
            for (const role of removedRoles.values()) {
                await RoleLog.create({
                    userId: newMember.id,
                    roleId: role.id,
                    roleName: role.name,
                    action: 'remove',
                    executorName: executor.username,
                    timestamp: new Date()
                });
            }

        } catch (error) {
            console.error('[ROLELOG] Error:', error);
        }
    }
}; 