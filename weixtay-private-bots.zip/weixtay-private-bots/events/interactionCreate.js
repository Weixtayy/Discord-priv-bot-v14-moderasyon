const { InteractionType } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (interaction.isCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);
            if (command) {
                try {
                    await command.execute(interaction.client, interaction);
                } catch (error) {
                    console.error(error);
                    await interaction.reply({ content: 'Bu komutu yürütürken bir hata oluştu!', ephemeral: true });
                }
            }
        } else if (interaction.isButton()) {
            const member = interaction.member;
            const guild = interaction.guild;

            const colorNames = ['Kırmızı', 'Mavi', 'Yeşil', 'Sarı', 'Mor', 'Turuncu', 'Pembe', 'Siyah', 'Beyaz'];
            const zodiacNames = ['Koç', 'Boğa', 'İkizler', 'Yengeç', 'Aslan', 'Başak', 'Terazi', 'Akrep', 'Yay', 'Oğlak', 'Kova', 'Balık'];

            if (interaction.customId.startsWith('color_')) {
                const colorName = interaction.customId.replace('color_', '');
                const colorRole = guild.roles.cache.find(r => r.name === colorName);
                
                if (!colorRole) {
                    return interaction.reply({ content: 'Bu rol bulunamadı!', ephemeral: true });
                }

                const otherColorRoles = member.roles.cache.filter(r => 
                    colorNames.includes(r.name) && r.id !== colorRole.id
                );
                if (otherColorRoles.size > 0) {
                    await member.roles.remove(otherColorRoles);
                }

                await member.roles.add(colorRole);
                await interaction.reply({ content: `${colorName} rolü başarıyla verildi!`, ephemeral: true });

            } else if (interaction.customId.startsWith('zodiac_')) {
                const zodiacName = interaction.customId.replace('zodiac_', '');
                const zodiacRole = guild.roles.cache.find(r => r.name === zodiacName);
                
                if (!zodiacRole) {
                    return interaction.reply({ content: 'Bu rol bulunamadı!', ephemeral: true });
                }

                const otherZodiacRoles = member.roles.cache.filter(r => 
                    zodiacNames.includes(r.name) && r.id !== zodiacRole.id
                );
                if (otherZodiacRoles.size > 0) {
                    await member.roles.remove(otherZodiacRoles);
                }

                await member.roles.add(zodiacRole);
                await interaction.reply({ content: `${zodiacName} rolü başarıyla verildi!`, ephemeral: true });
            } else if (interaction.customId === 'register_panel') {
                const Settings = require('../models/Settings');
                const { ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
                // Get settings
                const settings = await Settings.findOne({ id: guild.id });
                if (!settings || !settings.memberRole) {
                    return interaction.reply({ content: 'Kayıt sistemi tam ayarlanmamış!', ephemeral: true });
                }
                const memberRole = guild.roles.cache.get(settings.memberRole);
                const unregisteredRole = settings.unregisteredRole ? guild.roles.cache.get(settings.unregisteredRole) : null;
                // Rol işlemleri
                if (unregisteredRole && member.roles.cache.has(unregisteredRole.id)) {
                    await member.roles.remove(unregisteredRole).catch(() => {});
                }
                if (memberRole && !member.roles.cache.has(memberRole.id)) {
                    await member.roles.add(memberRole).catch(() => {});
                }
                // Sayaç güncelle (in-memory, productionda DB ile yapılmalı)
                const buttonCmd = require('../commands/register/button');
                buttonCmd.registerClickCount = (buttonCmd.registerClickCount || 0) + 1;
                // Sadece butonu güncelle
                const registerButton = new ButtonBuilder()
                    .setCustomId('register_panel')
                    .setLabel(`Kayıt - Ol ( ${buttonCmd.registerClickCount} )`)
                    .setStyle(ButtonStyle.Secondary);
                const row = new ActionRowBuilder().addComponents(registerButton);
                await interaction.update({ components: [row] });
                return interaction.followUp({ content: 'Başarıyla kayıt oldun!', ephemeral: true });
            }
        } else if (interaction.isStringSelectMenu()) {
            const member = interaction.member;
            const guild = interaction.guild;
            if (interaction.customId === 'select_color_roles') {
                const colorNames = ['Kırmızı', 'Mavi', 'Yeşil', 'Sarı', 'Mor', 'Turuncu', 'Pembe', 'Siyah', 'Beyaz'];
                const selected = interaction.values.map(v => v.replace('color_', ''));
                const rolesToAdd = colorNames.filter(name => selected.includes(name)).map(name => guild.roles.cache.find(r => r.name === name)).filter(Boolean);
                const rolesToRemove = member.roles.cache.filter(r => colorNames.includes(r.name) && !selected.includes(r.name));
                if (rolesToRemove.size > 0) await member.roles.remove(rolesToRemove);
                for (const role of rolesToAdd) {
                    if (!member.roles.cache.has(role.id)) await member.roles.add(role);
                }
                await interaction.reply({ content: 'Renk rolleri güncellendi!', ephemeral: true });
            } else if (interaction.customId === 'select_zodiac_roles') {
                const zodiacNames = ['Koç', 'Boğa', 'İkizler', 'Yengeç', 'Aslan', 'Başak', 'Terazi', 'Akrep', 'Yay', 'Oğlak', 'Kova', 'Balık'];
                const selected = interaction.values.map(v => v.replace('zodiac_', ''));
                const rolesToAdd = zodiacNames.filter(name => selected.includes(name)).map(name => guild.roles.cache.find(r => r.name === name)).filter(Boolean);
                const rolesToRemove = member.roles.cache.filter(r => zodiacNames.includes(r.name) && !selected.includes(r.name));
                if (rolesToRemove.size > 0) await member.roles.remove(rolesToRemove);
                for (const role of rolesToAdd) {
                    if (!member.roles.cache.has(role.id)) await member.roles.add(role);
                }
                await interaction.reply({ content: 'Burç rolleri güncellendi!', ephemeral: true });
            }
        }
        // Modal submit handler ekle
        else if (interaction.type === InteractionType.ModalSubmit || (interaction.isModalSubmit && interaction.isModalSubmit())) {
            if (interaction.customId === 'tag_settings_modal') {
                try {
                    const Settings = require('../models/Settings');
                    const tag1 = interaction.fields.getTextInputValue('tag1');
                    const tag2 = interaction.fields.getTextInputValue('tag2');
                    let settings = await Settings.findOne({ id: interaction.guild.id }) || new Settings({ id: interaction.guild.id });
                    settings.tag1 = tag1;
                    settings.tag2 = tag2;
                    await settings.save();
                    await interaction.reply({ content: 'Tag ayarları başarıyla kaydedildi!', ephemeral: true });
                } catch (err) {
                    console.error('Modal submit hatası:', err);
                    if (!interaction.replied) await interaction.reply({ content: 'Bir hata oluştu, lütfen tekrar deneyin.', ephemeral: true });
                }
            }
        }
    }
}; 