const { AuditLogEvent } = require('discord.js');
const Settings = require('../models/Settings');
const Jail = require('../models/Jail');
const ChatMute = require('../models/ChatMute');
const VoiceMute = require('../models/VoiceMute');

module.exports = {
    name: 'guildMemberUpdate',
    async execute(oldMember, newMember) {
        try {
            const settings = await Settings.findOne({ id: newMember.guild.id });
            if (!settings) return;

            // Jail rolü kaldırıldı mı kontrol et
            if (settings.jailRole && oldMember.roles.cache.has(settings.jailRole) && !newMember.roles.cache.has(settings.jailRole)) {
                // Jail rolü kaldırıldı, kontrol et
                const activeJail = await Jail.findOne({ 
                    userId: newMember.id, 
                    guildId: newMember.guild.id, 
                    isReleased: false 
                });

                if (activeJail && activeJail.releaseAt && activeJail.releaseAt > new Date()) {
                    // Süresi dolmamış jail varsa rolü geri ver
                    try {
                        await newMember.roles.add(settings.jailRole, 'Jail cezası devam ediyor');
                        console.log(`${newMember.user.tag} kullanıcısının jail rolü geri verildi (ceza devam ediyor)`);
                    } catch (error) {
                        console.error('Jail rolü geri verme hatası:', error);
                    }
                }
            }

            // Mute rolü kaldırıldı mı kontrol et
            if (settings.muteRole && oldMember.roles.cache.has(settings.muteRole) && !newMember.roles.cache.has(settings.muteRole)) {
                // Mute rolü kaldırıldı, kontrol et
                const activeMute = await ChatMute.findOne({ 
                    guildId: newMember.guild.id, 
                    userId: newMember.id, 
                    isActive: true 
                });

                if (activeMute) {
                    const remainingTime = activeMute.endTime.getTime() - Date.now();
                    if (remainingTime > 0) {
                        // Aktif chat mute varsa rolü geri ver
                        try {
                            await newMember.roles.add(settings.muteRole, 'Chat mute cezası devam ediyor');
                            console.log(`${newMember.user.tag} kullanıcısının chat mute rolü geri verildi (kalan süre: ${Math.floor(remainingTime / 60000)} dakika)`);
                        } catch (error) {
                            console.error('Chat mute rolü geri verme hatası:', error);
                        }
                    } else {
                        // Süresi dolmuşsa mute'u pasif yap
                        activeMute.isActive = false;
                        await activeMute.save();
                        console.log(`${newMember.user.tag} kullanıcısının chat mute süresi dolmuş, pasif yapıldı`);
                    }
                }
            }

            // Voice Mute rolü kaldırıldı mı kontrol et
            if (settings.voiceMuteRole && oldMember.roles.cache.has(settings.voiceMuteRole) && !newMember.roles.cache.has(settings.voiceMuteRole)) {
                // Voice mute rolü kaldırıldı, kontrol et
                const activeVoiceMute = await VoiceMute.findOne({ 
                    guildId: newMember.guild.id, 
                    userId: newMember.id, 
                    isActive: true 
                });

                if (activeVoiceMute) {
                    const remainingTime = activeVoiceMute.endTime.getTime() - Date.now();
                    if (remainingTime > 0) {
                        // Aktif voice mute varsa rolü geri ver
                        try {
                            await newMember.roles.add(settings.voiceMuteRole, 'Voice mute cezası devam ediyor');
                            console.log(`${newMember.user.tag} kullanıcısının voice mute rolü geri verildi (kalan süre: ${Math.floor(remainingTime / 60000)} dakika)`);
                        } catch (error) {
                            console.error('Voice mute rolü geri verme hatası:', error);
                        }
                    } else {
                        // Süresi dolmuşsa voice mute'u pasif yap
                        activeVoiceMute.isActive = false;
                        await activeVoiceMute.save();
                        console.log(`${newMember.user.tag} kullanıcısının voice mute süresi dolmuş, pasif yapıldı`);
                    }
                }
            }

        } catch (error) {
            console.error('Guild member update hatası:', error);
        }
    }
}; 