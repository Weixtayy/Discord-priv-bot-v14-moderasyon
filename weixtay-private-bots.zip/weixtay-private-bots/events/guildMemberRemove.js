const { EmbedBuilder } = require('discord.js');
const Settings = require('../models/Settings');
const UserStats = require('../models/UserStats');

module.exports = {
    name: 'guildMemberRemove',
    async execute(member) {
        try {
            const settings = await Settings.findOne({ id: member.guild.id });
            if (!settings || !settings.leaveChannel) return;
            const leaveChannel = member.guild.channels.cache.get(settings.leaveChannel);
            if (!leaveChannel) return;

            // Davet eden kişiyi ve davet kodunu bul
            let inviter = null;
            let inviteCode = null;
            try {
                const memberStats = await UserStats.findOne({ 
                    userId: member.id, 
                    guildId: member.guild.id 
                });
                if (memberStats && memberStats.lastInvitedBy) {
                    inviter = member.guild.members.cache.get(memberStats.lastInvitedBy);
                    inviteCode = memberStats.lastInviteCode;
                }
            } catch (error) {
                console.error('Davet eden bilgisi alınırken hata:', error);
            }

            // EMBED
            const embed = new EmbedBuilder()
                .setTitle('👋 Sunucudan Ayrıldı')
                .setDescription(`**${member.user.tag}** (\`${member.id}\`) sunucudan ayrıldı.`)
                .setColor(0xff0000)
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .addFields(
                    { name: '📅 Katılım Tarihi', value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Bilinmiyor', inline: true },
                    { name: '👥 Kalan Üye', value: `${member.guild.memberCount}`, inline: true }
                )
                .setTimestamp();

            if (inviter) {
                embed.addFields({ name: '🎯 Davet Eden', value: `${inviter.user.tag} (\`${inviter.id}\`)`, inline: true });
            }
            if (inviteCode) {
                embed.addFields({ name: '🔗 Davet Kodu', value: `\`${inviteCode}\``, inline: true });
            }
            embed.setFooter({ text: member.guild.name, iconURL: member.guild.iconURL({ dynamic: true }) });

            await leaveChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('guildMemberRemove event hatası:', error);
        }
    }
}; 