const Invite = require('../models/Invite');

module.exports = {
    name: 'inviteCreate',
    async execute(invite) {
        try {
            // Yeni daveti veritabanına kaydet
            const newInvite = new Invite({
                guildId: invite.guild.id,
                code: invite.code,
                inviterId: invite.inviter.id,
                uses: invite.uses,
                maxUses: invite.maxUses,
                expiresAt: invite.expiresAt,
                isTemporary: invite.temporary
            });

            await newInvite.save();
        } catch (error) {
            console.error('inviteCreate event hatası:', error);
        }
    }
}; 