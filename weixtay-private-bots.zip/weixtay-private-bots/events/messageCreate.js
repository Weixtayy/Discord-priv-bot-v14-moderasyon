const UserStats = require('../models/UserStats');
const Afk = require('../models/Afk');
const Level = require('../models/Level');
const Settings = require('../models/Settings');
const { createCanvas, loadImage, AttachmentBuilder } = require('canvas');
const { request } = require('undici');
const { addXP, createLevelUpCard } = require('../utils/levelSystem');
const canvafy = require('canvafy');

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        // Bot mesajlarını ve DM'leri sayma
        if (message.author.bot || !message.guild) return;

        const userId = message.author.id;
        const guildId = message.guild.id;

        // XP/Level Sistemi
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.commandChannel) return;
        // Sadece komut kanalında XP ver
        if (message.channel.id !== settings.commandChannel) return;

        // Seviye atlama öncesi eski seviye
        let levelData = await Level.findOne({ userId: message.author.id, guildId: message.guild.id });
        const oldLevel = levelData ? (levelData.messageLevel || 1) : 1;
        const { leveledUp, levelData: newLevelData, activity, newLevel } = await addXP({ userId: message.author.id, guildId: message.guild.id, type: 'message' });
        if (leveledUp) {
            const avatarURL = message.member.displayAvatarURL({ dynamic: false, format: 'png', size: 1024 });
            const backgroundURL = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80";
            const levelUp = await new canvafy.LevelUp()
                .setAvatar(avatarURL)
                .setBackground("image", backgroundURL)
                .setUsername(message.member.displayName)
                .setBorder("#000000")
                .setAvatarBorder("#ff0000")
                .setOverlayOpacity(0.7)
                .setLevels(oldLevel, newLevel)
                .build();
            const levelUpChannel = message.guild.channels.cache.find(c => c.name === 'level-up' && c.isTextBased());
            if (levelUpChannel) {
                levelUpChannel.send({
                    content: `**${message.member.displayName} ${oldLevel} → ${newLevel} seviye atladı!**`,
                    files: [{ attachment: levelUp, name: `levelup-${message.member.id}.png` }]
                });
            }
        }

        try {
            // AFK kontrolü - Mesaj gönderen kişinin AFK durumunu kontrol et
            const afkEntry = await Afk.findOne({ userId, guildId });

            if (afkEntry) {
                // AFK durumundan çıkar
                await Afk.deleteOne({ userId, guildId });

                // Nickname'i eski haline getir
                if (message.member.manageable && afkEntry.oldNickname !== null) {
                    await message.member.setNickname(afkEntry.oldNickname).catch(err => {
                        console.error('AFK çıkışında kullanıcı adı değiştirilemedi:', err);
                    });
                } else if (message.member.manageable) {
                    await message.member.setNickname(null).catch(err => {
                        console.error('AFK çıkışında kullanıcı adı sıfırlanamadı:', err);
                    });
                }

                const timeAfk = Math.round((Date.now() - afkEntry.startedAt) / 1000); // Saniye cinsinden AFK süresi
                let timeString = '';
                if (timeAfk < 60) {
                    timeString = `${timeAfk} saniye`;
                } else if (timeAfk < 3600) {
                    timeString = `${Math.round(timeAfk / 60)} dakika`;
                } else if (timeAfk < 86400) {
                    timeString = `${Math.round(timeAfk / 3600)} saat`;
                } else {
                    timeString = `${Math.round(timeAfk / 86400)} gün`;
                }

                message.channel.send(`${message.author}, AFK durumundan çıktınız. ${timeString} boyunca uzaktaydınız.`);
            }

            // AFK kontrolü - Etiketlenen kişilerin AFK durumunu kontrol et
            if (message.mentions.users.size > 0) {
                for (const [id, user] of message.mentions.users) {
                    const mentionedAfkEntry = await Afk.findOne({ userId: id, guildId });
                    if (mentionedAfkEntry) {
                        const timeAfk = Math.round((Date.now() - mentionedAfkEntry.startedAt) / 1000);
                        let timeString = '';
                        if (timeAfk < 60) {
                            timeString = `${timeAfk} saniye`;
                        } else if (timeAfk < 3600) {
                            timeString = `${Math.round(timeAfk / 60)} dakika`;
                        } else if (timeAfk < 86400) {
                            timeString = `${Math.round(timeAfk / 3600)} saat`;
                        } else {
                            timeString = `${Math.round(timeAfk / 86400)} gün`;
                        }
                        message.channel.send(`${user}, şu anda AFK. Sebep: \`${mentionedAfkEntry.reason}\` (${timeString} önce AFK oldu.)`);
                    }
                }
            }

            // Kullanıcı istatistiklerini sayma (mevcut kod)
            let userStats = await UserStats.findOne({ userId, guildId });

            if (!userStats) {
                userStats = new UserStats({ userId, guildId });
            }

            const now = new Date();

            // Reset daily stats if a new day has started
            if (now.getDate() !== userStats.lastDailyReset.getDate() ||
                now.getMonth() !== userStats.lastDailyReset.getMonth() ||
                now.getFullYear() !== userStats.lastDailyReset.getFullYear()) {
                userStats.dailyMessageCount = 0;
                userStats.dailyVoiceTime = 0;
                userStats.dailyCameraTime = 0;
                userStats.dailyStreamingTime = 0;
                userStats.lastDailyReset = now;
            }

            // Reset weekly stats if a new week has started (Monday as start of week)
            const firstDayOfWeek = new Date(userStats.lastWeeklyReset);
            firstDayOfWeek.setDate(userStats.lastWeeklyReset.getDate() - (userStats.lastWeeklyReset.getDay() + 6) % 7); // Adjust to Monday
            if (now.getTime() - firstDayOfWeek.getTime() >= 7 * 24 * 60 * 60 * 1000) {
                userStats.weeklyMessageCount = 0;
                userStats.weeklyVoiceTime = 0;
                userStats.weeklyCameraTime = 0;
                userStats.weeklyStreamingTime = 0;
                userStats.lastWeeklyReset = now;
            }

            // Reset monthly stats if a new month has started
            if (now.getMonth() !== userStats.lastMonthlyReset.getMonth() ||
                now.getFullYear() !== userStats.lastMonthlyReset.getFullYear()) {
                userStats.monthlyMessageCount = 0;
                userStats.monthlyVoiceTime = 0;
                userStats.monthlyCameraTime = 0;
                userStats.monthlyStreamingTime = 0;
                userStats.lastMonthlyReset = now;
            }

            userStats.messageCount++;
            userStats.dailyMessageCount++;
            userStats.weeklyMessageCount++;
            userStats.monthlyMessageCount++;

            await userStats.save();

        } catch (error) {
            console.error('[MESSAGE_STAT] Error saving message count or AFK handling:', error);
        }
    },
}; 