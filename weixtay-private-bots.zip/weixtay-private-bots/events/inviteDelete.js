const Invite = require('../models/Invite');

module.exports = {
    name: 'inviteDelete',
    async execute(invite) {
        try {
            // Silinen daveti veritabanından kaldır
            await Invite.findOneAndDelete({ 
                guildId: invite.guild.id, 
                code: invite.code 
            });
        } catch (error) {
            console.error('inviteDelete event hatası:', error);
        }
    }
}; 