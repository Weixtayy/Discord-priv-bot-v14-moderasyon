const { EmbedBuilder } = require('discord.js');
const Settings = require('../models/Settings');
const UserStats = require('../models/UserStats');
const Invite = require('../models/Invite');
const Jail = require('../models/Jail');
const ChatMute = require('../models/ChatMute');
const VoiceMute = require('../models/VoiceMute');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member) {
        try {
            const settings = await Settings.findOne({ id: member.guild.id });
            if (!settings) return;

            // memberRole kontrolü ve otomatik rol verme
            if (settings && settings.memberRole) {
                const role = member.guild.roles.cache.get(settings.memberRole);
                if (role) {
                    try {
                        await member.roles.add(role, 'Otomatik üye rolü');
                    } catch (e) {
                        console.error('Otomatik üye rolü verilemedi:', e);
                    }
                }
            }

            // Jail kontrolü - eğer aktif jail'i varsa jail rolünü ver
            const activeJail = await Jail.findOne({ 
                userId: member.id, 
                guildId: member.guild.id, 
                isReleased: false 
            });

            if (activeJail && activeJail.releaseAt && activeJail.releaseAt > new Date()) {
                // Süresi dolmamış jail varsa jail rolünü ver
                if (settings.jailRole) {
                    try {
                        await member.roles.add(settings.jailRole);
                    } catch (error) {
                        console.error('Jail rolü verilirken hata:', error);
                    }
                }
            } else {
                // Jail yoksa veya süresi dolmuşsa kayıtsız rolünü ver
                if (settings.unregisteredRole) {
                    try {
                        await member.roles.add(settings.unregisteredRole);
                    } catch (error) {
                        console.error('Kayıtsız rolü verilirken hata:', error);
                    }
                }
            }

            // Mute kontrolü - eğer aktif mute'u varsa mute rolünü ver
            const activeMute = await ChatMute.findOne({ 
                guildId: member.guild.id, 
                userId: member.id, 
                isActive: true 
            });

            if (activeMute && settings.muteRole) {
                try {
                    await member.roles.add(settings.muteRole);
                    console.log(`${member.user.tag} kullanıcısına mute rolü verildi (chat mute devam ediyor)`);
                } catch (error) {
                    console.error('Mute rolü verilirken hata:', error);
                }
            }

            // Voice Mute kontrolü - eğer aktif voice mute'u varsa voice mute rolünü ver
            const activeVoiceMute = await VoiceMute.findOne({ 
                guildId: member.guild.id, 
                userId: member.id, 
                isActive: true 
            });

            if (activeVoiceMute && settings.voiceMuteRole) {
                try {
                    await member.roles.add(settings.voiceMuteRole);
                    console.log(`${member.user.tag} kullanıcısına voice mute rolü verildi (voice mute devam ediyor)`);
                } catch (error) {
                    console.error('Voice mute rolü verilirken hata:', error);
                }
            }

            // Davet bilgisini bul
            let inviter = null;
            let inviteCode = null;
            try {
                const invites = await member.guild.invites.fetch();
                const userInvites = await Invite.find({ guildId: member.guild.id });
                
                // Bu kullanıcının daha önce davet edilip edilmediğini kontrol et
                let memberStats = await UserStats.findOne({ userId: member.id, guildId: member.guild.id });
                const isReturningUser = memberStats && memberStats.lastInvitedBy;
                
                for (const invite of userInvites) {
                    const guildInvite = invites.get(invite.code);
                    if (guildInvite && guildInvite.uses > invite.uses) {
                        inviter = member.guild.members.cache.get(invite.inviterId);
                        inviteCode = invite.code;
                        
                        // Davet sayısını güncelle
                        invite.uses = guildInvite.uses;
                        await invite.save();
                        
                        // Eğer bu kullanıcı daha önce davet edilmişse ve aynı kişi tarafından davet ediliyorsa sayı artırma
                        if (isReturningUser && memberStats.lastInvitedBy === invite.inviterId) {
                            console.log(`${member.user.tag} kullanıcısı zaten ${inviter.user.tag} tarafından davet edilmiş, sayı artırılmadı`);
                        } else {
                            // Davet eden kişinin istatistiklerini güncelle
                            let inviterStats = await UserStats.findOne({ userId: invite.inviterId, guildId: member.guild.id });
                            if (!inviterStats) {
                                inviterStats = new UserStats({ userId: invite.inviterId, guildId: member.guild.id });
                            }
                            inviterStats.invites += 1;
                            inviterStats.invitedUsers.push(member.id);
                            await inviterStats.save();
                            console.log(`${member.user.tag} kullanıcısı ${inviter.user.tag} tarafından davet edildi (+1 davet)`);
                        }

                        // Gelen üyenin son davet eden bilgisini kaydet
                        if (!memberStats) {
                            memberStats = new UserStats({ userId: member.id, guildId: member.guild.id });
                        }
                        memberStats.lastInvitedBy = invite.inviterId;
                        memberStats.lastInviteCode = invite.code;
                        await memberStats.save();
                        break;
                    }
                }
                if (!inviter) {
                    for (const [code, guildInvite] of invites) {
                        const existingInvite = userInvites.find(inv => inv.code === code);
                        if (!existingInvite && guildInvite.uses > 0) {
                            inviter = member.guild.members.cache.get(guildInvite.inviter.id);
                            inviteCode = code;
                            
                            // Eğer bu kullanıcı daha önce davet edilmişse ve aynı kişi tarafından davet ediliyorsa sayı artırma
                            if (isReturningUser && memberStats.lastInvitedBy === guildInvite.inviter.id) {
                                console.log(`${member.user.tag} kullanıcısı zaten ${inviter.user.tag} tarafından davet edilmiş, sayı artırılmadı`);
                            } else {
                                // Davet eden kişinin istatistiklerini güncelle
                                let inviterStats = await UserStats.findOne({ userId: guildInvite.inviter.id, guildId: member.guild.id });
                                if (!inviterStats) {
                                    inviterStats = new UserStats({ userId: guildInvite.inviter.id, guildId: member.guild.id });
                                }
                                inviterStats.invites += 1;
                                inviterStats.invitedUsers.push(member.id);
                                await inviterStats.save();
                                console.log(`${member.user.tag} kullanıcısı ${inviter.user.tag} tarafından davet edildi (+1 davet)`);
                            }

                            // Gelen üyenin son davet eden bilgisini kaydet
                            if (!memberStats) {
                                memberStats = new UserStats({ userId: member.id, guildId: member.guild.id });
                            }
                            memberStats.lastInvitedBy = guildInvite.inviter.id;
                            memberStats.lastInviteCode = code;
                            await memberStats.save();
                            break;
                        }
                    }
                }
            } catch (error) {
                console.error('Davet bilgisi alınırken hata:', error);
            }

            // Hoş geldin kanalı yoksa mesaj gönderme
            if (!settings.welcomeChannel) return;
            const welcomeChannel = member.guild.channels.cache.get(settings.welcomeChannel);
            if (!welcomeChannel) return;

            // EMBED
            const embed = new EmbedBuilder()
                .setTitle('🎉 Sunucuya Hoş Geldin!')
                .setDescription(`**${member.user.tag}** (\`${member.id}\`) sunucumuza katıldı!`)
                .setColor(0x00ff00)
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .addFields(
                    { name: '📅 Hesap Oluşturma', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: '👥 Üye Sayısı', value: `${member.guild.memberCount}`, inline: true }
                )
                .setTimestamp();

            if (inviter) {
                embed.addFields({ name: '🎯 Davet Eden', value: `${inviter.user.tag} (\`${inviter.id}\`)`, inline: true });
            }
            if (inviteCode) {
                embed.addFields({ name: '🔗 Davet Kodu', value: `\`${inviteCode}\``, inline: true });
            }
            if (member.guild.banner) {
                embed.setImage(member.guild.bannerURL({ size: 1024, format: 'png' }));
            }
            embed.setFooter({ text: member.guild.name, iconURL: member.guild.iconURL({ dynamic: true }) });

            await welcomeChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('guildMemberAdd event hatası:', error);
        }
    }
}; 