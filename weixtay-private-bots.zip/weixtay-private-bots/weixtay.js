const { Client, GatewayIntentBits, Collection, Partials, EmbedBuilder, ComponentType, REST, Routes } = require('discord.js');
const { joinVoiceChannel } = require('@discordjs/voice');
const fs = require('fs');
const { join } = require('path');
const mongoose = require('mongoose');
const config = require('./config');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildScheduledEvents,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
    ],
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.GuildMember,
        Partials.User
    ]
});

client.commands = new Collection();
client.aliases = new Collection();

// MongoDB Bağlantısı
mongoose.connect(config.mongoURL, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('MongoDB bağlantısı başarılı!');
}).catch((err) => {
    console.error('MongoDB bağlantı hatası:', err);
});

// --- OTOMATİK KOMUT YÜKLEYİCİ ---
const commandsPath = join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath).filter(folder => 
    fs.statSync(join(commandsPath, folder)).isDirectory()
);

for (const folder of commandFolders) {
    const folderPath = join(commandsPath, folder);
    const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        try {
            const command = require(join(folderPath, file));
            if (
                !command ||
                typeof command.name !== 'string' ||
                typeof command.execute !== 'function'
            ) {
                console.warn(`[COMMAND] Atlandı: ${folder}/${file} (name veya execute fonksiyonu yok)`);
                continue;
            }
            command.category = folder;
            client.commands.set(command.name, command);
            console.log(`[COMMAND] Loaded: ${folder}/${file}`);
            if (command.aliases && Array.isArray(command.aliases)) {
                command.aliases.forEach(alias => {
                    client.aliases.set(alias, command.name);
                });
            }
        } catch (err) {
            console.error(`[COMMAND] Yüklenemedi: ${folder}/${file}`, err);
        }
    }
}
// --- KOMUT YÜKLEYİCİ SONU ---

// Event Handler
const eventFiles = fs.readdirSync(join(__dirname, 'events')).filter(file => file.endsWith('.js'));
for (const file of eventFiles) {
    const event = require(join(__dirname, 'events', file));
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
        console.log(`[EVENT] Loaded: ${file}`);
    } else {
        client.on(event.name, (...args) => event.execute(...args, client));
        console.log(`[EVENT] Loaded: ${file}`);
    }
}

// Interaction Create Handler (Slash Commands and Buttons)
client.on('interactionCreate', async (interaction) => {
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(client, interaction, null, config);
        } catch (error) {
            console.error(error);
            if (interaction.deferred || interaction.replied) {
                await interaction.followUp({ content: 'Komut çalıştırılırken bir hata oluştu!', ephemeral: true });
            } else {
                await interaction.reply({ content: 'Komut çalıştırılırken bir hata oluştu!', ephemeral: true });
            }
        }
    } else if (interaction.isButton()) {
        const [commandName, period, userId] = interaction.customId.split('-');

        if (commandName === 'stat' && userId === interaction.user.id) {
            const command = client.commands.get(commandName);
            if (command) {
                try {
                    await command.execute(client, interaction, null, config);
                } catch (error) {
                    console.error(error);
                    if (interaction.deferred || interaction.replied) {
                        await interaction.followUp({ content: 'İstatistikler güncellenirken bir hata oluştu!', ephemeral: true });
                    } else {
                        await interaction.reply({ content: 'İstatistikler güncellenirken bir hata oluştu!', ephemeral: true });
                    }
                }
            }
        } else if (commandName === 'stat' && userId !== interaction.user.id) {
            // Başka bir kullanıcının butonuna tıklama
            await interaction.reply({ content: 'Sadece kendi istatistik butonlarınızı kullanabilirsiniz.', ephemeral: true });
        } else if (commandName === 'top') {
            const command = client.commands.get(commandName);
            if (command) {
                try {
                    await command.execute(client, interaction, null, config);
                } catch (error) {
                    console.error(error);
                    if (interaction.deferred || interaction.replied) {
                        await interaction.followUp({ content: 'Sıralamalar güncellenirken bir hata oluştu!', ephemeral: true });
                    } else {
                        await interaction.reply({ content: 'Sıralamalar güncellenirken bir hata oluştu!', ephemeral: true });
                    }
                }
            }
        }
    }
});

// Message Event Handler
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;

    const prefix = config.prefix;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName) || client.commands.get(client.aliases.get(commandName));
    if (!command) return;

    try {
        const embed = new EmbedBuilder()
            .setColor('#2f3136')
            .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
            .setFooter({ text: 'Nivroth Bots', iconURL: message.guild.iconURL() });

        await command.execute(client, message, args, config, null);
    } catch (error) {
        console.error(error);
        message.reply('Komut çalıştırılırken bir hata oluştu!').then(msg => {
            setTimeout(() => msg.delete().catch(() => {}), 5000);
        });
    }
});

client.login(config.token);

// Export