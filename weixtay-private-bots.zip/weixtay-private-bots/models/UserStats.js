const mongoose = require('mongoose');

const userStatsSchema = new mongoose.Schema({
    userId: { type: String, required: true, unique: true },
    guildId: { type: String, required: true },
    voiceTime: { type: Number, default: 0 }, // Total voice time in milliseconds
    messageCount: { type: Number, default: 0 }, // Total message count
    cameraTime: { type: Number, default: 0 }, // Total camera time in milliseconds
    streamingTime: { type: Number, default: 0 }, // Total streaming time in milliseconds

    // Daily Stats
    dailyVoiceTime: { type: Number, default: 0 },
    dailyMessageCount: { type: Number, default: 0 },
    dailyCameraTime: { type: Number, default: 0 },
    dailyStreamingTime: { type: Number, default: 0 },
    lastDailyReset: { type: Date, default: Date.now },

    // Weekly Stats
    weeklyVoiceTime: { type: Number, default: 0 },
    weeklyMessageCount: { type: Number, default: 0 },
    weeklyCameraTime: { type: Number, default: 0 },
    weeklyStreamingTime: { type: Number, default: 0 },
    lastWeeklyReset: { type: Date, default: Date.now },

    // Monthly Stats
    monthlyVoiceTime: { type: Number, default: 0 },
    monthlyMessageCount: { type: Number, default: 0 },
    monthlyCameraTime: { type: Number, default: 0 },
    monthlyStreamingTime: { type: Number, default: 0 },
    lastMonthlyReset: { type: Date, default: Date.now },

    lastVoiceJoin: { type: Date, default: null },
    lastCameraOn: { type: Date, default: null },
    lastStreamingOn: { type: Date, default: null },
    
    // Davet İstatistikleri
    invites: { type: Number, default: 0 },
    invitedUsers: [{ type: String }], // Davet edilen kullanıcı ID'leri
    lastInvitedBy: { type: String, default: null }, // En son kimin davet ettiği
    lastInviteCode: { type: String, default: null } // En son hangi davet koduyla geldiği
});

// Compound index to ensure uniqueness per user per guild for voice and message stats
userStatsSchema.index({ userId: 1, guildId: 1 }, { unique: true });

module.exports = mongoose.model('UserStats', userStatsSchema); 