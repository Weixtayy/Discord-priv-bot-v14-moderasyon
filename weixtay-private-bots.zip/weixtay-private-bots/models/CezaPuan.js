const mongoose = require('mongoose');

const cezaPuanSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    totalPoints: { type: Number, default: 0 }, // Toplam ceza puanı
    isAutoJailed: { type: Boolean, default: false }, // 300 puan nedeniyle otomatik jail
    punishments: [{ // Ceza geçmişi
        type: { type: String, required: true }, // mute, jail, ban
        points: { type: Number, required: true }, // Verilen puan
        reason: { type: String, required: true }, // Sebep
        staffId: { type: String, required: true }, // Yetkili ID
        date: { type: Date, default: Date.now }, // Tarih
        isActive: { type: Boolean, default: true } // Aktif mi
    }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Compound index for unique user per guild
cezaPuanSchema.index({ userId: 1, guildId: 1 }, { unique: true });

module.exports = mongoose.model('CezaPuan', cezaPuanSchema); 