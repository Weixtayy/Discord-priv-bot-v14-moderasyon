const mongoose = require('mongoose');

const voiceMuteSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    userId: { type: String, required: true },
    staffId: { type: String, required: true }, // Mute atan yetkili
    reason: { type: String, required: true },
    duration: { type: Number, required: true }, // milisaniye cinsinden süre
    endTime: { type: Date, required: true }, // mute bitiş zamanı
    isActive: { type: Boolean, default: true }, // mute aktif mi
    createdAt: { type: Date, default: Date.now }
}, { 
    // Hiçbir index kullanma
    autoIndex: false,
    collection: 'voice_mutes' // Ayrı koleksiyon
});

// Compound index - unique değil
voiceMuteSchema.index({ guildId: 1, userId: 1, isActive: 1 }, { unique: false });

module.exports = mongoose.model('VoiceMute', voiceMuteSchema); 