const mongoose = require('mongoose');

const afkSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        unique: true
    },
    guildId: {
        type: String,
        required: true
    },
    reason: {
        type: String,
        default: 'Belirtilmedi'
    },
    startedAt: {
        type: Date,
        default: Date.now
    },
    oldNickname: {
        type: String,
        default: null
    }
});

module.exports = mongoose.model('Afk', afkSchema); 