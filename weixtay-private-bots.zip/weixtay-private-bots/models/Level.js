const mongoose = require('mongoose');

const LevelSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    // Genel toplam (eski sistemle uyumlu)
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 1 },
    lastMessage: { type: Date, default: null },
    lastVoice: { type: Date, default: null },
    // Yeni: mesaj ve ses için ayrı ayrı
    messageXP: { type: Number, default: 0 },
    messageLevel: { type: Number, default: 1 },
    lastMessageXP: { type: Date, default: null },
    voiceXP: { type: Number, default: 0 },
    voiceLevel: { type: Number, default: 1 },
    lastVoiceXP: { type: Date, default: null }
});

module.exports = mongoose.model('Level', LevelSchema); 