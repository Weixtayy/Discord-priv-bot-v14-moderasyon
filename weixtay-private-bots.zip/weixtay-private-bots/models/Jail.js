const mongoose = require('mongoose');

const jailSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    reason: { type: String, required: true },
    duration: { type: Number, required: true }, // Süre (gün cinsinden)
    roles: [{ type: String }], // Alınan roller
    adminRoles: [{ type: String }], // Yetkili rolleri
    jailedBy: { type: String, required: true },
    jailedAt: { type: Date, default: Date.now },
    releaseAt: { type: Date },
    isReleased: { type: Boolean, default: false }
});

module.exports = mongoose.model('Jail', jailSchema); 