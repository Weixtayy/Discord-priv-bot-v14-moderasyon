const mongoose = require('mongoose');

const userNamesSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    userId: { type: String, required: true },
    names: [{
        name: String,
        date: { type: Date, default: Date.now },
        staffId: String // Kayıt eden yetkili
    }]
});

module.exports = mongoose.model('UserNames', userNamesSchema); 