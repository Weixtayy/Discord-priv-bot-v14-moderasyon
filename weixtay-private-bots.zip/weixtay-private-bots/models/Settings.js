const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true },
    // Kanal Ayarları
    commandChannel: { type: String, default: null },
    tweetChannel: { type: String, default: null },
    spochannel: { type: String, default: null },
    // Rol Ayarları
    
    vipRole: { type: String, default: null },
    banHammer: { type: String, default: null },
    jailHammer: { type: String, default: null },
    jailRole: { type: String, default: null },
    memberRole: { type: String, default: null },
    unregisteredRole: { type: String, default: null },
    // Kayıt Sistemi Ayarları
    tag1: { type: String, default: null },
    tag2: { type: String, default: null },
    tagMuh: { type: String, default: null },
    maleRole: { type: String, default: null },
    femaleRole: { type: String, default: null },
    kayitYetkiliRole: { type: String, default: null },
    // Hoş Geldin/Çıkış Sistemi
    welcomeChannel: { type: String, default: null },
    leaveChannel: { type: String, default: null },
    // Mute Sistemi
    muteRole: { type: String, default: null },
    voiceMuteRole: { type: String, default: null },
    muteYetkiliRole: { type: String, default: null },

    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Settings', settingsSchema); 