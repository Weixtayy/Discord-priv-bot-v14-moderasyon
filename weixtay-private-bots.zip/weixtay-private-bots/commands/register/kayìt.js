const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionsBitField } = require('discord.js');
const Settings = require('../../models/Settings');
const UserNames = require('../../models/UserNames');

module.exports = {
    name: 'kayıt',
    description: 'Kayıt işlemi yapar',
    aliases: ['e', 'k', 'erkek', 'kız'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.kayitYetkiliRole) return message.reply('Kayıt sistemi ayarlanmamış!');
        if (!message.member.roles.cache.has(settings.kayitYetkiliRole) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('Bu komutu kullanmak için kayıt yetkilisi olmalısın!');
        }

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Kayıt edilecek kullanıcıyı etiketle veya ID gir!');
        const isim = args[1];
        const yas = args[2];
        if (!isim || !yas) return message.reply('İsim ve yaş gir! Örnek: .k @kullanıcı İsim Yaş');

        const fixedIsim = isim.charAt(0).toLocaleUpperCase('tr-TR') + isim.slice(1);

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('kayıt_erkek').setLabel('Erkek').setStyle(ButtonStyle.Primary).setEmoji('👨'),
            new ButtonBuilder().setCustomId('kayıt_kız').setLabel('Kız').setStyle(ButtonStyle.Danger).setEmoji('👩'),
            new ButtonBuilder().setCustomId('gecmis_isimler').setLabel('Geçmiş İsimler').setStyle(ButtonStyle.Secondary).setEmoji('📜'),
            new ButtonBuilder().setCustomId('iptal_kayit').setLabel('İptal Et').setStyle(ButtonStyle.Secondary).setEmoji('❌')
        );

        const regEmbed = new EmbedBuilder()
            .setTitle('Kayıt Paneli')
            .setDescription(`Kullanıcı: ${user} (\`${user.id}\`)
İsim: **${fixedIsim}**
Yaş: **${yas}**`)
            .setColor(0x5865F2)
            .setFooter({ text: `Kayıt eden: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

        const regMsg = await message.reply({ embeds: [regEmbed], components: [row] });

        const filter = i => i.user.id === message.author.id && ['kayıt_erkek', 'kayıt_kız', 'gecmis_isimler', 'iptal_kayit'].includes(i.customId);
        const collector = regMsg.createMessageComponentCollector({ filter, time: 60_000 });

        // Hata yakalama için collector'a error handler ekle
        collector.on('error', error => {
            console.error('Button collector hatası:', error);
        });

        collector.on('collect', async (i) => {
            try {
                if (i.customId === 'gecmis_isimler') {
                    try {
                        let userNames = await UserNames.findOne({ guildId: message.guild.id, userId: user.id });
                        if (!userNames || !userNames.names || userNames.names.length === 0) {
                            await i.reply({ content: 'Bu kullanıcının kayıt geçmişi yok!', ephemeral: true });
                        } else {
                            const slice = userNames.names.slice(0, 10);
                            const embed = new EmbedBuilder()
                                .setTitle(`${user.user.tag || user.user.username} (${user.id}) - Kayıt Geçmişi`)
                                .setThumbnail(user.displayAvatarURL())
                                .setColor(0x5865F2)
                                .setDescription(slice.map((n, idx) => {
                                    const date = n.date ? Math.floor(new Date(n.date).getTime()/1000) : Math.floor(Date.now()/1000);
                                    const staffMention = n.staffId ? `<@${n.staffId}>` : 'Bilinmiyor';
                                    return `**${idx + 1}.** ${n.name || 'İsimsiz'} <t:${date}:R> ${staffMention}`;
                                }).join('\n'))
                                .setFooter({ text: `Toplam ${userNames.names.length} kayıt` });
                            await i.reply({ embeds: [embed], ephemeral: true });
                        }
                    } catch (error) {
                        console.error('Geçmiş isimler hatası:', error);
                        await i.reply({ content: 'Geçmiş isimler yüklenirken bir hata oluştu!', ephemeral: true });
                    }
                    return;
                }

                if (i.customId === 'iptal_kayit') {
                    const cancelEmbed = new EmbedBuilder()
                        .setTitle('Kayıt İptal Edildi')
                        .setDescription(`Kayıt işlemi iptal edildi. Kullanıcıya hiçbir işlem uygulanmadı.`)
                        .setColor(0xe84343)
                        .setFooter({ text: `İptal eden: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });
                    await i.update({ embeds: [cancelEmbed], components: [] });
                    collector.stop();
                    return;
                }

                let roleId, roleName, removeRoleId;
                if (i.customId === 'kayıt_erkek') {
                    roleId = settings.maleRole;
                    roleName = 'Erkek';
                    removeRoleId = settings.femaleRole;
                } else if (i.customId === 'kayıt_kız') {
                    roleId = settings.femaleRole;
                    roleName = 'Kız';
                    removeRoleId = settings.maleRole;
                } else {
                    return;
                }

                if (!roleId) return i.reply({ content: 'Rol ayarlanmamış!', ephemeral: true });

                if (removeRoleId && user.roles.cache.has(removeRoleId)) {
                    await user.roles.remove(removeRoleId).catch(() => {});
                }

                await user.roles.add(roleId).catch(() => {});

                const newName = `${settings.tag1 || ''} ${fixedIsim} ${settings.tag2 || ''} ${yas}`.replace(/ +/g, ' ').trim();
                await user.setNickname(newName).catch(() => {});

                let userNames = await UserNames.findOne({ guildId: message.guild.id, userId: user.id });
                if (!userNames) userNames = new UserNames({ guildId: message.guild.id, userId: user.id, names: [] });
                userNames.names.unshift({ name: newName, staffId: message.author.id });
                if (userNames.names.length > 50) userNames.names = userNames.names.slice(0, 50);
                await userNames.save();

                // 🔴 Kayıtsız rolü burda kaldır
                if (settings.unregisteredRole && user.roles.cache.has(settings.unregisteredRole)) {
                    await user.roles.remove(settings.unregisteredRole).catch(() => {});
                }

                const logChannel = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === 'kayıt-log');
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setAuthor({ name: `${user.user.tag} (${user.id})`, iconURL: user.displayAvatarURL() })
                        .setTitle('Kayıt Başarılı!')
                        .setDescription(`Kullanıcı: ${user} (\`${user.id}\`)
İsim: **${fixedIsim}**
Yaş: **${yas}**
Rol: **${roleName}**`)
                        .setColor(roleName === 'Erkek' ? 0x3498db : 0xe84393)
                        .setFooter({ text: `Kayıt eden: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                        .setTimestamp();
                    logChannel.send({ embeds: [embed] });
                }

                const doneEmbed = new EmbedBuilder()
                    .setTitle('Kayıt Tamamlandı')
                    .setDescription(`Kullanıcı: ${user} (\`${user.id}\`)
İsim: **${fixedIsim}** | Yaş: **${yas}**
Rol: **${roleName}**`)
                    .setColor(roleName === 'Erkek' ? 0x3498db : 0xe84393)
                    .setFooter({ text: `Kayıt eden: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

                await i.update({ embeds: [doneEmbed], components: [] });
                collector.stop();
            } catch (error) {
                console.error('Button interaction hatası:', error);
                try {
                    await i.reply({ content: 'Bir hata oluştu, lütfen tekrar deneyin.', ephemeral: true });
                } catch (replyError) {
                    console.error('Reply hatası:', replyError);
                }
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) regMsg.edit({ content: 'Kayıt işlemi zaman aşımına uğradı.', components: [] });
        });
    }
};
