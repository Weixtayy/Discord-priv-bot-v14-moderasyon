const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, PermissionsBitField } = require('discord.js');
const Settings = require('../../models/Settings');
const UserNames = require('../../models/UserNames');

module.exports = {
    name: 'isimler',
    description: 'Kullanıcının önceki kayıt isimlerini gösterir',
    aliases: ['isimgeçmişi','names','nickhistory'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.kayitYetkiliRole) return message.reply('Kayıt sistemi ayarlanmamış!');
        if (!message.member.roles.cache.has(settings.kayitYetkiliRole) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('Bu komutu kullanmak için kayıt yetkilisi olmalısın!');
        }
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Kullanıcıyı etiketle veya ID gir!');
        const userNames = await UserNames.findOne({ guildId: message.guild.id, userId: user.id });
        if (!userNames || !userNames.names.length) return message.reply('Bu kullanıcının kayıt geçmişi yok!');
        let page = 0;
        const perPage = 10;
        const totalPages = Math.ceil(userNames.names.length / perPage);
        const getEmbed = (page) => {
            const slice = userNames.names.slice(page * perPage, (page + 1) * perPage);
            return new EmbedBuilder()
                .setTitle(`${user.user.tag} (${user.id}) - Kayıt Geçmişi`)
                .setThumbnail(user.displayAvatarURL())
                .setColor(0x5865F2)
                .setDescription(slice.map((n, i) => `**${page * perPage + i + 1}.** ${n.name} <t:${Math.floor(new Date(n.date).getTime()/1000)}:R> <@${n.staffId}>`).join('\n'))
                .setFooter({ text: `Toplam ${userNames.names.length} kayıt | Sayfa ${page+1}/${totalPages}` });
        };
        let row = null;
        if (totalPages > 1) {
            row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('prev_names').setLabel('◀').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('next_names').setLabel('▶').setStyle(ButtonStyle.Secondary)
            );
        }
        const msg = await message.reply({ embeds: [getEmbed(page)], components: row ? [row] : [] });
        if (!row) return;
        const filter = i => i.user.id === message.author.id && ['prev_names','next_names'].includes(i.customId);
        const collector = msg.createMessageComponentCollector({ filter, time: 120_000 });
        collector.on('collect', async i => {
            if (i.customId === 'prev_names') page--;
            if (i.customId === 'next_names') page++;
            await i.update({
                embeds: [getEmbed(page)],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('prev_names').setLabel('◀').setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
                        new ButtonBuilder().setCustomId('next_names').setLabel('▶').setStyle(ButtonStyle.Secondary).setDisabled(page === totalPages-1)
                    )
                ]
            });
        });
    }
}; 