const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const Settings = require('../../models/Settings');

// In-memory click count (should be moved to DB for persistence)
let registerClickCount = 0;

module.exports = {
    name: 'bregister',
    description: 'Kayıt paneli gönderir (Yönetici)',
    category: 'register',
    async execute(client, message, args, config) {
        // Sadece yönetici
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('Bu komutu sadece yöneticiler kullanabilir!');
        }

        const guild = message.guild;
        // VIP Banka Kartı Tasarımı
        const canvasWidth = 480;
        const canvasHeight = 220;
        const canvas = createCanvas(canvasWidth, canvasHeight);
        const ctx = canvas.getContext('2d');

        // Koyu gradient arka plan
        const bgGrad = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
        bgGrad.addColorStop(0, '#23243a');
        bgGrad.addColorStop(0.5, '#181924');
        bgGrad.addColorStop(1, '#10111a');
        ctx.save();
        ctx.beginPath();
        ctx.roundRect(0, 0, canvasWidth, canvasHeight, 28);
        ctx.closePath();
        ctx.clip();
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        ctx.restore();

        // Kart üstü: Sunucu iconu ve adı
        try {
            const iconURL = guild.iconURL({ extension: 'png', size: 128, forceStatic: true });
            if (iconURL) {
                const icon = await loadImage(iconURL);
                // Glow
                ctx.save();
                ctx.beginPath();
                ctx.arc(60, 60, 38, 0, Math.PI * 2, true);
                ctx.shadowColor = '#4f8cff';
                ctx.shadowBlur = 18;
                ctx.fillStyle = '#23243a';
                ctx.fill();
                ctx.restore();
                // Icon
                ctx.save();
                ctx.beginPath();
                ctx.arc(60, 60, 34, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(icon, 26, 26, 68, 68);
                ctx.restore();
            }
        } catch (error) { /* ignore */ }

        // Sunucu adı (üstte, modern)
        ctx.save();
        ctx.font = 'bold 28px Arial';
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'left';
        ctx.fillText(guild.name, 110, 60);
        ctx.restore();

        // Açıklama (ortada)
        ctx.font = '18px Arial';
        ctx.fillStyle = '#b9bbbe';
        ctx.textAlign = 'center';
        ctx.fillText('Butona basarak kayıt olabilirsiniz', canvasWidth / 2, 120);

        // Sol altta büyük VIP yazısı (gradient)
        ctx.save();
        ctx.font = 'bold 48px Arial';
        const vipGrad = ctx.createLinearGradient(40, canvasHeight - 60, 180, canvasHeight - 10);
        vipGrad.addColorStop(0, '#ffe066');
        vipGrad.addColorStop(1, '#4f8cff');
        ctx.fillStyle = vipGrad;
        ctx.textAlign = 'left';
        ctx.globalAlpha = 0.92;
        ctx.fillText('VIP', 40, canvasHeight - 28);
        ctx.globalAlpha = 1;
        ctx.restore();

        // Sağ alt köşeye imza
        ctx.save();
        ctx.font = 'bold 16px Arial';
        const signGrad = ctx.createLinearGradient(canvasWidth - 120, canvasHeight - 18, canvasWidth - 10, canvasHeight - 18);
        signGrad.addColorStop(0, '#4f8cff');
        signGrad.addColorStop(1, '#ffe066');
        ctx.fillStyle = signGrad;
        ctx.textAlign = 'right';
        ctx.fillText('By Nivroth', canvasWidth - 18, canvasHeight - 18);
        ctx.restore();

        // Kayıt Ol butonu (tıklayan sayısı ile)
        const registerButton = new ButtonBuilder()
            .setCustomId('register_panel')
            .setLabel(`Kayıt Ol (${registerClickCount})`)
            .setStyle(ButtonStyle.Secondary);
        const row = new ActionRowBuilder().addComponents(registerButton);

        const buffer = canvas.toBuffer();
        const attachment = new AttachmentBuilder(buffer, { name: 'register_panel.png' });

        await message.reply({ files: [attachment], components: [row] });
    }
}; 