const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'kayıtsız',
    description: 'Kullanıcıyı kayıtsıza atar',
    aliases: ['unreg', 'unregistered'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.unregisteredRole) return message.reply('Kayıtsız rol ayarlanmamış!');
        if (!settings.kayitYetkiliRole) return message.reply('Kayıt sistemi ayarlanmamış!');
        if (!message.member.roles.cache.has(settings.kayitYetkiliRole) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('Bu komutu kullanmak için kayıt yetkilisi olmalısın!');
        }
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Kullanıcıyı etiketle veya ID gir!');
        if (user.id === message.author.id) return message.reply('Kendini kayıtsıza atamazsın!');
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) return message.reply('Rolleri yönetme yetkim yok!');
        // Tüm rollerini çek, sadece kayıtsız rolü ver
        const rolesToRemove = user.roles.cache.filter(r => r.id !== settings.unregisteredRole && r.editable);
        await user.roles.remove(rolesToRemove).catch(() => {});
        await user.roles.add(settings.unregisteredRole).catch(() => {});
        // Embedli başarı mesajı
        const embed = new EmbedBuilder()
            .setTitle('Kayıtsız İşlemi')
            .setDescription(`${user} kullanıcısının tüm rolleri çekildi ve kayıtsız rolü verildi.`)
            .setColor(0x5865F2)
            .setFooter({ text: `İşlemi yapan: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();
        await message.reply({ embeds: [embed] });
    }
}; 