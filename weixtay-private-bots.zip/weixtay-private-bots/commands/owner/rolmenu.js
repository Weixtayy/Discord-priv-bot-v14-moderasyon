const { PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'rolmenu',
    description: 'Rol seçim menüsünü oluşturur.',
    category: 'owner',
    async execute(client, message, args, config) {
        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('Bu komutu kullanmak için "Yönetici" yetkisine sahip olmalısın!');
        }

        // Renk Rolleri
        const colorNames = ['Kırmızı', 'Mavi', 'Yeşil', 'Sarı', 'Mor', 'Turuncu', 'Pembe', 'Siyah', 'Beyaz'];
        const colorEmojis = {
            'Kırmızı': '🔴', 'Mavi': '🔵', 'Yeşil': '🟢', 'Sarı': '🟡', 'Mor': '🟣', 'Turuncu': '🟠', 'Pembe': '💗', 'Siyah': '⚫', 'Beyaz': '⚪'
        };
        let colorOptions = colorNames
            .filter(name => message.guild.roles.cache.some(r => r.name === name))
            .map(color => {
                let label = color;
                let value = `color_${color}`;
                if (!label || label.length < 1) label = 'Renk';
                if (label.length > 25) label = label.slice(0, 25);
                if (!value || value.length < 1) value = 'color';
                if (value.length > 25) value = value.slice(0, 25);
                return {
                    label,
                    value,
                    emoji: colorEmojis[color] || undefined
                };
            })
            .filter(opt => opt.label && opt.value && opt.label.length >= 1 && opt.label.length <= 25 && opt.value.length >= 1 && opt.value.length <= 25);
        if (colorOptions.length === 0) {
            colorOptions.push({ label: 'Yok', value: 'none', emoji: undefined });
        }

        const colorSelect = new StringSelectMenuBuilder()
            .setCustomId('select_color_roles')
            .setPlaceholder('Renk Rolü Seçin')
            .setMinValues(0)
            .setMaxValues(1)
            .addOptions(colorOptions);

        // Burç Rolleri
        const zodiacNames = ['Koç', 'Boğa', 'İkizler', 'Yengeç', 'Aslan', 'Başak', 'Terazi', 'Akrep', 'Yay', 'Oğlak', 'Kova', 'Balık'];
        const zodiacEmojis = {
            'Koç': '♈', 'Boğa': '♉', 'İkizler': '♊', 'Yengeç': '♋', 'Aslan': '♌', 'Başak': '♍', 'Terazi': '♎', 'Akrep': '♏', 'Yay': '♐', 'Oğlak': '♑', 'Kova': '♒', 'Balık': '♓'
        };
        let zodiacOptions = zodiacNames
            .filter(name => message.guild.roles.cache.some(r => r.name === name))
            .map(zodiac => {
                let label = zodiac;
                let value = `zodiac_${zodiac}`;
                if (!label || label.length < 1) label = 'Burç';
                if (label.length > 25) label = label.slice(0, 25);
                if (!value || value.length < 1) value = 'zodiac';
                if (value.length > 25) value = value.slice(0, 25);
                return {
                    label,
                    value,
                    emoji: zodiacEmojis[zodiac] || undefined
                };
            })
            .filter(opt => opt.label && opt.value && opt.label.length >= 1 && opt.label.length <= 25 && opt.value.length >= 1 && opt.value.length <= 25);
        if (zodiacOptions.length === 0) {
            zodiacOptions.push({ label: 'Yok', value: 'none', emoji: undefined });
        }

        const zodiacSelect = new StringSelectMenuBuilder()
            .setCustomId('select_zodiac_roles')
            .setPlaceholder('Burç Rolü Seçin')
            .setMinValues(0)
            .setMaxValues(1)
            .addOptions(zodiacOptions);

        // Satırları oluştur
        const rows = [
            new ActionRowBuilder().addComponents(colorSelect),
            new ActionRowBuilder().addComponents(zodiacSelect)
        ];

        await message.channel.send({
            content: `**${message.guild.name} - Rol Seçim Menüsü**\n\nRenk ve burç rollerini seçebilirsiniz.`,
            components: rows
        });
    },
}; 