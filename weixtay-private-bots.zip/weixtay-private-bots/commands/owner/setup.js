const { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, PermissionFlagsBits, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'setup',
    description: 'Sunucu ayarlarını yapılandırır ve istatistikleri gösterir.',
    category: 'owner',
    async execute(client, message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) return;

        let settings = await Settings.findOne({ id: message.guild.id }) || new Settings({ id: message.guild.id });
        await settings.save();

        let lastSelectedRoleType = null;
        let lastSelectedChannelType = null;

        // Menü satırları
        const roleMenuRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setPlaceholder('Rol Ayarları')
                .setCustomId('roleMenu')
                .addOptions([
                    { label: 'VIP Rolü', value: 'vipRole', description: 'VIP rolünü ayarlar' },
                    { label: 'Ban Hammer Rolü', value: 'banHammer', description: 'Ban Hammer rolünü ayarlar' },
                    { label: 'Jail Hammer Rolü', value: 'jailHammer', description: 'Jail Hammer rolünü ayarlar' },
                    { label: 'Jail Ceza Rolü', value: 'jailRole', description: 'Jail ceza rolünü ayarlar' },
                    { label: 'Üye Rolü', value: 'memberRole', description: 'Kayıt olanlara verilecek üye rolü' },
                    { label: 'Kayıtsız Rol', value: 'unregisteredRole', description: 'Kayıtsız kullanıcı rolü' },
                    { label: 'Kayıt Erkek Rolü', value: 'maleRole', description: 'Kayıt edilenlere verilecek erkek rolü' },
                    { label: 'Kayıt Kız Rolü', value: 'femaleRole', description: 'Kayıt edilenlere verilecek kız rolü' },
                    { label: 'Kayıt Yetkilisi Rolü', value: 'kayitYetkiliRole', description: 'Kayıt yetkilisi rolü' },
                    { label: 'Mute Rolü', value: 'muteRole', description: 'Chat mute için verilecek rol' },
                    { label: 'VMute Rolü', value: 'voiceMuteRole', description: 'Voice mute için verilecek rol' },
                    { label: 'Mute Yetkilisi Rolü', value: 'muteYetkiliRole', description: 'Mute atabilen yetkili rolü' },
                ])
        );

        const channelMenuRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setPlaceholder('Kanal Ayarları')
                .setCustomId('channelMenu')
                .addOptions([
                    { label: 'Komut Kanalı', value: 'commandChannel', description: 'Komut kullanım kanalını ayarlar' },
                    { label: 'Tweet Kanalı', value: 'tweetChannel', description: 'Tweet komutunun kullanılacağı kanalı ayarlar' },
                    { label: 'Spo Kanalı', value: 'spochannel', description: 'Spo komutunun kullanılacağı kanalı ayarlar' },
                    { label: 'Hoş Geldin Kanalı', value: 'welcomeChannel', description: 'Hoş geldin mesajlarının gönderileceği kanal' },
                    { label: 'Çıkış Kanalı', value: 'leaveChannel', description: 'Çıkış mesajlarının gönderileceği kanal' }
                ])
        );

        const otherMenuRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setPlaceholder('Diğer Ayarlar')
                .setCustomId('otherMenu')
                .addOptions([
                    { label: 'Tag Ayarları', value: 'tagSettings', description: 'Kayıt ismi başı ve arası tag ayarları' }
                ])
        );

        const buttonRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('channelSetup')
                    .setLabel('Kanal Kurulumu')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('roleSetup')
                    .setLabel('Rol Kurulumu')
                    .setStyle(ButtonStyle.Success)
            );

        const msg = await message.reply({
            content: 'Sunucu ayarlarını yapılandırmak için aşağıdaki menüleri kullanın:',
            components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow],
        });

        const interactionFilter = (i) => i.user.id === message.author.id;
        const collector = msg.createMessageComponentCollector({
            filter: interactionFilter,
            time: 1000 * 60 * 30,
        });

        collector.on('collect', async (i) => {
            try {
                // Kanal kurulum butonu
                if (i.customId === 'channelSetup') {
                    await logSetup(message);
                    await i.update({ content: 'Kanal kurulumu tamamlandı!', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
                }
                // Rol kurulum butonu
                else if (i.customId === 'roleSetup') {
                    await roleSetup(message);
                    await i.update({ content: 'Rol kurulumu tamamlandı!', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
                }
                // Kanal ayarları menüsü
                else if (i.customId === 'channelMenu') {
                    lastSelectedChannelType = i.values[0];
                    const channelSelectRow = new ActionRowBuilder().addComponents(
                        new ChannelSelectMenuBuilder()
                            .setPlaceholder('Kanal Seçin')
                            .setCustomId('channelSelect')
                            .setChannelTypes([ChannelType.GuildText])
                    );
                    await i.update({ content: 'Kanal seçin:', components: [channelSelectRow] });
                }
                // Kanal seçimi
                else if (i.customId === 'channelSelect') {
                    if (!lastSelectedChannelType) {
                        await i.update({ content: 'Bir hata oluştu, lütfen tekrar deneyin.', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
                        return;
                    }
                    settings[lastSelectedChannelType] = i.values[0];
                    await settings.save();
                    await i.update({ content: 'Kanal başarıyla güncellendi!', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
                }
                // Rol ayarları menüsü
                else if (i.customId === 'roleMenu') {
                    lastSelectedRoleType = i.values[0];
                    const roleSelectRow = new ActionRowBuilder().addComponents(
                        new RoleSelectMenuBuilder()
                            .setPlaceholder('Rol Seçin')
                            .setCustomId('roleSelect')
                    );
                    await i.update({ content: 'Rol seçin:', components: [roleSelectRow] });
                }
                // Rol seçimi
                else if (i.customId === 'roleSelect') {
                    if (!lastSelectedRoleType) {
                        await i.update({ content: 'Bir hata oluştu, lütfen tekrar deneyin.', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
                        return;
                    }
                    settings[lastSelectedRoleType] = i.values[0];
                    await settings.save();
                    await i.update({ content: 'Rol başarıyla güncellendi!', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
                }
                // Tag ayarları
                else if (i.customId === 'otherMenu' && i.values[0] === 'tagSettings') {
                    const modal = new ModalBuilder()
                        .setCustomId('tag_settings_modal')
                        .setTitle('Tag Ayarları');
                    const tag1Input = new TextInputBuilder()
                        .setCustomId('tag1')
                        .setLabel('Tag 1 (isim başı sembolü)')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true);
                    const tag2Input = new TextInputBuilder()
                        .setCustomId('tag2')
                        .setLabel('Tag 2 (isim/yaş arası sembolü)')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true);
                    modal.addComponents(
                        new ActionRowBuilder().addComponents(tag1Input),
                        new ActionRowBuilder().addComponents(tag2Input)
                    );
                    await i.showModal(modal);
                }
            } catch (error) {
                console.error('Interaction error:', error);
                await i.update({ content: 'Bir hata oluştu, lütfen tekrar deneyin.', components: [roleMenuRow, channelMenuRow, otherMenuRow, buttonRow] });
            }
        });
    },
};

async function roleSetup(message) {
    const roles = [
        // Renk Rolleri
        { name: 'Kırmızı', color: '#FF0000' },
        { name: 'Mavi', color: '#0000FF' },
        { name: 'Yeşil', color: '#00FF00' },
        { name: 'Sarı', color: '#FFFF00' },
        { name: 'Mor', color: '#800080' },
        { name: 'Turuncu', color: '#FFA500' },
        { name: 'Pembe', color: '#FFC0CB' },
        { name: 'Siyah', color: '#000000' },
        { name: 'Beyaz', color: '#FFFFFF' },
        // Burç Rolleri
        { name: 'Koç', color: '#FF0000' },
        { name: 'Boğa', color: '#00FF00' },
        { name: 'İkizler', color: '#FFFF00' },
        { name: 'Yengeç', color: '#00FFFF' },
        { name: 'Aslan', color: '#FFA500' },
        { name: 'Başak', color: '#800080' },
        { name: 'Terazi', color: '#FFC0CB' },
        { name: 'Akrep', color: '#FF0000' },
        { name: 'Yay', color: '#00FF00' },
        { name: 'Oğlak', color: '#808080' },
        { name: 'Kova', color: '#0000FF' },
        { name: 'Balık', color: '#00FFFF' }
    ];

    const createdRoles = [];
    for (const role of roles) {
        try {
            // Önce rolün var olup olmadığını kontrol et
            const existingRole = message.guild.roles.cache.find(r => r.name === role.name);
            if (!existingRole) {
                const newRole = await message.guild.roles.create({
                    name: role.name,
                    color: role.color,
                    reason: 'Rol kurulumu'
                });
                createdRoles.push(newRole);
            }
        } catch (error) {
            console.error(`${role.name} rolü oluşturulurken hata:`, error);
        }
    }

    const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('Rol Kurulumu Tamamlandı')
        .setDescription(`${createdRoles.length} rol başarıyla oluşturuldu!`)
        .addFields(
            { name: 'Renk Rolleri', value: createdRoles.filter(r => !['Koç', 'Boğa', 'İkizler', 'Yengeç', 'Aslan', 'Başak', 'Terazi', 'Akrep', 'Yay', 'Oğlak', 'Kova', 'Balık'].includes(r.name)).map(r => r.toString()).join(', ') || 'Tüm renk rolleri zaten mevcut!' },
            { name: 'Burç Rolleri', value: createdRoles.filter(r => ['Koç', 'Boğa', 'İkizler', 'Yengeç', 'Aslan', 'Başak', 'Terazi', 'Akrep', 'Yay', 'Oğlak', 'Kova', 'Balık'].includes(r.name)).map(r => r.toString()).join(', ') || 'Tüm burç rolleri zaten mevcut!' }
        );

    await message.reply({ embeds: [embed] });
}

async function logSetup(message) {
    try {
        // Log kategorisi oluştur
        const logCategory = await message.guild.channels.create({
            name: 'Nivronix Log Sistemi',
            type: ChannelType.GuildCategory,
            permissionOverwrites: [
                {
                    id: message.guild.id,
                    deny: [PermissionFlagsBits.ViewChannel]
                }
            ]
        });

        // Log kanalları oluştur
        const logChannels = [
            { name: 'Jail-log', type: ChannelType.GuildText },
            { name: 'Ban-log', type: ChannelType.GuildText },
            { name: 'Mute-log', type: ChannelType.GuildText },
            { name: 'ceza-puan-log', type: ChannelType.GuildText },
            { name: 'kayıt-log', type: ChannelType.GuildText }
        ];

        for (const channel of logChannels) {
            await message.guild.channels.create({
                name: channel.name,
                type: channel.type,
                parent: logCategory.id,
                permissionOverwrites: [
                    {
                        id: message.guild.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    }
                ]
            });
        }

        message.reply('Log kanalları başarıyla oluşturuldu!');
    } catch (error) {
        console.error('Log kanalları oluşturulurken hata:', error);
        message.reply('Log kanalları oluşturulurken bir hata oluştu!');
    }
} 