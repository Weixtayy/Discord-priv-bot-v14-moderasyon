const { AttachmentBuilder } = require('discord.js');
const canvafy = require('canvafy');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'tweet',
    description: 'Bir tweet kartı oluşturur.',
    category: 'general',
    aliases: ['tw'],
    async execute(client, message, args) {
        if (!message.guild) return;

        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.tweetChannel || message.channel.id !== settings.tweetChannel) {
            return message.reply({ content: `Bu komutu sadece <#${settings.tweetChannel}> kanalında kullanabilirsin!` });
        }

        const tweetContent = args.join(' ');
        if (!tweetContent) {
            return message.reply('Tweet içeriği belirtmelisin!');
        }

        const tweet = await new canvafy.Tweet()

            .setTheme('dark')
            .setUser({ displayName: message.member.displayName, username: message.author.username })
            .setVerified(true)
            .setComment(tweetContent)
            .setAvatar(message.author.displayAvatarURL({ extension: 'png', size: 1024 }))
            .build();

        message.reply({
            files: [{
                attachment: tweet,
                name: `tweet-${message.author.id}.png`
            }]
        });
    },
};