const { PermissionsBitField: { Flags }, ActivityType } = require('discord.js');
const canvafy = require('canvafy');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'spotify',
    aliases: ['spo'],
    category: 'General',

    execute: async (client, message, args, elweix, embed) => {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.spochannel) {
            return message.reply('Spo kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }

        if (message.channel.id !== settings.spochannel) {
            return message.reply(`Bu komutu sadece <#${settings.spochannel}> kanalında kullanabilirsin!`);
        }

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
        if (member && member.presence && member.presence.activities && member.presence.activities.some(elweix => elweix.name == 'Spotify' && elweix.type == ActivityType.Listening)) {
            const status = await member.presence.activities.find(elweix => elweix.type == ActivityType.Listening);

            const spotify = await new canvafy.Spotify()
            .setOverlayOpacity(0.7)
            .setAuthor(status.state)
            .setAlbum(status.assets.largeText)
            .setImage(`https://i.scdn.co/image/${status.assets.largeImage.slice(8)}`)
            .setTimestamp(new Date(Date.now()).getTime() - new Date(status.timestamps.start).getTime(), new Date(status.timestamps.end).getTime() - new Date(status.timestamps.start).getTime())
            .setTitle(status.details)
            .build();
             
            message.reply({
                files: [{
                    attachment: spotify,
                    name: `spotify-${message.author.id}.png`
                }]
            });

        } else return message.reply({ content: 'Kullanıcı şu anda Spotify dinlemiyor.' });
    }
}