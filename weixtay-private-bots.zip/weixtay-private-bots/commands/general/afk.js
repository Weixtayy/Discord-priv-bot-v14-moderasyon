const { EmbedBuilder } = require('discord.js');
const Settings = require('../../models/Settings');
const Afk = require('../../models/Afk');

module.exports = {
    name: 'afk',
    description: 'AFK durumuna geçmenizi sağlar.',
    category: 'general',
    async execute(client, message, args) {
        // Yetki kontrolü (AFK komutu herkes tarafından kullanılabileceği için şimdilik bir yetki kontrolü eklemiyorum.)
        
        const reason = args.join(' ') || 'Belirtilmedi';

        try {
            let afkEntry = await Afk.findOne({ userId: message.author.id, guildId: message.guild.id });

            if (afkEntry) {
                return message.reply('Zaten AFK durumundasınız!');
            }

            const oldNickname = message.member.nickname;
            let newNickname = `[AFK] ${message.member.displayName}`;

            if (newNickname.length > 32) {
                newNickname = `[AFK] ${message.author.username}`.slice(0, 32);
            }

            await message.member.setNickname(newNickname).catch(err => {
                console.error('Kullanıcı adı değiştirilemedi:', err);
                message.channel.send('AFK durumuna geçildi ancak kullanıcı adınız değiştirilemedi.');
            });

            afkEntry = new Afk({
                userId: message.author.id,
                guildId: message.guild.id,
                reason: reason,
                oldNickname: oldNickname
            });
            await afkEntry.save();

            const afkEmbed = new EmbedBuilder()
                .setColor('#FFD700')
                .setDescription(`${message.author} adlı kullanıcı ${reason === 'Belirtilmedi' ? 'AFK durumuna geçti.' : `\`${reason}\` sebebiyle AFK durumuna geçti.`}`);
            
            message.channel.send({ embeds: [afkEmbed] });

        } catch (error) {
            console.error('AFK komutu hatası:', error);
            message.reply('AFK durumuna geçilirken bir hata oluştu!');
        }
    },
}; 