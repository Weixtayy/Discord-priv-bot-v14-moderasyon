const { AttachmentBuilder } = require('discord.js');
const Level = require('../../models/Level');
const Settings = require('../../models/Settings');
const { createLevelCard } = require('../../utils/levelSystem');

module.exports = {
    name: 'level',
    description: 'Seviye ve XP bilgini gösterir',
    aliases: ['seviye', 'lvl'],
    category: 'general',
    async execute(client, message, args, config) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const user = message.mentions.members.first() || message.member;
        let levelData = await Level.findOne({ userId: user.id, guildId: message.guild.id });
        if (!levelData) {
            levelData = new Level({ userId: user.id, guildId: message.guild.id });
            await levelData.save();
        }
        const card = await createLevelCard({
            user,
            levelData
        });
        message.channel.send({ content: `${user}, işte seviye kartın!`, files: [card] });
    }
}; 