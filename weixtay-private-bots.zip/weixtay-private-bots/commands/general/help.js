const { ActionRowBuilder, StringSelectMenuBuilder, AttachmentBuilder, ComponentType, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');
const Settings = require('../../models/Settings');

// Kategori kutusu çizim fonksiyonu (tek bir fonksiyonla genel kullanım)
const drawCommandsBox = async (guildName, categoryName, commands, currentPage = 0, config, maxBoxesPerRow, initialBoxX) => {
    const commandsPerPage = maxBoxesPerRow * 3; // Örneğin: 3 sütun için 3x3=9, 4 sütun için 4x3=12 komut
    const totalPages = Math.ceil(commands.length / commandsPerPage);
    const startIndex = currentPage * commandsPerPage;
    const currentCommands = commands.slice(startIndex, startIndex + commandsPerPage);

    const boxWidth = 320; // Kullanıcının örneğinden
    const boxHeight = 120; // Kullanıcının örneğinden
    const boxMargin = 24; // Standart boşluk

    const canvasWidth = initialBoxX * 2 + maxBoxesPerRow * boxWidth + (maxBoxesPerRow - 1) * boxMargin;
    const headerHeight = 100;
    const contentStartY = headerHeight + 20;

    const rows = Math.ceil(currentCommands.length / maxBoxesPerRow);
    const canvasHeight = contentStartY + (rows * (boxHeight + boxMargin)) + 70; // Alt bilgi için ek alan

    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');

    // Yuvarlak köşeli dikdörtgen çizmek için yardımcı fonksiyon
    const drawRoundRect = (ctx, x, y, width, height, radius) => {
        if (width < 2 * radius) radius = width / 2;
        if (height < 2 * radius) radius = height / 2;
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.arcTo(x + width, y, x + width, y + height, radius);
        ctx.arcTo(x + width, y + height, x, y + height, radius);
        ctx.arcTo(x, y + height, x, y, radius);
        ctx.arcTo(x, y, x + width, y, radius);
        ctx.closePath();
    };

    // Arka plan: top.js'den alınan gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#1A1A1A');
    gradient.addColorStop(1, '#0A0A0A');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Başlık kutusu (top.js'den alınan renk)
    ctx.fillStyle = '#1A1D20'; // top.js'den alınan kutucuk rengi
    ctx.shadowColor = 'rgba(0,0,0,0.3)';
    ctx.shadowBlur = 8;
    drawRoundRect(ctx, initialBoxX - 20, 40, canvas.width - (initialBoxX - 20) * 2, headerHeight - 40, 8);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Başlık
    ctx.font = 'bold 40px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 8;
    ctx.fillText(`${guildName} ${categoryName.charAt(0).toUpperCase() + categoryName.slice(1)} Komutları`, initialBoxX, 90);
    ctx.shadowBlur = 0;

    // Komut Grid
    for (let i = 0; i < currentCommands.length; i++) {
        const cmd = currentCommands[i];
        const col = i % maxBoxesPerRow;
        const row = Math.floor(i / maxBoxesPerRow);

        const x = initialBoxX + col * (boxWidth + boxMargin);
        const y = contentStartY + row * (boxHeight + boxMargin);

        // Card Background (top.js'den alınan alternatif renkler)
        ctx.fillStyle = col % 2 === 0 ? '#1A1D20' : '#2C2F33';
        ctx.save();
        drawRoundRect(ctx, x, y, boxWidth, boxHeight, 8);
        ctx.shadowColor = 'rgba(0,0,0,0.3)';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.restore();
        ctx.shadowBlur = 0;

        // Emoji
        const emoji = cmd.emoji || '✨';
        ctx.font = '24px Arial'; // Emoji boyutu
        ctx.fillStyle = '#FFFFFF'; // Emoji rengini beyaz yap
        ctx.textAlign = 'left';
        ctx.fillText(emoji, x + 22, y + 45); // Ayarlanmış konum

        // Komut Adı
        ctx.font = 'bold 26px Arial'; // Kullanıcının örneğinden
        ctx.fillStyle = cmd.color || '#FFFFFF'; // Komutun rengini veya beyazı kullan
        ctx.textAlign = 'left';
        // Emoji genişliğini ölçüp ismin konumunu ayarlıyoruz
        const emojiWidth = ctx.measureText(emoji).width;
        ctx.fillText(`${config.prefix}${cmd.name}`, x + 22 + emojiWidth + 8, y + 45);

        // Komut Açıklaması (satır kaydırmalı)
        ctx.font = '20px Arial'; // Kullanıcının örneğinden
        ctx.fillStyle = '#B9BBBE'; // Kullanıcının örneğinden
        const descriptionText = cmd.description || 'Açıklama yok.';
        const descMaxWidth = boxWidth - 44; // Padding, kullanıcının örneğinden
        const words = descriptionText.split(' ');
        let line = '';
        let lines = [];
        for (let n = 0; n < words.length; n++) {
            let testLine = line + words[n] + ' ';
            let metrics = ctx.measureText(testLine);
            let testWidth = metrics.width;
            if (testWidth > descMaxWidth && n > 0) {
                lines.push(line.trim());
                line = words[n] + ' ';
            } else {
                line = testLine;
            }
        }
        lines.push(line.trim());
        // Her satırı kutu içinde alt alta yaz
        let descY = y + 85; // Kullanıcının örneğinden
        for (let i = 0; i < lines.length; i++) {
            ctx.fillText(lines[i], x + 22, descY + i * 24); // Satır yüksekliği 24 (kullanıcının örneğinden)
        }
    }

    // Sayfa Numaraları
    ctx.font = '20px Arial';
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.fillText(`Sayfa ${currentPage + 1} / ${totalPages}`, canvas.width / 2, canvasHeight - 30);

    return new AttachmentBuilder(canvas.toBuffer('image/png'), { name: 'help_commands.png' });
};


module.exports = {
    name: 'yardım',
    description: 'Botun komutlarını kategoriye göre listeler.',
    aliases: ['help', 'komutlar'],
    async execute(client, message, args, config) {
        if (!message.guild) {
            return;
        }

        const settings = await Settings.findOne({ guildId: message.guild.id });
        // Kanal kontrolü
        if (settings && settings.commandChannel && message.channel.id !== settings.commandChannel) {
            return message.reply({
                content: `Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsiniz.`
            });
        }

        const allCommands = client.commands;
        const categories = [...new Set(allCommands.map(cmd => cmd.category))].filter(Boolean).sort();

        // Varsayılan kategori
        let defaultCategory = categories.includes('general') ? 'general' : categories[0] || null;
        if (!defaultCategory && categories.length === 0) {
            return message.reply('Hiç komut bulunamadı veya kategorilendirilmedi.');
        }

        // Argüman olarak belirtilen kategori varsa onu kullan
        if (args[0] && categories.includes(args[0].toLowerCase())) {
            defaultCategory = args[0].toLowerCase();
        }

        let currentCategory = defaultCategory;
        let currentPage = 0;

        const commandsForCategory = Array.from(allCommands.filter(cmd => cmd.category === currentCategory).values());

        // Kategori tipine göre canvas boyutlarını belirle
        let canvasParams = {};
        if (currentCategory === 'auth') { // 'auth' kategorisi için 3 sütunlu ("Kurucu Komutları" örneği)
            canvasParams = { maxBoxesPerRow: 3, initialBoxX: 80 };
        } else { // Diğer kategoriler için 4 sütunlu ("Kullanıcı Komutları" örneği)
            canvasParams = { maxBoxesPerRow: 4, initialBoxX: 80 };
        }

        const attachment = await drawCommandsBox(message.guild.name, currentCategory, commandsForCategory, currentPage, config, canvasParams.maxBoxesPerRow, canvasParams.initialBoxX);

        // Select menü oluştur
        const selectMenuOptions = categories.map(cat => ({
            label: cat.charAt(0).toUpperCase() + cat.slice(1),
            value: cat,
            default: cat === currentCategory,
        }));

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('help_category_select')
            .setPlaceholder('Kategori Seçin...')
            .addOptions(selectMenuOptions);

        // Sayfa navigasyon butonları
        const prevButton = new ButtonBuilder()
            .setCustomId('help_prev_page')
            .setLabel('◀️ Önceki')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === 0);

        const nextButton = new ButtonBuilder()
            .setCustomId('help_next_page')
            .setLabel('Sonraki ▶️')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage >= Math.ceil(commandsForCategory.length / (canvasParams.maxBoxesPerRow * 3)) - 1);

        const selectRow = new ActionRowBuilder().addComponents(selectMenu);
        const buttonRow = new ActionRowBuilder().addComponents(prevButton, nextButton);

        const replyMessage = await message.reply({
            files: [attachment],
            components: [selectRow, buttonRow],
            ephemeral: false
        });

        const collector = replyMessage.createMessageComponentCollector({
            time: 60000 // 60 saniye boyunca dinle
        });

        collector.on('collect', async i => {
            if (i.customId === 'help_category_select') {
                currentCategory = i.values[0];
                currentPage = 0; // Kategori değişince sayfayı sıfırla
                const newCommandsForCategory = Array.from(allCommands.filter(cmd => cmd.category === currentCategory).values());

                // Kategori tipine göre canvas boyutlarını tekrar belirle
                let newCanvasParams = {};
                if (currentCategory === 'auth') {
                    newCanvasParams = { maxBoxesPerRow: 3, initialBoxX: 80 };
                } else {
                    newCanvasParams = { maxBoxesPerRow: 4, initialBoxX: 80 };
                }

                const newAttachment = await drawCommandsBox(message.guild.name, currentCategory, newCommandsForCategory, currentPage, config, newCanvasParams.maxBoxesPerRow, newCanvasParams.initialBoxX);
                
                // Select menüyü güncelle
                const updatedSelectMenu = new StringSelectMenuBuilder()
                    .setCustomId('help_category_select')
                    .setPlaceholder('Kategori Seçin...')
                    .addOptions(categories.map(cat => ({
                        label: cat.charAt(0).toUpperCase() + cat.slice(1),
                        value: cat,
                        default: cat === currentCategory,
                    })));

                // Butonları güncelle
                const updatedPrevButton = new ButtonBuilder()
                    .setCustomId('help_prev_page')
                    .setLabel('◀️ Önceki')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === 0);

                const updatedNextButton = new ButtonBuilder()
                    .setCustomId('help_next_page')
                    .setLabel('Sonraki ▶️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage >= Math.ceil(newCommandsForCategory.length / (newCanvasParams.maxBoxesPerRow * 3)) - 1);

                const updatedSelectRow = new ActionRowBuilder().addComponents(updatedSelectMenu);
                const updatedButtonRow = new ActionRowBuilder().addComponents(updatedPrevButton, updatedNextButton);

                await i.update({
                    files: [newAttachment],
                    components: [updatedSelectRow, updatedButtonRow]
                });
            } else if (i.customId === 'help_prev_page') {
                if (currentPage > 0) {
                    currentPage--;
                    const commandsForCategory = Array.from(allCommands.filter(cmd => cmd.category === currentCategory).values());
                    
                    let canvasParams = {};
                    if (currentCategory === 'auth') {
                        canvasParams = { maxBoxesPerRow: 3, initialBoxX: 80 };
                    } else {
                        canvasParams = { maxBoxesPerRow: 4, initialBoxX: 80 };
                    }

                    const newAttachment = await drawCommandsBox(message.guild.name, currentCategory, commandsForCategory, currentPage, config, canvasParams.maxBoxesPerRow, canvasParams.initialBoxX);
                    
                    // Butonları güncelle
                    const updatedPrevButton = new ButtonBuilder()
                        .setCustomId('help_prev_page')
                        .setLabel('◀️ Önceki')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage === 0);

                    const updatedNextButton = new ButtonBuilder()
                        .setCustomId('help_next_page')
                        .setLabel('Sonraki ▶️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage >= Math.ceil(commandsForCategory.length / (canvasParams.maxBoxesPerRow * 3)) - 1);

                    const updatedButtonRow = new ActionRowBuilder().addComponents(updatedPrevButton, updatedNextButton);

                    await i.update({
                        files: [newAttachment],
                        components: [selectRow, updatedButtonRow]
                    });
                }
            } else if (i.customId === 'help_next_page') {
                const commandsForCategory = Array.from(allCommands.filter(cmd => cmd.category === currentCategory).values());
                let canvasParams = {};
                if (currentCategory === 'auth') {
                    canvasParams = { maxBoxesPerRow: 3, initialBoxX: 80 };
                } else {
                    canvasParams = { maxBoxesPerRow: 4, initialBoxX: 80 };
                }
                
                const maxPages = Math.ceil(commandsForCategory.length / (canvasParams.maxBoxesPerRow * 3));
                if (currentPage < maxPages - 1) {
                    currentPage++;
                    const newAttachment = await drawCommandsBox(message.guild.name, currentCategory, commandsForCategory, currentPage, config, canvasParams.maxBoxesPerRow, canvasParams.initialBoxX);
                    
                    // Butonları güncelle
                    const updatedPrevButton = new ButtonBuilder()
                        .setCustomId('help_prev_page')
                        .setLabel('◀️ Önceki')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage === 0);

                    const updatedNextButton = new ButtonBuilder()
                        .setCustomId('help_next_page')
                        .setLabel('Sonraki ▶️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage >= maxPages - 1);

                    const updatedButtonRow = new ActionRowBuilder().addComponents(updatedPrevButton, updatedNextButton);

                    await i.update({
                        files: [newAttachment],
                        components: [selectRow, updatedButtonRow]
                    });
                }
            }
        });

        collector.on('end', () => {
            const disabledSelectMenu = selectMenu.setDisabled(true);
            const disabledPrevButton = prevButton.setDisabled(true);
            const disabledNextButton = nextButton.setDisabled(true);
            
            const disabledSelectRow = new ActionRowBuilder().addComponents(disabledSelectMenu);
            const disabledButtonRow = new ActionRowBuilder().addComponents(disabledPrevButton, disabledNextButton);
            
            replyMessage.edit({ components: [disabledSelectRow, disabledButtonRow] }).catch(console.error);
        });
    },
};