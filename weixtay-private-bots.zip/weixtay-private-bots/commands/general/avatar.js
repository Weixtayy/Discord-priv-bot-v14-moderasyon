const { EmbedBuilder } = require('discord.js');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'avatar',
    aliases: ['av'],
    category: 'general',
    execute: async (client, message, args) => {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (settings?.commandChannel && message.channel.id !== settings.commandChannel) {
            return message.reply({ content: `Bu komut sadece <#${settings.commandChannel}> kanalında kullanılabilir.` }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
        }

        const member = message.mentions.users.first() || (args[0] ? await client.users.fetch(args[0]).catch(() => null) : null) || message.author;
        if (!member) return message.channel.send({ content: 'Bir kullanıcı belirtmelisin.' }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));

        message.channel.send({
            embeds: [
                new EmbedBuilder()
                    .setAuthor({ name: `${member.username}`, iconURL: member.displayAvatarURL({ dynamic: true }) })
                    .setImage(member.displayAvatarURL({ dynamic: true, size: 4096 }))
            ]
        });
    }
}; 