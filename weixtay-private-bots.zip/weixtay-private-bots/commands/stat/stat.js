const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, InteractionType } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const UserStats = require('../../models/UserStats');
const Settings = require('../../models/Settings');
const CezaPuan = require('../../models/CezaPuan');

// Süreleri okunabilir hale getirme fonksiyonu (dışarı taşıdık)
const formatDuration = (ms) => {
    if (ms === 0) return '0 saniye';
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));

    const parts = [];
    if (days > 0) parts.push(`${days} gün`);
    if (hours > 0) parts.push(`${hours} saat`);
    if (minutes > 0) parts.push(`${minutes} dakika`);
    if (seconds > 0) parts.push(`${seconds} saniye`);

    return parts.length > 0 ? parts.join(' ') : '0 saniye';
};

// Zaman dilimi etiketlerini Türkçeye çevirme fonksiyonu
const translateTimePeriod = (period) => {
    switch (period) {
        case 'daily': return 'Günlük - Veriler';
        case 'weekly': return 'Haftalık - Veriler';
        case 'monthly': return 'Aylık - Veriler';
        case 'total': return 'Toplam - Veriler';
        default: return '';
    }
};

module.exports = {
    name: 'stat',
    description: 'Bir kullanıcının istatistiklerini gösterir',
    async execute(client, context, args, config) {
        let replyTarget;
        let targetUser;
        let timePeriod = 'total'; // Varsayılan olarak toplam istatistikler

        if (context.type === InteractionType.ApplicationCommand) {
            replyTarget = context;
            targetUser = context.options.getUser('kullanıcı') || context.user;
            timePeriod = 'total';
        } else if (context.type === InteractionType.MessageComponent && context.isButton()) {
            await context.deferUpdate(); // Defer the button update immediately
            replyTarget = context;
            const customIdParts = context.customId.split('-');
            timePeriod = customIdParts[1];
            targetUser = await client.users.fetch(customIdParts[2]);
        } else if (context.guild) { // It's a message command
            replyTarget = context;
            if (args[0]) {
                if (['daily', 'weekly', 'monthly', 'total'].includes(args[0].toLowerCase())) {
                    timePeriod = args[0].toLowerCase();
                    targetUser = context.author; // Kendi istatistiklerine bakıyor
                } else {
                    if (!context.member.permissions.has('Administrator')) {
                        return context.reply('Sadece yöneticiler başka bir kullanıcının istatistiklerini görüntüleyebilir.');
                    }
                    targetUser = context.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
                    if (!targetUser) {
                        return context.reply('Geçerli bir kullanıcı etiketleyin veya ID girin!');
                    }
                }
            } else {
                targetUser = context.author;
            }
        } else {
            // Handle cases where it's neither a guild message nor an interaction (e.g., DM command which is not supported)
            if (context.isRepliable) {
                await context.reply('Bu komut sadece sunucularda kullanılabilir!');
            } else {
                console.warn("Unsupported context type in stat.js:", context);
            }
            return;
        }

        // Guild kontrolü
        if (!replyTarget.guild) {
            if (replyTarget.isRepliable) {
                await replyTarget.reply({ content: 'Bu komut sadece sunucularda kullanılabilir!', ephemeral: true });
            } else {
                console.warn("Cannot reply to non-repliable context outside of guild:", replyTarget);
            }
            return;
        }

        // Komut kanalı kontrolü
        const settings = await Settings.findOne({ id: replyTarget.guild.id });
        if (!settings || !settings.commandChannel) {
            return replyTarget.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }

        if (replyTarget.channel.id !== settings.commandChannel) {
            return replyTarget.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const targetMember = replyTarget.guild.members.cache.get(targetUser.id);

        if (!targetMember) {
            return replyTarget.reply('Belirtilen kullanıcı sunucuda bulunamadı!');
        }

        let userStats = await UserStats.findOne({ userId: targetUser.id, guildId: replyTarget.guild.id });

        if (!userStats) {
            userStats = new UserStats({ userId: targetUser.id, guildId: replyTarget.guild.id });
            await userStats.save();
        }

        // Ceza puanını al
        let cezaPuan = await CezaPuan.findOne({ userId: targetUser.id, guildId: replyTarget.guild.id });
        if (!cezaPuan) {
            cezaPuan = new CezaPuan({ userId: targetUser.id, guildId: replyTarget.guild.id });
            await cezaPuan.save();
        }

        const getStatsForPeriod = (period) => {
            switch (period) {
                case 'daily':
                    return {
                        voiceTime: userStats.dailyVoiceTime || 0,
                        messageCount: userStats.dailyMessageCount || 0,
                        cameraTime: userStats.dailyCameraTime || 0,
                        streamingTime: userStats.dailyStreamingTime || 0
                    };
                case 'weekly':
                    return {
                        voiceTime: userStats.weeklyVoiceTime || 0,
                        messageCount: userStats.weeklyMessageCount || 0,
                        cameraTime: userStats.weeklyCameraTime || 0,
                        streamingTime: userStats.weeklyStreamingTime || 0
                    };
                case 'monthly':
                    return {
                        voiceTime: userStats.monthlyVoiceTime || 0,
                        messageCount: userStats.monthlyMessageCount || 0,
                        cameraTime: userStats.monthlyCameraTime || 0,
                        streamingTime: userStats.monthlyStreamingTime || 0
                    };
                case 'total':
                default:
                    return {
                        voiceTime: userStats.voiceTime || 0,
                        messageCount: userStats.messageCount || 0,
                        cameraTime: userStats.cameraTime || 0,
                        streamingTime: userStats.streamingTime || 0
                    };
            }
        };

        const currentStats = getStatsForPeriod(timePeriod);

        const statsData = [
            { label: 'Sesli Kanal', value: formatDuration(currentStats.voiceTime), color: '#5865F2' },
            { label: 'Mesaj', value: currentStats.messageCount.toLocaleString(), color: '#fff' },
            { label: 'Kamera', value: formatDuration(currentStats.cameraTime), color: '#43b581' },
            { label: 'Yayın', value: formatDuration(currentStats.streamingTime), color: '#f04747' },
            { label: 'Davet', value: (userStats.invites || 0).toString(), color: 'gold' },
            { label: 'Ceza Puanı', value: `${cezaPuan.totalPoints}/300`, color: cezaPuan.totalPoints >= 300 ? '#ff0000' : '#ff6b6b' },
        ];

        // Canvas oluşturma - Modern tasarım
        const width = 1000;
        const height = 600;
        const canvas = createCanvas(width, height);
        const ctx = canvas.getContext('2d');

        // Modern arka plan: Gradient
        const bgGradient = ctx.createLinearGradient(0, 0, width, height);
        bgGradient.addColorStop(0, '#0F0F23'); // Koyu mavi-siyah
        bgGradient.addColorStop(0.5, '#1A1A2E'); // Orta mavi-siyah
        bgGradient.addColorStop(1, '#16213E'); // Açık mavi-siyah
        ctx.fillStyle = bgGradient;
        ctx.fillRect(0, 0, width, height);

        // Dekoratif çizgiler
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        for (let i = 0; i < 5; i++) {
            ctx.beginPath();
            ctx.moveTo(0, 120 + i * 100);
            ctx.lineTo(width, 120 + i * 100);
            ctx.stroke();
        }

        // Kullanıcı bilgi kartı - Modern tasarım
        const userCardGradient = ctx.createLinearGradient(20, 20, width - 20, 20);
        userCardGradient.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
        userCardGradient.addColorStop(1, 'rgba(255, 255, 255, 0.05)');
        
        // Kullanıcı kartı arka planı
        ctx.save();
        ctx.beginPath();
        ctx.roundRect(20, 20, width - 40, 120, 20);
        ctx.fillStyle = userCardGradient;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
        ctx.shadowBlur = 20;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.restore();

        // Kullanıcı avatarı - Modern çerçeve
        const avatar = await loadImage(targetUser.displayAvatarURL({ extension: 'png', size: 256 }));
        ctx.save();
        
        // Avatar için gradient çerçeve
        const avatarGradient = ctx.createRadialGradient(80, 80, 0, 80, 80, 50);
        avatarGradient.addColorStop(0, '#00D4FF');
        avatarGradient.addColorStop(0.5, '#0099CC');
        avatarGradient.addColorStop(1, '#006699');
        
        ctx.beginPath();
        ctx.arc(80, 80, 50, 0, Math.PI * 2);
        ctx.fillStyle = avatarGradient;
        ctx.fill();
        
        // Avatar
        ctx.beginPath();
        ctx.arc(80, 80, 45, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(avatar, 35, 35, 90, 90);
        ctx.restore();

        // Kullanıcı bilgileri - Modern tasarım
        ctx.font = 'bold 32px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(targetUser.username, 160, 70);
        
        // Kullanıcı ID'si
        ctx.font = '16px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#8E8E93';
        ctx.fillText(`ID: ${targetUser.id}`, 160, 95);
        
        // Zaman dilimi
        ctx.font = 'bold 18px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#00D4FF';
        ctx.fillText(translateTimePeriod(timePeriod), 160, 115);

        // Dekoratif çizgi
        ctx.strokeStyle = 'rgba(0, 212, 255, 0.3)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(160, 125);
        ctx.lineTo(width - 40, 125);
        ctx.stroke();

        // Modern istatistik kartı fonksiyonu
        function drawStatBox(c, x, y, width, height, radius, title, value, color) {
            c.save();
            
            // Kart arka planı - Glassmorphism efekti
            const cardGradient = c.createLinearGradient(x, y, x + width, y + height);
            cardGradient.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
            cardGradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.05)');
            cardGradient.addColorStop(1, 'rgba(255, 255, 255, 0.02)');
            
            c.fillStyle = cardGradient;
            c.shadowColor = 'rgba(0, 0, 0, 0.2)';
            c.shadowBlur = 15;
            c.beginPath();
            c.roundRect(x, y, width, height, radius);
            c.fill();
            c.shadowBlur = 0;
            
            // Kart kenarlığı
            c.strokeStyle = 'rgba(255, 255, 255, 0.2)';
            c.lineWidth = 1;
            c.stroke();
            
            // Özel renk efektleri
            if (color === 'gold') {
                // Davet için altın efekti
                const goldGradient = c.createLinearGradient(x, y, x + width, y + height);
                goldGradient.addColorStop(0, 'rgba(255, 215, 0, 0.3)');
                goldGradient.addColorStop(1, 'rgba(255, 215, 0, 0.1)');
                c.fillStyle = goldGradient;
                c.fill();
            } else if (color === '#ff0000' || color === '#ff6b6b') {
                // Ceza puanı için kırmızı efekt
                const redGradient = c.createLinearGradient(x, y, x + width, y + height);
                redGradient.addColorStop(0, 'rgba(255, 0, 0, 0.2)');
                redGradient.addColorStop(1, 'rgba(255, 0, 0, 0.05)');
                c.fillStyle = redGradient;
                c.fill();
            }
            
            // Başlık
            c.font = 'bold 18px "Segoe UI", Arial, sans-serif';
            c.fillStyle = '#FFFFFF';
            c.textAlign = 'left';
            c.fillText(title, x + 20, y + 30);
            
            // Değer
            c.font = 'bold 24px "Segoe UI", Arial, sans-serif';
            
            // Renk kodlaması
            if (color === 'gold') {
                c.fillStyle = '#FFD700';
            } else if (color === '#ff0000' || color === '#ff6b6b') {
                c.fillStyle = color;
            } else {
                c.fillStyle = color;
            }
            
            c.textAlign = 'right';
            c.fillText(value, x + width - 20, y + 55);
            
            c.restore();
        }

        // İstatistik kartlarını çiz - 3x2 grid layout
        const cardWidth = 300;
        const cardHeight = 90;
        const cardPadding = 25;
        const startY = 160;
        const cardsPerRow = 3;
        
        for (let i = 0; i < statsData.length; i++) {
            const stat = statsData[i];
            const row = Math.floor(i / cardsPerRow);
            const col = i % cardsPerRow;
            const x = 30 + col * (cardWidth + cardPadding);
            const y = startY + row * (cardHeight + cardPadding);
            drawStatBox(ctx, x, y, cardWidth, cardHeight, 16, stat.label, stat.value, stat.color);
        }

        // Alt bilgi kartı - Modern tasarım
        const infoCardGradient = ctx.createLinearGradient(20, height - 100, width - 20, height - 100);
        infoCardGradient.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
        infoCardGradient.addColorStop(1, 'rgba(255, 255, 255, 0.05)');
        
        ctx.save();
        ctx.beginPath();
        ctx.roundRect(20, height - 100, width - 40, 80, 20);
        ctx.fillStyle = infoCardGradient;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
        ctx.shadowBlur = 15;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.restore();
        
        // Kenarlık
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.stroke();
        
        // Katılma tarihi
        ctx.font = 'bold 18px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'center';
        const memberJoinDate = targetMember.joinedAt ? targetMember.joinedAt.toLocaleDateString('tr-TR', { year: 'numeric', month: 'long', day: 'numeric' }) : 'Bilinmiyor';
        ctx.fillText(`Sunucuya Katılma Tarihi: ${memberJoinDate}`, width / 2, height - 70);
        
        // Hesap oluşturma tarihi
        ctx.font = '16px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#8E8E93';
        const accountCreated = targetUser.createdAt.toLocaleDateString('tr-TR', { year: 'numeric', month: 'long', day: 'numeric' });
        ctx.fillText(`Hesap Oluşturma: ${accountCreated}`, width / 2, height - 45);

        // Sağ üst köşeye modern imza
        ctx.save();
        ctx.font = 'bold 20px "Segoe UI", Arial, sans-serif';
        const signatureGradient = ctx.createLinearGradient(width - 200, 30, width - 20, 30);
        signatureGradient.addColorStop(0, '#00D4FF');
        signatureGradient.addColorStop(1, '#FFD700');
        ctx.fillStyle = signatureGradient;
        ctx.textAlign = 'right';
        ctx.globalAlpha = 0.9;
        ctx.fillText('By Nivroth', width - 30, 50);
        ctx.restore();

        // Butonları oluştur
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`stat-total-${targetUser.id}`)
                    .setLabel('Anasayfa')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(timePeriod === 'total'),
                new ButtonBuilder()
                    .setCustomId(`stat-daily-${targetUser.id}`)
                    .setLabel('Günlük')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(timePeriod === 'daily'),
                new ButtonBuilder()
                    .setCustomId(`stat-weekly-${targetUser.id}`)
                    .setLabel('Haftalık')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(timePeriod === 'weekly'),
                new ButtonBuilder()
                    .setCustomId(`stat-monthly-${targetUser.id}`)
                    .setLabel('Aylık')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(timePeriod === 'monthly'),
                new ButtonBuilder()
                    .setCustomId('nivroth-bots')
                    .setLabel('Nivroth Bots')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
            );

        const buffer = canvas.toBuffer();
        const attachment = new AttachmentBuilder(buffer, { name: 'user_stats.png' });

        if (replyTarget.isRepliable) {
            // Check if the interaction has already been replied to or deferred
            if (replyTarget.deferred || replyTarget.replied) {
                await replyTarget.editReply({ files: [attachment], components: [row] });
            } else {
                await replyTarget.reply({ files: [attachment], components: [row] });
            }
        } else {
            await replyTarget.reply({ files: [attachment], components: [row] }); // Use reply for messages
        }
    },
};
