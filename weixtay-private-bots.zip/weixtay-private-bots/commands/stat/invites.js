const { EmbedBuilder } = require('discord.js');
const UserStats = require('../../models/UserStats');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'invites',
    description: 'Kullanıcının davet istatistiklerini gösterir',
    aliases: ['davet', 'davetler'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }

        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const targetUser = message.mentions.users.first() || 
                          (args[0] ? await client.users.fetch(args[0]).catch(() => null) : message.author);

        if (!targetUser) {
            return message.reply('Geçerli bir kullanıcı etiketleyin veya ID girin!');
        }

        const userStats = await UserStats.findOne({ 
            userId: targetUser.id, 
            guildId: message.guild.id 
        });

        const inviteCount = userStats ? userStats.invites : 0;
        const invitedUsers = userStats ? userStats.invitedUsers : [];

        // Davet edilen kullanıcıların durumunu kontrol et
        const activeInvites = [];
        const leftInvites = [];

        for (const invitedUserId of invitedUsers) {
            const member = message.guild.members.cache.get(invitedUserId);
            if (member) {
                activeInvites.push(invitedUserId);
            } else {
                leftInvites.push(invitedUserId);
            }
        }

        // Bu kullanıcının kim tarafından davet edildiğini göster
        let invitedBy = null;
        let inviteCode = null;
        if (userStats && userStats.lastInvitedBy) {
            const inviterMember = message.guild.members.cache.get(userStats.lastInvitedBy);
            if (inviterMember) {
                invitedBy = inviterMember;
            }
            inviteCode = userStats.lastInviteCode;
        }

        const embed = new EmbedBuilder()
            .setTitle('🎯 Davet İstatistikleri')
            .setDescription(`${targetUser} kullanıcısının davet istatistikleri`)
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
            .setColor(0x00ff00)
            .addFields(
                { name: '📊 Toplam Davet', value: inviteCount.toString(), inline: true },
                { name: '✅ Aktif Üyeler', value: activeInvites.length.toString(), inline: true },
                { name: '❌ Ayrılan Üyeler', value: leftInvites.length.toString(), inline: true }
            );

        // Eğer bu kullanıcı başka biri tarafından davet edildiyse göster
        if (invitedBy) {
            embed.addFields({
                name: '🎯 Davet Eden',
                value: `${invitedBy.user.tag} (\`${invitedBy.id}\`)`,
                inline: true
            });
            if (inviteCode) {
                embed.addFields({
                    name: '🔗 Davet Kodu',
                    value: `\`${inviteCode}\``,
                    inline: true
                });
            }
        }

        embed.setFooter({ 
            text: `${message.guild.name}`, 
            iconURL: message.guild.iconURL({ dynamic: true }) 
        })
        .setTimestamp();

        // Aktif üyelerin listesi (ilk 10 tanesi)
        if (activeInvites.length > 0) {
            const activeList = activeInvites.slice(0, 10).map(userId => {
                const member = message.guild.members.cache.get(userId);
                return `• ${member.user.tag} (\`${userId}\`)`;
            }).join('\n');
            
            embed.addFields({
                name: `✅ Aktif Üyeler (${activeInvites.length})`,
                value: activeList + (activeInvites.length > 10 ? '\n*...ve daha fazlası*' : ''),
                inline: false
            });
        }

        // Ayrılan üyelerin listesi (ilk 10 tanesi)
        if (leftInvites.length > 0) {
            const leftList = leftInvites.slice(0, 10).map(userId => {
                return `• \`${userId}\``;
            }).join('\n');
            
            embed.addFields({
                name: `❌ Ayrılan Üyeler (${leftInvites.length})`,
                value: leftList + (leftInvites.length > 10 ? '\n*...ve daha fazlası*' : ''),
                inline: false
            });
        }

        await message.reply({ embeds: [embed] });
    }
}; 