const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, InteractionType } = require('discord.js');
const { createCanvas, loadImage, registerFont } = require('canvas');
const UserStats = require('../../models/UserStats');
const Settings = require('../../models/Settings');

// Yuvarlak dikdörtgen çizme fonksiyonu
const roundRect = (c, x, y, width, height, radius) => {
    c.beginPath();
    c.moveTo(x + radius, y);
    c.arcTo(x + width, y, x + width, y + height, radius);
    c.arcTo(x + width, y + height, x, y + height, radius);
    c.arcTo(x, y + height, x, y, radius);
    c.arcTo(x, y, x + width, y, radius);
    c.closePath();
};

// Süreleri okunabilir hale getirme fonksiyonu (stat.js'den alındı)
const formatDuration = (ms) => {
    if (ms === 0) return '0 saniye';
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));

    const parts = [];
    if (days > 0) parts.push(`${days} gün`);
    if (hours > 0) parts.push(`${hours} saat`);
    if (minutes > 0) parts.push(`${minutes} dakika`);
    if (seconds > 0) parts.push(`${seconds} saniye`);

    return parts.length > 0 ? parts.join(' ') : '0 saniye';
};

module.exports = {
    name: 'top',
    description: 'Sunucudaki en iyi istatistiklere sahip kullanıcıları gösterir.',
    async execute(client, context, args, config) {
        let replyTarget;
        let statType = 'voiceTime'; // Varsayılan olarak ses süresi

        if (context.type === InteractionType.MessageComponent && context.isButton()) {
            await context.deferUpdate();
            replyTarget = context;
            const customIdParts = context.customId.split('-');
            statType = customIdParts[1];
        } else { // Mesaj komutu
            replyTarget = context;
            if (args[0] && ['voice', 'camera', 'streaming', 'message', 'invite'].includes(args[0].toLowerCase())) {
                switch (args[0].toLowerCase()) {
                    case 'voice': statType = 'voiceTime'; break;
                    case 'camera': statType = 'cameraTime'; break;
                    case 'streaming': statType = 'streamingTime'; break;
                    case 'message': statType = 'messageCount'; break;
                    case 'invite': statType = 'invites'; break;
                }
            }
        }

        if (!replyTarget.guild) {
            const isInteraction = replyTarget.type === InteractionType.ApplicationCommand || replyTarget.type === InteractionType.MessageComponent;
            if (replyTarget.isRepliable) {
                await replyTarget.reply({ content: 'Bu komut sadece sunucularda kullanılabilir!', ephemeral: isInteraction });
            } else {
                console.warn("Cannot reply to non-repliable context outside of guild:", replyTarget);
            }
            return;
        }

        // Komut kanalı kontrolü
        const settings = await Settings.findOne({ id: replyTarget.guild.id });
        if (!settings || !settings.commandChannel) {
            return replyTarget.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }

        if (replyTarget.channel.id !== settings.commandChannel) {
            return replyTarget.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const allUserStats = await UserStats.find({ guildId: replyTarget.guild.id });

        let sortedStats = [];
        let filteredStats = allUserStats.filter(stat => {
            if (statType === 'invites') {
                return (stat.invites || 0) > 0;
            }
            return (stat[statType] || 0) > 0;
        });

        switch (statType) {
            case 'voiceTime':
                sortedStats = filteredStats.sort((a, b) => (b.voiceTime || 0) - (a.voiceTime || 0));
                break;
            case 'cameraTime':
                sortedStats = filteredStats.sort((a, b) => (b.cameraTime || 0) - (a.cameraTime || 0));
                break;
            case 'streamingTime':
                sortedStats = filteredStats.sort((a, b) => (b.streamingTime || 0) - (a.streamingTime || 0));
                break;
            case 'messageCount':
                sortedStats = filteredStats.sort((a, b) => (b.messageCount || 0) - (a.messageCount || 0));
                break;
            case 'invites':
                sortedStats = filteredStats.sort((a, b) => (b.invites || 0) - (a.invites || 0));
                break;
        }

        const top10Stats = sortedStats.slice(0, 10);

        const width = 1000;
        const height = 650; 
        const canvas = createCanvas(width, height);
        const ctx = canvas.getContext('2d');

        // Arka Plan (Modern Gradient + Soft Blur Spotlights)
        const bgGradient = ctx.createLinearGradient(0, 0, width, height);
        bgGradient.addColorStop(0, '#23243a');
        bgGradient.addColorStop(1, '#2e2244');
        ctx.fillStyle = bgGradient;
        ctx.fillRect(0, 0, width, height);
        // Soft blur spotlights
        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.filter = 'blur(32px)';
        ctx.beginPath(); ctx.arc(220, 120, 90, 0, Math.PI*2); ctx.fillStyle = '#b68cff'; ctx.fill();
        ctx.beginPath(); ctx.arc(700, 200, 110, 0, Math.PI*2); ctx.fillStyle = '#00eaff'; ctx.fill();
        ctx.beginPath(); ctx.arc(500, 400, 120, 0, Math.PI*2); ctx.fillStyle = '#ff5ccf'; ctx.fill();
        ctx.filter = 'none';
        ctx.globalAlpha = 1;
        ctx.restore();
        // Dış canvas çerçevesi (radiuslu, gradientli, ince ve modern)
        ctx.save();
        ctx.lineWidth = 3;
        const outerGrad = ctx.createLinearGradient(0, 0, width, height);
        outerGrad.addColorStop(0, '#00eaff');
        outerGrad.addColorStop(0.5, '#b68cff');
        outerGrad.addColorStop(1, '#ff5ccf');
        ctx.strokeStyle = outerGrad;
        ctx.beginPath();
        ctx.moveTo(20, 10);
        ctx.lineTo(width-20, 10);
        ctx.quadraticCurveTo(width-10, 10, width-10, 20);
        ctx.lineTo(width-10, height-20);
        ctx.quadraticCurveTo(width-10, height-10, width-20, height-10);
        ctx.lineTo(20, height-10);
        ctx.quadraticCurveTo(10, height-10, 10, height-20);
        ctx.lineTo(10, 20);
        ctx.quadraticCurveTo(10, 10, 20, 10);
        ctx.closePath();
        ctx.stroke();
        ctx.restore();

        // Header Bölgesi
        const headerY = 40;
        // Sunucu İkonu ve Adı (yanyana)
        const serverIcon = await loadImage(replyTarget.guild.iconURL({ extension: 'png', size: 128 }));
        const iconSize = 60;
        const iconX = 60;
        const iconY = headerY;
        ctx.save();
        ctx.beginPath();
        ctx.arc(iconX + iconSize/2, iconY + iconSize/2, iconSize/2, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(serverIcon, iconX, iconY, iconSize, iconSize);
        ctx.restore();
        // Sunucu ikonu çerçevesi (canlı gradient)
        ctx.beginPath();
        ctx.arc(iconX + iconSize/2, iconY + iconSize/2, iconSize/2, 0, Math.PI * 2, true);
        const iconGrad = ctx.createLinearGradient(iconX, iconY, iconX+iconSize, iconY+iconSize);
        iconGrad.addColorStop(0, '#00eaff');
        iconGrad.addColorStop(1, '#ff5ccf');
        ctx.strokeStyle = iconGrad;
        ctx.lineWidth = 3;
        ctx.stroke();
        // Sunucu adı (ikonun sağında, büyük ve kalın)
        ctx.font = 'bold 32px Arial';
        ctx.textAlign = 'left';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(replyTarget.guild.name, iconX + iconSize + 20, iconY + iconSize/2 + 10);
        // Başlık (örn. Mesaj Sıralaması) - ortalanmış, ikon ve isimden aşağıda
        const titleY = iconY + iconSize + 40;
        ctx.font = 'bold 40px Arial';
        ctx.textAlign = 'center';
        // Modern gradient başlık rengi
        const titleGrad = ctx.createLinearGradient(width/2-100, titleY, width/2+100, titleY+40);
        titleGrad.addColorStop(0, '#00eaff');
        titleGrad.addColorStop(1, '#ff5ccf');
        ctx.fillStyle = titleGrad;
        const rankingTitle = {
            'voiceTime': 'Ses Sıralaması',
            'cameraTime': 'Kamera Sıralaması',
            'streamingTime': 'Yayın Sıralaması',
            'messageCount': 'Mesaj Sıralaması',
            'invites': 'Davet Sıralaması'
        }[statType] || 'Sıralama';
        ctx.fillText(rankingTitle, width / 2, titleY);
        // Başlık Altı Çizgi
        ctx.strokeStyle = '#FFD700';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(50, titleY + 15);
        ctx.lineTo(width - 50, titleY + 15);
        ctx.stroke();
        // Kullanıcı kutuları (1-5 solda, 6-10 sağda)
        const startY = titleY + 40;
        const rowHeight = 80;
        const avatarSize = 45;
        const avatarRadius = avatarSize / 2;
        const boxWidth = 420;
        const leftX = 70;
        const rightX = width/2 + 30;
        for (let i = 0; i < top10Stats.length; i++) {
            const statEntry = top10Stats[i];
            const user = await client.users.fetch(statEntry.userId).catch(() => null);
            if (!user) continue;
            // 0-4 arası solda, 5-9 arası sağda
            const col = i < 5 ? 0 : 1;
            const row = col === 0 ? i : i - 5;
            const boxX = col === 0 ? leftX : rightX;
            const y = startY + row * rowHeight;

            // --- MODERN HANE KART TASARIMI (altınsız, kart gibi) ---
            // Kart arka planı (daha şeffaf)
            ctx.save();
            ctx.beginPath();
            roundRect(ctx, boxX, y, boxWidth, rowHeight - 10, 18);
            ctx.closePath();
            ctx.globalAlpha = 0.48;
            ctx.fillStyle = 'rgba(44, 48, 94, 0.82)';
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.restore();

            // Kart çerçevesi (canlı mavi-cyan-mor gradient)
            const borderGrad = ctx.createLinearGradient(boxX, y, boxX+boxWidth, y+rowHeight);
            borderGrad.addColorStop(0, '#00eaff'); // cyan
            borderGrad.addColorStop(0.5, '#7b5cff'); // mor
            borderGrad.addColorStop(1, '#ff5ccf'); // pembe
            ctx.save();
            ctx.beginPath();
            roundRect(ctx, boxX, y, boxWidth, rowHeight - 10, 18);
            ctx.closePath();
            ctx.lineWidth = 2.5;
            ctx.strokeStyle = borderGrad;
            ctx.stroke();
            ctx.restore();

            // Sıra numarası
            let rankTextX = boxX + 20;
            let avatarX = boxX + 80;
            let usernameX = boxX + 140;
            ctx.font = 'bold 28px Arial';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'left';
            ctx.shadowColor = '#23243a';
            ctx.shadowBlur = 6;
            ctx.fillText(`${i + 1}.`, rankTextX, y + 40);
            ctx.shadowBlur = 0;
            // Avatar
            const avatar = await loadImage(user.displayAvatarURL({ extension: 'png', size: 128 }));
            ctx.save();
            ctx.beginPath();
            ctx.arc(avatarX, y + 40, avatarRadius, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(avatar, avatarX - avatarRadius, y + 40 - avatarRadius, avatarSize, avatarSize);
            ctx.restore();
            // Kullanıcı adı
            ctx.font = 'bold 20px Arial';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'left';
            ctx.shadowColor = '#000b';
            ctx.shadowBlur = 8;
            ctx.fillText(user.username, usernameX, y + 40);
            ctx.shadowBlur = 0;
            // İstatistik değeri (canlı cyan veya pembe, gölgeli)
            let statValue = 0;
            if (statType === 'voiceTime' || statType === 'cameraTime' || statType === 'streamingTime') {
                statValue = formatDuration(statEntry[statType] || 0);
            } else if (statType === 'invites') {
                statValue = (statEntry.invites || 0).toString();
            } else {
                statValue = (statEntry[statType] || 0).toLocaleString();
            }
            ctx.font = 'bold 20px Arial';
            ctx.fillStyle = i % 2 === 0 ? '#00eaff' : '#ff5ccf'; // Çiftlerde cyan, teklerde pembe
            ctx.textAlign = 'right';
            ctx.shadowColor = '#000b';
            ctx.shadowBlur = 8;
            ctx.fillText(statValue, boxX + boxWidth - 30, y + 40);
            ctx.shadowBlur = 0;
        }

        // Sağ üst köşeye imza: By Nivroth
        ctx.save();
        ctx.font = 'bold 20px Arial';
        const sigGrad = ctx.createLinearGradient(width-200, 30, width-20, 50);
        sigGrad.addColorStop(0, '#00eaff');
        sigGrad.addColorStop(1, '#ff5ccf');
        ctx.fillStyle = sigGrad;
        ctx.textAlign = 'right';
        ctx.shadowColor = '#000b';
        ctx.shadowBlur = 8;
        ctx.fillText('By Nivroth', width - 30, 45);
        ctx.shadowBlur = 0;
        ctx.restore();

        // Butonları oluştur
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`top-voiceTime`)
                    .setLabel('Ses')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(statType === 'voiceTime'),
                new ButtonBuilder()
                    .setCustomId(`top-cameraTime`)
                    .setLabel('Kamera')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(statType === 'cameraTime'),
                new ButtonBuilder()
                    .setCustomId(`top-streamingTime`)
                    .setLabel('Yayın')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(statType === 'streamingTime'),
                new ButtonBuilder()
                    .setCustomId(`top-messageCount`)
                    .setLabel('Mesaj')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(statType === 'messageCount'),
                new ButtonBuilder()
                    .setCustomId(`top-invites`)
                    .setLabel('Davet')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(statType === 'invites'),
                new ButtonBuilder()
                    .setCustomId('nivroth-bots')
                    .setLabel('Nivroth Bots')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
            );
        
        // Yanıtı gönderme veya düzenleme
        if (context.type === InteractionType.ApplicationCommand) { // Slash komutları için
            await replyTarget.reply({
                files: [new AttachmentBuilder(canvas.toBuffer(), { name: 'top_stats.png' })],
                components: [row]
            });
        } else if (context.type === InteractionType.MessageComponent) { // Düğme etkileşimleri için
            // replyTarget zaten deferUpdate edildiği için editReply kullanıyoruz
            await replyTarget.editReply({
                files: [new AttachmentBuilder(canvas.toBuffer(), { name: 'top_stats.png' })],
                components: [row]
            });
        } else { // Normal mesaj komutları için
            await replyTarget.reply({
                files: [new AttachmentBuilder(canvas.toBuffer(), { name: 'top_stats.png' })],
                components: [row]
            });
        }
    },
};