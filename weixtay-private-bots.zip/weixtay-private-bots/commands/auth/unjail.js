const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const Settings = require('../../models/Settings');
const Jail = require('../../models/Jail');
const CezaPuan = require('../../models/CezaPuan');

module.exports = {
    name: 'unjail',
    description: 'Belirtilen kullanıcıyı jail sisteminden çıkarır.',
    category: 'auth',
    async execute(client, message, args) {
        // Yetki kontrolü
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı! Lütfen `.setup` komutunu kullanın.');

        const hasPermission = message.member.permissions.has(PermissionFlagsBits.Administrator) || 
                            (settings.jailHammer && message.member.roles.cache.has(settings.jailHammer));
        
        if (!hasPermission) {
            return message.reply('Bu komutu kullanmak için "Yönetici" yetkisine veya Jail Hammer rolüne sahip olmalısın!');
        }

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const targetUser = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
        if (!targetUser) {
            return message.reply('Lütfen jail\'den çıkarmak istediğiniz kullanıcıyı etiketleyin veya ID\'sini girin.');
        }

        const member = await message.guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) {
            return message.reply('Bu kullanıcı sunucuda bulunamadı!');
        }

        // Bot kontrolü
        if (member.user.bot) {
            return message.reply('Botları jail\'den çıkaramazsın!');
        }

        if (!member.roles.cache.has(settings.jailRole)) {
            return message.reply('Bu kullanıcı jail sisteminde değil!');
        }

        // Ceza puanı kontrolü - 300 puanı geçen kullanıcıları sadece yönetici çıkarabilir
        const cezaPuan = await CezaPuan.findOne({ userId: targetUser.id, guildId: message.guild.id });
        if (cezaPuan && cezaPuan.isAutoJailed && !message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('Bu kullanıcı 300 ceza puanını geçtiği için otomatik jail sisteminde! Sadece yöneticiler çıkarabilir.');
        }

        try {
            // Jail kaydını bul
            const jailRecord = await Jail.findOne({
                userId: targetUser.id,
                guildId: message.guild.id,
                isReleased: false
            });

            if (!jailRecord) {
                return message.reply('Bu kullanıcı için aktif jail kaydı bulunamadı!');
            }

            // Yetkili olmayan rolleri geri ver
            const rolesToAdd = jailRecord.roles.filter(roleId => 
                !jailRecord.adminRoles.includes(roleId)
            );
            
            // Önce jail rolünü kaldır
            await member.roles.remove(settings.jailRole);
            
            // Sonra eski rolleri geri ver
            if (rolesToAdd.length > 0) {
                await member.roles.add(rolesToAdd);
            }

            // Jail kaydını güncelle
            jailRecord.isReleased = true;
            await jailRecord.save();

            // Log mesajı
            const logChannel = message.guild.channels.cache.find(c => c.name === 'jail-log');
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('Kullanıcı Jail\'den Çıkarıldı')
                    .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                    .addFields(
                        { name: 'Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                        { name: 'Yetkili', value: `${message.author.tag} (${message.author.id})`, inline: true },
                        { name: 'Sebep', value: 'Manuel Çıkarma', inline: true }
                    )
                    .setFooter({ text: 'Jail Sistemi' });

                await logChannel.send({ embeds: [embed] });
            }

            message.reply(`${targetUser} kullanıcısı jail'den çıkarıldı!`);
        } catch (error) {
            console.error('Unjail hatası:', error);
            message.reply('Kullanıcı jail\'den çıkarılırken bir hata oluştu!');
        }
    },
}; 