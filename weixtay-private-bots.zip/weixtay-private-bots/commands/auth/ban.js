const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const Settings = require('../../models/Settings');
const CezaPuan = require('../../models/CezaPuan');

module.exports = {
    name: 'ban',
    description: 'Belirtilen kullanıcıyı sunucudan yasaklar.',
    category: 'auth',
    async execute(client, message, args) {
        // Yetki kontrolü
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı! Lütfen `.setup` komutunu kullanın.');

        const hasPermission = message.member.permissions.has(PermissionFlagsBits.BanMembers) || 
                            (settings.banHammer && message.member.roles.cache.has(settings.banHammer));
        
        if (!hasPermission) {
            return message.reply('Bu komutu kullanmak için "Üyeleri Yasakla" yetkisine veya Ban Hammer rolüne sahip olmalısın!');
        }

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const targetUser = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
        if (!targetUser) {
            return message.reply('Lütfen yasaklamak istediğiniz kullanıcıyı etiketleyin veya ID\'sini girin.');
        }

        const reason = args.slice(1).join(' ') || 'Sebep belirtilmedi';

        try {
            const member = await message.guild.members.fetch(targetUser.id).catch(() => null);
            if (member && !member.bannable) {
                return message.reply('Bu kullanıcıyı yasaklayamam!');
            }

            await message.guild.members.ban(targetUser, { reason: reason });

            // Ceza puanı ekle
            await addCezaPuan(targetUser.id, message.guild.id, 'ban', 20, reason, message.author.id, message);

            // Log mesajı
            const logChannel = message.guild.channels.cache.find(c => c.name === 'Ban-log');
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Kullanıcı Yasaklandı')
                    .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                    .addFields(
                        { name: 'Yasaklanan Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                        { name: 'Yasaklayan Yetkili', value: `${message.author.tag} (${message.author.id})`, inline: true },
                        { name: 'Sebep', value: reason, inline: false },
                        { name: 'Tarih', value: new Date().toLocaleString('tr-TR'), inline: true }
                    )
                    .setFooter({ text: 'Ban Log Sistemi' });

                await logChannel.send({ embeds: [embed] });
            }

            message.reply(`${targetUser.tag} kullanıcısı başarıyla yasaklandı!`);
        } catch (error) {
            console.error('Ban hatası:', error);
            message.reply('Kullanıcı yasaklanırken bir hata oluştu!');
        }
    },
};

// Ceza puanı ekleme fonksiyonu
async function addCezaPuan(userId, guildId, type, points, reason, staffId, message) {
    try {
        let cezaPuan = await CezaPuan.findOne({ userId, guildId });
        if (!cezaPuan) {
            cezaPuan = new CezaPuan({ userId, guildId });
        }

        // Ceza geçmişine ekle
        cezaPuan.punishments.push({
            type: type,
            points: points,
            reason: reason,
            staffId: staffId,
            date: new Date(),
            isActive: true
        });

        // Toplam puanı güncelle
        cezaPuan.totalPoints += points;
        cezaPuan.updatedAt = new Date();

        // 300 puanı geçerse otomatik jail
        if (cezaPuan.totalPoints >= 300 && !cezaPuan.isAutoJailed) {
            cezaPuan.isAutoJailed = true;
            
            // Otomatik jail uygula
            const guild = await message.client.guilds.fetch(guildId);
            const member = await guild.members.fetch(userId);
            const settings = await Settings.findOne({ id: guildId });
            
            if (member && settings && settings.jailRole) {
                // Tüm rolleri al
                const userRoles = member.roles.cache.filter(role => role.id !== guildId).map(role => role.id);
                const adminRoles = member.roles.cache.filter(role => 
                    role.permissions.has(PermissionFlagsBits.Administrator) ||
                    role.permissions.has(PermissionFlagsBits.ManageChannels) ||
                    role.permissions.has(PermissionFlagsBits.ManageMessages) ||
                    role.permissions.has(PermissionFlagsBits.ManageRoles)
                ).map(role => role.id);

                // Jail rolünü ver
                await member.roles.set([settings.jailRole]);

                // Jail kaydı oluştur
                const Jail = require('../../models/Jail');
                const jail = new Jail({
                    userId: userId,
                    guildId: guildId,
                    reason: `Otomatik Jail - ${cezaPuan.totalPoints} ceza puanı`,
                    duration: 0, // Sınırsız
                    roles: userRoles,
                    adminRoles: adminRoles,
                    jailedBy: 'Sistem',
                    releaseAt: null
                });
                await jail.save();

                // Log gönder
                const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('🔒 Otomatik Jail Uygulandı')
                        .setDescription(`${member} kullanıcısı 300 puanı geçtiği için otomatik jail'e alındı`)
                        .addFields(
                            { name: '👤 Kullanıcı', value: `${member} (\`${member.id}\`)`, inline: true },
                            { name: '📊 Toplam Puan', value: `${cezaPuan.totalPoints}`, inline: true },
                            { name: '🔒 Jail Türü', value: 'Otomatik (Sınırsız)', inline: true }
                        )
                        .setColor(0xff0000)
                        .setThumbnail(member.displayAvatarURL({ dynamic: true }))
                        .setTimestamp();

                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
        }

        await cezaPuan.save();

        // Ceza puan logu gönder
        const guild = await message.client.guilds.fetch(guildId);
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
        if (logChannel) {
            const member = await guild.members.fetch(userId);
            await logChannel.send(`${member} kullanıcısına +${points} puan eklendi. Toplam: **${cezaPuan.totalPoints}/300**`);
        }

    } catch (error) {
        console.error('Ceza puanı ekleme hatası:', error);
    }
} 