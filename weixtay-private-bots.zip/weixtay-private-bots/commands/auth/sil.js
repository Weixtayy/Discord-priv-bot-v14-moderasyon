const { PermissionFlagsBits } = require('discord.js');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'sil',
    description: 'Belirtilen sayıda mesajı siler (1-100 arası).',
    category: 'auth',
    async execute(client, message, args) {
        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return message.reply('Bu komutu kullanmak için "Mesajları Yönet" yetkisine sahip olmalısın!');
        }

        // Ayarları veritabanından çek
        const settings = await Settings.findOne({ id: message.guild.id });

        // Komut kanalı kontrolü kaldırıldı, komutun kullanıldığı kanalda çalışacak.
        // if (!settings || !settings.commandChannel) {
        //     return message.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        // }
        // if (message.channel.id !== settings.commandChannel) {
        //     return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        // }

        // Silinecek mesaj sayısını al
        const amount = parseInt(args[0]);

        // Geçerli bir sayı kontrolü
        if (isNaN(amount) || amount < 1 || amount > 100) {
            return message.reply('Lütfen 1 ile 100 arasında geçerli bir sayı girin.');
        }

        try {
            // Önce komut mesajını sil
            await message.delete().catch(() => {});
            
            // Sonra diğer mesajları sil
            const deleted = await message.channel.bulkDelete(amount, true);
            
            // Silinen mesaj sayısını bildir
            message.channel.send(`${deleted.size} mesaj başarıyla silindi!`).then(msg => {
                // Bilgilendirme mesajını 5 saniye sonra sil
                setTimeout(() => msg.delete().catch(() => {}), 5000);
            });
        } catch (error) {
            console.error('Mesaj silinirken hata:', error);
            
            // 14 günden eski mesajlar için özel hata mesajı
            if (error.code === 50034) {
                return message.reply('14 günden eski mesajlar silinemez!');
            }
            
            message.reply('Mesajlar silinirken bir hata oluştu. Lütfen botun yetkilerini kontrol edin.');
        }
    },
};