const { AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'say',
    description: 'Sunucu istatistiklerini gösterir',
    async execute(client, message, args, config) {
        // Yetki kontrolü
        if (!message.member.permissions.has('Administrator')) {
            return message.reply('Bu komutu kullanmak için "Yönetici" yetkisine sahip olmalısın!');
        }

        // Komut kanalı kontrolü
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const guild = message.guild;
        await guild.members.fetch({ withPresences: true });

        // --- İstatistikler ---
        const totalMembers = guild.memberCount;
        const onlineMembers = guild.members.cache.filter(m => m.presence?.status === 'online').size;
        const idleMembers = guild.members.cache.filter(m => m.presence?.status === 'idle').size;
        const dndMembers = guild.members.cache.filter(m => m.presence?.status === 'dnd').size;
        const offlineMembers = guild.members.cache.filter(m => !m.presence || m.presence.status === 'offline').size;
        const voiceMembers = guild.members.cache.filter(m => m.voice && m.voice.channel).size;
        const boostCount = guild.premiumSubscriptionCount || 0;
        const emojiCount = guild.emojis.cache.size;
        const cameraMembers = guild.members.cache.filter(m => m.voice.channel && m.voice.selfVideo).size;
        const streamingMembers = guild.members.cache.filter(m => m.voice.channel && m.voice.streaming).size;
        const webMembers = guild.members.cache.filter(m => m.presence?.clientStatus?.web).size;
        const desktopMembers = guild.members.cache.filter(m => m.presence?.clientStatus?.desktop).size;
        const mobileMembers = guild.members.cache.filter(m => m.presence?.clientStatus?.mobile).size;

        // --- Blok Grupları ---
        const blocks = [
            {
                title: 'Üye Bilgileri',
                stats: [
                    { label: 'Toplam Üye', value: totalMembers.toLocaleString(), icon: '👥', valueColor: '#fff' },
                    { label: 'Online', value: onlineMembers.toLocaleString(), icon: '🌐', valueColor: '#2ecc71' },
                    { label: 'Idle', value: idleMembers.toLocaleString(), icon: '🌙', valueColor: '#f5a623' },
                    { label: 'DND', value: dndMembers.toLocaleString(), icon: '⛔', valueColor: '#e74c3c' },
                    { label: 'Offline', value: offlineMembers.toLocaleString(), icon: '⚪', valueColor: '#b9bbbe' }
                ]
            },
            {
                title: 'Ses & Boost',
                stats: [
                    { label: 'Ses Kanalı', value: voiceMembers.toLocaleString(), icon: '🎤', valueColor: '#4f6bed' },
                    { label: 'Boost', value: boostCount.toLocaleString(), icon: '🪐', valueColor: '#e16ee6' },
                    { label: 'Emoji', value: emojiCount.toLocaleString(), icon: '😀', valueColor: '#f5a623' },
                    { label: 'Kamera', value: cameraMembers.toLocaleString(), icon: '📹', valueColor: '#2ecc71' },
                    { label: 'Yayın', value: streamingMembers.toLocaleString(), icon: '📺', valueColor: '#e74c3c' }
                ]
            },
            {
                title: 'Cihazlar',
                stats: [
                    { label: 'Web', value: webMembers.toLocaleString(), icon: '💻', valueColor: '#4f6bed' },
                    { label: 'Masaüstü', value: desktopMembers.toLocaleString(), icon: '🖥️', valueColor: '#4f6bed' },
                    { label: 'Mobil', value: mobileMembers.toLocaleString(), icon: '📱', valueColor: '#f5a623' }
                ]
            }
        ];

        // Ekstra veriler: Rol ve Kanal sayısı
        const roleCount = guild.roles.cache.size;
        const channelCount = guild.channels.cache.size;
        // Mobil verisini bul ve çıkar
        let mobileStatIndex = blocks[2].stats.findIndex(s => s.label === 'Mobil');
        let mobileStat = null;
        if (mobileStatIndex !== -1) {
            mobileStat = blocks[2].stats.splice(mobileStatIndex, 1)[0];
        }
        // --- Canvas Ayarları (1920x1400p) ---
        const canvasWidth = 1920;
        const canvasHeight = 1400;
        // Blok ve kutucuk boyutlarını ve paddingleri bu boyuta göre optimize et
        const blockCount = blocks.length;
        const blockPadX = 40, blockPadY = 80;
        const blockW = Math.floor((canvasWidth - (blockCount + 1) * blockPadX) / blockCount);
        const blockH = 600;
        const statBoxW = 360, statBoxH = 180;
        const statPadX = 40, statPadY = 40;
        const blockTitleH = 70;
        const blockInnerPad = 32;
        const headerY = 60;
        const canvas = createCanvas(canvasWidth, canvasHeight);
        const ctx = canvas.getContext('2d');

        // --- Arka Plan (Gradient) ---
        const bgGradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
        bgGradient.addColorStop(0, '#202225');
        bgGradient.addColorStop(1, '#18191c');
        ctx.fillStyle = bgGradient;
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);

        // --- Sunucu İkonu, İsim ve Başlık Yatayda ---
        const iconSize = 220;
        const iconX = 120;
        const iconY = 120;
        const titleX = iconX + iconSize + 60;
        const titleY = iconY + 80;
        try {
            const iconURL = guild.iconURL({ extension: 'png', size: 256, forceStatic: true });
            if (iconURL) {
                const icon = await loadImage(iconURL);
                ctx.save();
                ctx.beginPath();
                ctx.arc(iconX + iconSize / 2, iconY + iconSize / 2, iconSize / 2, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(icon, iconX, iconY, iconSize, iconSize);
                ctx.restore();
                // Beyaz çerçeve
                ctx.save();
                ctx.beginPath();
                ctx.arc(iconX + iconSize / 2, iconY + iconSize / 2, iconSize / 2, 0, Math.PI * 2, true);
                ctx.lineWidth = 10;
                ctx.strokeStyle = '#fff';
                ctx.stroke();
                ctx.restore();
            }
        } catch {}
        ctx.save();
        ctx.font = 'bold 110px Arial';
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'left';
        ctx.fillText(guild.name.toUpperCase(), titleX, titleY + 60);
        ctx.font = 'bold 60px Arial';
        ctx.fillStyle = '#b9bbbe';
        ctx.fillText('Sunucu İstatistikleri', titleX, titleY + 140);
        ctx.restore();

        // --- Kutucukları başlığın altına düzgün grid olarak hizala ---
        const allStats = [
            ...blocks[0].stats,
            ...blocks[1].stats,
            ...blocks[2].stats,
            // 4. satır: Mobil, Rol Sayısı, Kanal Sayısı
            mobileStat || { label: 'Mobil', value: '0', icon: '📱', valueColor: '#f5a623' },
            { label: 'Rol Sayısı', value: roleCount.toLocaleString(), icon: '🧩', valueColor: '#fff' },
            { label: 'Kanal Sayısı', value: channelCount.toLocaleString(), icon: '📁', valueColor: '#fff' }
        ];
        const statCols = 4;
        const statRows = Math.ceil(allStats.length / statCols);
        // Grid başlangıcı: ikonun altı ile başlığın altı hizasında, yatayda ortalı
        const gridStartY = Math.max(iconY + iconSize, titleY + 180) + 60;
        const gridTotalW = statCols * statBoxW + (statCols - 1) * statPadX;
        const gridStartX = Math.floor((canvasWidth - gridTotalW) / 2);
        for (let i = 0; i < allStats.length; i++) {
            const stat = allStats[i];
            const col = i % statCols;
            const row = Math.floor(i / statCols);
            const statX = gridStartX + col * (statBoxW + statPadX);
            const statY = gridStartY + row * (statBoxH + statPadY);
                // Kutu
                ctx.save();
                ctx.beginPath();
                ctx.moveTo(statX + 24, statY);
                ctx.arcTo(statX + statBoxW, statY, statX + statBoxW, statY + statBoxH, 24);
                ctx.arcTo(statX + statBoxW, statY + statBoxH, statX, statY + statBoxH, 24);
                ctx.arcTo(statX, statY + statBoxH, statX, statY, 24);
                ctx.arcTo(statX, statY, statX + statBoxW, statY, 24);
                ctx.closePath();
                ctx.fillStyle = '#181a1b';
                ctx.shadowColor = 'rgba(0,0,0,0.12)';
                ctx.shadowBlur = 16;
                ctx.fill();
                ctx.shadowBlur = 0;
                ctx.restore();
                // İkon ve başlık
                ctx.save();
            ctx.font = 'bold 40px Arial';
                ctx.fillStyle = '#fff';
                ctx.textAlign = 'left';
            ctx.fillText(stat.icon, statX + 28, statY + 48);
                ctx.font = 'bold 28px Arial';
                ctx.fillStyle = '#fff';
            ctx.fillText(stat.label, statX + 90, statY + 48);
                ctx.restore();
                // Değer
                ctx.save();
            ctx.font = 'bold 48px Arial';
                ctx.fillStyle = stat.valueColor;
                ctx.textAlign = 'left';
            ctx.fillText(stat.value, statX + 28, statY + 120);
                ctx.restore();
        }

        // Sağ alt köşeye imza
        ctx.save();
        ctx.font = 'bold 32px Arial';
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.textAlign = 'right';
        ctx.fillText('By Nivroth', canvasWidth - 60, canvasHeight - 40);
        ctx.restore();

        // --- Gönder ---
        const buffer = canvas.toBuffer();
        const attachment = new AttachmentBuilder(buffer, { name: 'server_stats.png' });
        await message.reply({ files: [attachment] });
    }
};