const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createCanvas, loadImage, registerFont } = require('canvas');
const RoleLog = require('../../models/RoleLog');
const Settings = require('../../models/Settings');

// registerFont('./fonts/YourFont.ttf', { family: 'YourFont' }); // Eğer özel font kullanmak isterseniz

module.exports = {
    name: 'rollog',
    description: 'Bir kullanıcının rol geçmişini gösterir',
    async execute(client, message, args, config, embed) {
        // Yetki kontrolü
        if (!message.member.permissions.has('ManageRoles') && !message.member.permissions.has('Administrator')) {
            return message.reply('Bu komutu kullanmak için "Rolleri Yönet" veya "Yönetici" yetkisine sahip olmalısın!');
        }

        // Komut kanalı kontrolü
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings || !settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }

        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Kullanıcı kontrolü
        const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
        if (!user) {
            return message.reply('Lütfen bir kullanıcı etiketleyin veya ID girin!');
        }

        const member = message.guild.members.cache.get(user.id);
        if (!member) {
            return message.reply('Bu kullanıcı sunucuda bulunamadı!');
        }

        // Rol loglarını getir
        const logs = await RoleLog.find({ 
            userId: user.id
        }).sort({ timestamp: -1 });

        if (logs.length === 0) {
            return message.reply('Bu kullanıcı için rol geçmişi bulunamadı!');
        }

        // Sayfalama için verileri hazırla
        const itemsPerPage = 5;
        const totalPages = Math.ceil(logs.length / itemsPerPage);
        let currentPage = 1;

        function truncateText(ctx, text, maxWidth) {
            if (ctx.measureText(text).width <= maxWidth) return text;
            while (text.length > 0 && ctx.measureText(text + '...').width > maxWidth) {
                text = text.slice(0, -1);
            }
            return text + '...';
        }

        async function generateCanvas(page) {
            const width = 900;
            const height = 555; // Yeni yükseklik: 5 kartı tam sığdırır
            const cardHeight = 60;
            const cardGap = 15;
            const cardStartY = 175; // İlk kartın başlangıç Y koordinatı

            const canvas = createCanvas(width, height);
            const ctx = canvas.getContext('2d');

            // Arka plan: gradient
            const gradient = ctx.createLinearGradient(0, 0, 0, height);
            gradient.addColorStop(0, '#1A1A1A');
            gradient.addColorStop(1, '#0A0A0A');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);

            // Sunucu Bilgisi Kutusu
            ctx.save();
            ctx.beginPath();
            ctx.roundRect(10, 15, 300, 100, 15); // Yuvarlatılmış dikdörtgen
            ctx.fillStyle = '#1A1D20';
            ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
            ctx.shadowBlur = 15;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.restore();

            // Sunucu adı ve logo
            if (message.guild.iconURL()) {
                const guildIcon = await loadImage(message.guild.iconURL({ extension: 'png', size: 128 }));
                ctx.save();
                ctx.beginPath();
                ctx.arc(60, 65, 40, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(guildIcon, 20, 25, 80, 80);
                ctx.restore();

                // İkon çerçevesi
                ctx.save();
                ctx.beginPath();
                ctx.arc(60, 65, 42, 0, Math.PI * 2, true);
                ctx.strokeStyle = '#FFD700'; // Altın rengi
                ctx.lineWidth = 4; // Çerçeve kalınlığı
                ctx.stroke();
                ctx.restore();
            }
            ctx.font = 'bold 26px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.fillText(truncateText(ctx, message.guild.name, 170), 115, 60); // Yazı hizalaması
            ctx.font = '18px sans-serif';
            ctx.fillStyle = '#b9bbbe';

            // Kullanıcı Bilgisi Kutusu
            ctx.save();
            ctx.beginPath();
            ctx.roundRect(width - 310, 15, 300, 100, 15); // Yuvarlatılmış dikdörtgen
            ctx.fillStyle = '#1A1D20';
            ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
            ctx.shadowBlur = 15;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.restore();

            // Kullanıcı avatarı ve adı
            const avatar = await loadImage(user.displayAvatarURL({ extension: 'png', size: 128 }));
            ctx.save();
            ctx.beginPath();
            ctx.arc(width - 60, 65, 40, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(avatar, width - 100, 25, 80, 80);
            ctx.restore();

            // Avatar çerçevesi
            ctx.save();
            ctx.beginPath();
            ctx.arc(width - 60, 65, 42, 0, Math.PI * 2, true);
            ctx.strokeStyle = '#FFD700'; // Altın rengi
            ctx.lineWidth = 4; // Çerçeve kalınlığı
            ctx.stroke();
            ctx.restore();
            
            ctx.font = 'bold 22px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'right';
            ctx.fillText(truncateText(ctx, user.tag, 180), width - 115, 60); // Yazı hizalaması
            ctx.font = '18px sans-serif';
            ctx.fillStyle = '#b9bbbe';
            ctx.fillText('Rol Geçmişi', width - 115, 90); // Yazı hizalaması
            ctx.textAlign = 'left';

            // Başlık çizgisi
            ctx.strokeStyle = '#FFD700'; // Altın rengi
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(30, 130);
            ctx.lineTo(width - 30, 130);
            ctx.stroke();

            // Sayfa numarası
            ctx.font = 'bold 16px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'right';
            ctx.fillText(`Sayfa ${page}/${totalPages}`, width - 30, height - 20);
            ctx.textAlign = 'left';

            // Kutu başlıkları
            ctx.font = 'bold 18px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.fillText('Aksiyon', 60, 155);
            ctx.fillText('Rol', 220, 155);
            ctx.fillText('Yetkili', 460, 155);
            ctx.fillText('Tarih', 690, 155);

            // Log kartları (tam 5 tane, eksikse boş kart)
            const start = (page - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const currentLogs = logs.slice(start, end);
            
            for (let i = 0; i < itemsPerPage; i++) {
                const log = currentLogs[i];
                const currentCardY = cardStartY + (i * (cardHeight + cardGap));

                // Kart arka planı (Yuvarlatılmış dikdörtgen)
                ctx.save();
                ctx.beginPath();
                ctx.roundRect(30, currentCardY, width - 60, cardHeight, 10);
                ctx.globalAlpha = 0.85;
                ctx.fillStyle = i % 2 === 0 ? '#1A1D20' : '#2C2F33';
                ctx.shadowColor = '#000';
                ctx.shadowBlur = 8;
                ctx.fill();
                ctx.shadowBlur = 0;
                ctx.globalAlpha = 1;
                ctx.restore();

                if (log) {
                    // Aksiyon rozeti (yuvarlak içinde)
                    ctx.save();
                    ctx.font = 'bold 16px sans-serif';
                    ctx.fillStyle = log.action === 'add' ? '#43b581' : '#f04747'; // Renkli + veya -
                    ctx.beginPath();
                    ctx.arc(75, currentCardY + 20, 15, 0, Math.PI * 2); // Yuvarlak
                    ctx.fill();
                    ctx.fillStyle = '#fff';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(log.action === 'add' ? '+' : '-', 75, currentCardY + 20); // İşaret
                    ctx.restore();

                    // Aksiyon metni
                    ctx.font = '14px sans-serif';
                    ctx.fillStyle = log.action === 'add' ? '#43b581' : '#f04747'; // Renkli + veya -
                    ctx.textAlign = 'center';
                    ctx.fillText(log.action === 'add' ? 'Verildi' : 'Alındı', 75, currentCardY + 45); 

                    // Rol adı (taşmayan)
                    ctx.font = 'bold 18px sans-serif';
                    ctx.fillStyle = '#fff';
                    ctx.textAlign = 'left';
                    const roleText = truncateText(ctx, log.roleName, 180);
                    ctx.fillText(roleText, 220, currentCardY + cardHeight / 2 + 5);

                    // Yetkili (taşmayan ve belirgin)
                    ctx.font = 'bold 16px sans-serif'; // Belirgin
                    ctx.fillStyle = '#fff'; // Daha belirgin renk
                    ctx.textAlign = 'left';
                    const execText = truncateText(ctx, log.executorName || 'Bilinmeyen', 200);
                    ctx.fillText(execText, 460, currentCardY + cardHeight / 2 + 5);

                    // Tarih (açık renk, taşmayan ve belirgin)
                    ctx.font = 'bold 15px monospace'; // Belirgin
                    ctx.fillStyle = '#f0f0f0'; // Daha belirgin açık renk
                    ctx.textAlign = 'left';
                    const dateText = truncateText(ctx, new Date(log.timestamp).toLocaleString('tr-TR'), 180);
                    ctx.fillText(dateText, 690, currentCardY + cardHeight / 2 + 5);
                }
            }

            ctx.textAlign = 'left';
            return canvas.toBuffer();
        }

        // İlk sayfa görselini oluştur ve gönder
        const buffer = await generateCanvas(currentPage);
        const attachment = new AttachmentBuilder(buffer, { name: 'rollog.png' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('first')
                    .setLabel('⏮️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === 1),
                new ButtonBuilder()
                    .setCustomId('previous')
                    .setLabel('◀️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === 1),
                new ButtonBuilder()
                    .setCustomId('next')
                    .setLabel('▶️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === totalPages),
                new ButtonBuilder()
                    .setCustomId('last')
                    .setLabel('⏭️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === totalPages)
            );

        const msg = await message.reply({
            content: `${user} kullanıcısının rol geçmişi:`,
            files: [attachment],
            components: [row]
        });

        // Buton koleksiyoncusu
        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 60000
        });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'first') currentPage = 1;
            if (interaction.customId === 'previous') currentPage--;
            if (interaction.customId === 'next') currentPage++;
            if (interaction.customId === 'last') currentPage = totalPages;

            row.components[0].setDisabled(currentPage === 1);
            row.components[1].setDisabled(currentPage === 1);
            row.components[2].setDisabled(currentPage === totalPages);
            row.components[3].setDisabled(currentPage === totalPages);

            const buffer = await generateCanvas(currentPage);
            const attachment = new AttachmentBuilder(buffer, { name: 'rollog.png' });

            await interaction.update({
                content: `${user} kullanıcısının rol geçmişi:`,
                files: [attachment],
                components: [row]
            });
        });

        collector.on('end', () => {
            msg.edit({ components: [] }).catch(() => {});
        });
    }
}; 