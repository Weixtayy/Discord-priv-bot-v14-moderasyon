const { 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    StringSelectMenuBuilder,
    PermissionsBitField 
} = require('discord.js');
const Settings = require('../../models/Settings');
const CezaPuan = require('../../models/CezaPuan');
const ChatMute = require('../../models/ChatMute');
const VoiceMute = require('../../models/VoiceMute');
const Jail = require('../../models/Jail');

module.exports = {
    name: 'psifirla',
    description: 'Kullanıcının ceza puanlarını sıfırlar',
    aliases: ['sıfırla', 'reset', 'temizle'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı!');

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator) && 
            !message.member.roles.cache.has(settings.muteYetkiliRole)) {
            return message.reply('Bu komutu kullanmak için yetkili olmalısın!');
        }

        // Kullanıcı kontrolü
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Ceza puanları sıfırlanacak kullanıcıyı etiketle veya ID gir!');

        // Kullanıcının ceza puanlarını getir
        const cezaPuan = await CezaPuan.findOne({ guildId: message.guild.id, userId: user.id });
        if (!cezaPuan || cezaPuan.punishments.length === 0) {
            return message.reply('Bu kullanıcının hiç ceza puanı bulunmuyor!');
        }

        // Her cezayı ayrı ayrı listele
        const selectOptions = [
            {
                label: `Tüm Ceza Puanlarını Sil (${cezaPuan.totalPoints} puan)`,
                value: 'all',
                description: 'Kullanıcının tüm ceza puanlarını sıfırlar'
            }
        ];

        // Her cezayı tek tek ekle
        cezaPuan.punishments.forEach((punishment, index) => {
            let typeLabel = punishment.type;
            if (punishment.type === 'chat_mute') typeLabel = 'Chat Mute';
            else if (punishment.type === 'voice_mute') typeLabel = 'Voice Mute';
            else if (punishment.type === 'jail') typeLabel = 'Jail';
            else if (punishment.type === 'ban') typeLabel = 'Ban';
            else if (punishment.type === 'kick') typeLabel = 'Kick';
            else if (punishment.type === 'warn') typeLabel = 'Uyarı';

            const date = new Date(punishment.date).toLocaleDateString('tr-TR');
            const time = new Date(punishment.date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

            selectOptions.push({
                label: `${typeLabel} (+${punishment.points}) - ${date}`,
                value: `punishment_${index}`,
                description: `${punishment.reason} - ${time}`
            });
        });

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('psifirla_select')
            .setPlaceholder('Silinecek cezayı seçin...')
            .addOptions(selectOptions);

        const confirmButton = new ButtonBuilder()
            .setCustomId('psifirla_confirm')
            .setLabel('✅ Onayla')
            .setStyle(ButtonStyle.Success)
            .setDisabled(true);

        const cancelButton = new ButtonBuilder()
            .setCustomId('psifirla_cancel')
            .setLabel('❌ İptal')
            .setStyle(ButtonStyle.Danger);

        const selectRow = new ActionRowBuilder().addComponents(selectMenu);
        const buttonRow = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

        const msg = await message.reply({
            content: `${user} kullanıcısının ceza puanlarını sıfırlama:\n\n**Mevcut Durum:**\n• Toplam Puan: ${cezaPuan.totalPoints}/300\n• Toplam Ceza: ${cezaPuan.punishments.length} adet\n\nHangi cezayı silmek istiyorsun?`,
            components: [selectRow, buttonRow]
        });

        let selectedValue = null;
        let selectedPunishment = null;

        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 60000
        });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'psifirla_select') {
                selectedValue = interaction.values[0];
                confirmButton.setDisabled(false);

                if (selectedValue === 'all') {
                    selectedPunishment = null;
                    await interaction.update({
                        content: `${user} kullanıcısının ceza puanlarını sıfırlama:\n\n**Tüm ceza puanları silinecek:**\n• Toplam ${cezaPuan.totalPoints} puan\n• ${cezaPuan.punishments.length} adet ceza\n\nOnaylamak için ✅ butonuna tıklayın.`,
                        components: [selectRow, buttonRow]
                    });
                } else {
                    const punishmentIndex = parseInt(selectedValue.split('_')[1]);
                    selectedPunishment = cezaPuan.punishments[punishmentIndex];
                    
                    let typeLabel = selectedPunishment.type;
                    if (selectedPunishment.type === 'chat_mute') typeLabel = 'Chat Mute';
                    else if (selectedPunishment.type === 'voice_mute') typeLabel = 'Voice Mute';
                    else if (selectedPunishment.type === 'jail') typeLabel = 'Jail';
                    else if (selectedPunishment.type === 'ban') typeLabel = 'Ban';
                    else if (selectedPunishment.type === 'kick') typeLabel = 'Kick';
                    else if (selectedPunishment.type === 'warn') typeLabel = 'Uyarı';

                    const date = new Date(selectedPunishment.date).toLocaleDateString('tr-TR');
                    const time = new Date(selectedPunishment.date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

                    await interaction.update({
                        content: `${user} kullanıcısının ceza puanlarını sıfırlama:\n\n**Seçilen Ceza:**\n• Tür: ${typeLabel}\n• Puan: +${selectedPunishment.points}\n• Sebep: ${selectedPunishment.reason}\n• Tarih: ${date} ${time}\n• Yetkili: <@${selectedPunishment.staffId}>\n\nOnaylamak için ✅ butonuna tıklayın.`,
                        components: [selectRow, buttonRow]
                    });
                }
            } else if (interaction.customId === 'psifirla_confirm') {
                if (!selectedValue) {
                    await interaction.reply({ content: 'Lütfen önce bir ceza seçin!', ephemeral: true });
                    return;
                }

                try {
                    if (selectedValue === 'all') {
                        // Tüm ceza puanlarını sil
                        await CezaPuan.deleteOne({ guildId: message.guild.id, userId: user.id });
                        
                        // İlgili tüm ceza türlerini de sil (sicil.js'de görünmemesi için)
                        try {
                            // Chat mute cezalarını sil
                            await ChatMute.deleteMany({ 
                                guildId: message.guild.id, 
                                userId: user.id
                            });
                            
                            // Voice mute cezalarını sil
                            await VoiceMute.deleteMany({ 
                                guildId: message.guild.id, 
                                userId: user.id
                            });
                            
                            // Jail cezalarını sil
                            await Jail.deleteMany({ 
                                guildId: message.guild.id, 
                                userId: user.id
                            });
                        } catch (error) {
                            console.error('İlgili ceza türleri silinirken hata:', error);
                        }
                        
                        await interaction.update({
                            content: `✅ **Başarılı!**\n\n${user} kullanıcısının tüm ceza puanları silindi:\n• ${cezaPuan.totalPoints} puan silindi\n• ${cezaPuan.punishments.length} adet ceza silindi`,
                            components: []
                        });
                    } else {
                        // Belirli cezayı sil
                        const punishmentIndex = parseInt(selectedValue.split('_')[1]);
                        const deletedPunishment = cezaPuan.punishments[punishmentIndex];
                        
                        // Cezayı listeden çıkar
                        cezaPuan.punishments.splice(punishmentIndex, 1);
                        
                        // Toplam puanı güncelle
                        cezaPuan.totalPoints -= deletedPunishment.points;
                        
                        // Eğer hiç ceza kalmadıysa dokümanı sil
                        if (cezaPuan.punishments.length === 0) {
                            await CezaPuan.deleteOne({ guildId: message.guild.id, userId: user.id });
                        } else {
                            // Değilse güncelle
                            await cezaPuan.save();
                        }

                        // İlgili ceza türünü de sil (sicil.js'de görünmemesi için)
                        try {
                            if (deletedPunishment.type === 'chat_mute') {
                                // Chat mute cezasını sil
                                await ChatMute.deleteMany({ 
                                    guildId: message.guild.id, 
                                    userId: user.id,
                                    reason: deletedPunishment.reason,
                                    staffId: deletedPunishment.staffId
                                });
                            } else if (deletedPunishment.type === 'voice_mute') {
                                // Voice mute cezasını sil
                                await VoiceMute.deleteMany({ 
                                    guildId: message.guild.id, 
                                    userId: user.id,
                                    reason: deletedPunishment.reason,
                                    staffId: deletedPunishment.staffId
                                });
                            } else if (deletedPunishment.type === 'jail') {
                                // Jail cezasını sil
                                await Jail.deleteMany({ 
                                    guildId: message.guild.id, 
                                    userId: user.id,
                                    reason: deletedPunishment.reason,
                                    jailedBy: deletedPunishment.staffId
                                });
                            }
                        } catch (error) {
                            console.error('İlgili ceza türü silinirken hata:', error);
                        }

                        let typeLabel = deletedPunishment.type;
                        if (deletedPunishment.type === 'chat_mute') typeLabel = 'Chat Mute';
                        else if (deletedPunishment.type === 'voice_mute') typeLabel = 'Voice Mute';
                        else if (deletedPunishment.type === 'jail') typeLabel = 'Jail';
                        else if (deletedPunishment.type === 'ban') typeLabel = 'Ban';
                        else if (deletedPunishment.type === 'kick') typeLabel = 'Kick';
                        else if (deletedPunishment.type === 'warn') typeLabel = 'Uyarı';

                        const date = new Date(deletedPunishment.date).toLocaleDateString('tr-TR');
                        const time = new Date(deletedPunishment.date).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

                        await interaction.update({
                            content: `✅ **Başarılı!**\n\n${user} kullanıcısının cezası silindi:\n• Tür: ${typeLabel}\n• Puan: +${deletedPunishment.points}\n• Sebep: ${deletedPunishment.reason}\n• Tarih: ${date} ${time}\n\nKalan puan: ${cezaPuan.totalPoints}/300`,
                            components: []
                        });
                    }

                    // Log kanalına bilgi gönder
                    if (settings.logChannel) {
                        const logChannel = message.guild.channels.cache.get(settings.logChannel);
                        if (logChannel) {
                            let logMessage = `**Ceza Puanı Silme İşlemi**\n\n`;
                            logMessage += `**Kullanıcı:** ${user} (${user.user.tag})\n`;
                            logMessage += `**Yetkili:** ${message.author} (${message.author.tag})\n`;
                            
                            if (selectedValue === 'all') {
                                logMessage += `**İşlem:** Tüm ceza puanları silindi\n`;
                                logMessage += `**Silinen:** ${cezaPuan.totalPoints} puan, ${cezaPuan.punishments.length} ceza`;
                            } else {
                                let typeLabel = selectedPunishment.type;
                                if (selectedPunishment.type === 'chat_mute') typeLabel = 'Chat Mute';
                                else if (selectedPunishment.type === 'voice_mute') typeLabel = 'Voice Mute';
                                else if (selectedPunishment.type === 'jail') typeLabel = 'Jail';
                                else if (selectedPunishment.type === 'ban') typeLabel = 'Ban';
                                else if (selectedPunishment.type === 'kick') typeLabel = 'Kick';
                                else if (selectedPunishment.type === 'warn') typeLabel = 'Uyarı';

                                logMessage += `**İşlem:** Tek ceza silindi\n`;
                                logMessage += `**Silinen:** ${typeLabel} (+${selectedPunishment.points} puan)\n`;
                                logMessage += `**Sebep:** ${selectedPunishment.reason}`;
                            }

                            logChannel.send({ content: logMessage }).catch(() => {});
                        }
                    }

                } catch (error) {
                    console.error('Ceza puanı silme hatası:', error);
                    await interaction.update({
                        content: '❌ **Hata!** Ceza puanları silinirken bir hata oluştu.',
                        components: []
                    });
                }
            } else if (interaction.customId === 'psifirla_cancel') {
                await interaction.update({
                    content: '❌ **İptal edildi!** Ceza puanı silme işlemi iptal edildi.',
                    components: []
                });
            }
        });

        collector.on('end', () => {
            const disabledSelectMenu = selectMenu.setDisabled(true);
            const disabledConfirmButton = confirmButton.setDisabled(true);
            const disabledCancelButton = cancelButton.setDisabled(true);
            
            const disabledSelectRow = new ActionRowBuilder().addComponents(disabledSelectMenu);
            const disabledButtonRow = new ActionRowBuilder().addComponents(disabledConfirmButton, disabledCancelButton);
            
            msg.edit({ components: [disabledSelectRow, disabledButtonRow] }).catch(() => {});
        });
    }
}; 