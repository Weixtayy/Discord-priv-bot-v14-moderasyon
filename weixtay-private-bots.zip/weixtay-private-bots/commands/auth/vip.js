const { PermissionFlagsBits } = require('discord.js');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'vip',
    description: 'Belirtilen kullanıcıya VIP rolü verir.',
    category: 'auth',
    async execute(client, message, args) {
        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply('Bu komutu kullanmak için "Rolleri Yönet" yetkisine sahip olmalısın!');
        }

        // Ayarları veritabanından çek
        const settings = await Settings.findOne({ id: message.guild.id });

        // Komut kanalı kontrolü
        if (!settings || !settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen önce `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const targetMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!targetMember) {
            return message.reply("Lütfen VIP rolü vermek istediğiniz kullanıcıyı etiketleyin veya ID'sini girin.");
        }

        if (!settings.vipRole) {
            return message.reply('VIP rolü ayarlanmamış! Lütfen `.setup` komutunu kullanarak VIP rolünü ayarlayın.');
        }

        const vipRole = message.guild.roles.cache.get(settings.vipRole);
        if (!vipRole) {
            return message.reply('Ayarlanan VIP rolü bulunamadı veya silinmiş.');
        }

        // Kullanıcının zaten VIP rolüne sahip olup olmadığını kontrol et
        if (targetMember.roles.cache.has(vipRole.id)) {
            return message.reply(`${targetMember.user.tag} zaten VIP rolüne sahip.`);
        }

        try {
            await targetMember.roles.add(vipRole);
            message.reply(`${targetMember.user.tag} kullanıcısına başarıyla VIP rolü verildi!`);
        } catch (error) {
            console.error('VIP rolü verilirken hata:', error);
            message.reply('VIP rolü verilirken bir hata oluştu. Lütfen botun yetkilerini kontrol edin.');
        }
    },
}; 