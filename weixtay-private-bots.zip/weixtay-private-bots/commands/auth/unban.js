const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const Settings = require('../../models/Settings');

module.exports = {
    name: 'unban',
    description: 'Belirtilen kullanıcının yasağını kaldırır.',
    category: 'auth',
    async execute(client, message, args) {
        // Yetki kontrolü
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı! Lütfen `.setup` komutunu kullanın.');

        const hasPermission = message.member.permissions.has(PermissionFlagsBits.BanMembers) || 
                            (settings.banHammer && message.member.roles.cache.has(settings.banHammer));
        
        if (!hasPermission) {
            return message.reply('Bu komutu kullanmak için "Üyeleri Yasakla" yetkisine veya Ban Hammer rolüne sahip olmalısın!');
        }

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        const userId = args[0];
        if (!userId) {
            return message.reply('Lütfen yasağını kaldırmak istediğiniz kullanıcının ID\'sini girin.');
        }

        try {
            const bans = await message.guild.bans.fetch();
            const bannedUser = bans.find(ban => ban.user.id === userId);

            if (!bannedUser) {
                return message.reply('Bu kullanıcı yasaklı değil!');
            }

            await message.guild.members.unban(userId);

            // Log mesajı
            const logChannel = message.guild.channels.cache.find(c => c.name === 'ban-log');
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('Kullanıcı Yasağı Kaldırıldı')
                    .setThumbnail(bannedUser.user.displayAvatarURL({ dynamic: true }))
                    .addFields(
                        { name: 'Kullanıcı', value: `${bannedUser.user.tag} (${bannedUser.user.id})`, inline: true },
                        { name: 'Yasağı Kaldıran Yetkili', value: `${message.author.tag} (${message.author.id})`, inline: true },
                        { name: 'Tarih', value: new Date().toLocaleString('tr-TR'), inline: true }
                    )
                    .setFooter({ text: 'Ban Log Sistemi' });

                await logChannel.send({ embeds: [embed] });
            }

            message.reply(`${bannedUser.user.tag} kullanıcısının yasağı başarıyla kaldırıldı!`);
        } catch (error) {
            console.error('Unban hatası:', error);
            message.reply('Kullanıcının yasağı kaldırılırken bir hata oluştu!');
        }
    },
}; 