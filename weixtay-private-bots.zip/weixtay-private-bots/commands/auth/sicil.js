const { 
    AttachmentBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    StringSelectMenuBuilder,
    PermissionsBitField 
} = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const Settings = require('../../models/Settings');
const ChatMute = require('../../models/ChatMute');
const VoiceMute = require('../../models/VoiceMute');
const Jail = require('../../models/Jail');
const CezaPuan = require('../../models/CezaPuan');

module.exports = {
    name: 'sicil',
    description: 'Kullanıcının sicilini gösterir',
    aliases: ['ceza', 'geçmiş', 'sicil'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı!');

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator) && 
            !message.member.roles.cache.has(settings.muteYetkiliRole)) {
            return message.reply('Bu komutu kullanmak için yetkili olmalısın!');
        }

        // Kullanıcı kontrolü
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Sicili görüntülenecek kullanıcıyı etiketle veya ID gir!');

        // Tüm cezaları çek
        const chatMutes = await ChatMute.find({ guildId: message.guild.id, userId: user.id }).sort({ createdAt: -1 });
        const voiceMutes = await VoiceMute.find({ guildId: message.guild.id, userId: user.id }).sort({ createdAt: -1 });
        const jails = await Jail.find({ guildId: message.guild.id, userId: user.id }).sort({ createdAt: -1 });
        const cezaPuan = await CezaPuan.findOne({ guildId: message.guild.id, userId: user.id });

        // Ceza türleri
        const punishmentTypes = [
            { label: 'Tüm Cezalar', value: 'all', color: '#ffffff' },
            { label: 'Chat Mute', value: 'chat_mute', color: '#ff6b6b' },
            { label: 'Voice Mute', value: 'voice_mute', color: '#ffa500' },
            { label: 'Jail', value: 'jail', color: '#8b0000' }
        ];

        let currentType = 'all';
        let currentPage = 0;

        function getPunishmentsByType(type) {
            const allPunishments = [];

            if (type === 'all' || type === 'chat_mute') {
                chatMutes.forEach(mute => {
                    allPunishments.push({
                        type: 'Chat Mute',
                        reason: mute.reason,
                        staffId: mute.staffId,
                        date: mute.createdAt,
                        endTime: mute.endTime,
                        isActive: mute.isActive,
                        duration: mute.duration,
                        color: '#ff6b6b'
                    });
                });
            }

            if (type === 'all' || type === 'voice_mute') {
                voiceMutes.forEach(mute => {
                    allPunishments.push({
                        type: 'Voice Mute',
                        reason: mute.reason,
                        staffId: mute.staffId,
                        date: mute.createdAt,
                        endTime: mute.endTime,
                        isActive: mute.isActive,
                        duration: mute.duration,
                        color: '#ffa500'
                    });
                });
            }

            if (type === 'all' || type === 'jail') {
                jails.forEach(jail => {
                    allPunishments.push({
                        type: 'Jail',
                        reason: jail.reason,
                        staffId: jail.jailedBy,
                        date: jail.createdAt,
                        endTime: jail.releaseAt,
                        isActive: !jail.isReleased,
                        duration: jail.duration,
                        color: '#8b0000'
                    });
                });
            }

            if (type === 'all' || type === 'ceza_puan') {
                if (cezaPuan && cezaPuan.punishments.length > 0) {
                    cezaPuan.punishments.forEach(punishment => {
                        let cezaType = 'Ceza Puanı';
                        if (punishment.type === 'chat_mute') cezaType = 'Chat Mute';
                        else if (punishment.type === 'voice_mute') cezaType = 'Voice Mute';
                        else if (punishment.type === 'jail') cezaType = 'Jail';
                        else if (punishment.type === 'ban') cezaType = 'Ban';
                        else if (punishment.type === 'kick') cezaType = 'Kick';
                        else if (punishment.type === 'warn') cezaType = 'Uyarı';

                        allPunishments.push({
                            type: `${cezaType} (+${punishment.points})`,
                            reason: punishment.reason,
                            staffId: punishment.staffId,
                            date: punishment.date || new Date(),
                            isActive: punishment.isActive,
                            points: punishment.points,
                            color: '#00ff00'
                        });
                    });
                }
            }

            // Aktif cezaları önce, sonra tarihe göre sırala
            allPunishments.sort((a, b) => {
                if (a.isActive && !b.isActive) return -1;
                if (!a.isActive && b.isActive) return 1;
                return b.date - a.date;
            });

            return allPunishments;
        }

        function truncateText(ctx, text, maxWidth) {
            if (ctx.measureText(text).width <= maxWidth) return text;
            while (text.length > 0 && ctx.measureText(text + '...').width > maxWidth) {
                text = text.slice(0, -1);
            }
            return text + '...';
        }

        async function generateCanvas(page, type) {
            const punishments = getPunishmentsByType(type);
            
            if (punishments.length === 0) {
                return null; // Boş sayfa için null döndür
            }

            const width = 900;
            const height = 555;
            const cardHeight = 60;
            const cardGap = 15;
            const cardStartY = 175;

            const canvas = createCanvas(width, height);
            const ctx = canvas.getContext('2d');

            // Arka plan: gradient
            const gradient = ctx.createLinearGradient(0, 0, 0, height);
            gradient.addColorStop(0, '#1A1A1A');
            gradient.addColorStop(1, '#0A0A0A');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);

            // Sunucu Bilgisi Kutusu
            ctx.save();
            ctx.beginPath();
            ctx.roundRect(10, 15, 300, 100, 15);
            ctx.fillStyle = '#1A1D20';
            ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
            ctx.shadowBlur = 15;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.restore();

            // Sunucu adı ve logo
            if (message.guild.iconURL()) {
                const guildIcon = await loadImage(message.guild.iconURL({ extension: 'png', size: 128 }));
                ctx.save();
                ctx.beginPath();
                ctx.arc(60, 65, 40, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();
                ctx.drawImage(guildIcon, 20, 25, 80, 80);
                ctx.restore();

                // İkon çerçevesi
                ctx.save();
                ctx.beginPath();
                ctx.arc(60, 65, 42, 0, Math.PI * 2, true);
                ctx.strokeStyle = '#FFD700';
                ctx.lineWidth = 4;
                ctx.stroke();
                ctx.restore();
            }
            ctx.font = 'bold 26px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.fillText(truncateText(ctx, message.guild.name, 170), 115, 60);
            ctx.font = '18px sans-serif';
            ctx.fillStyle = '#b9bbbe';

            // Kullanıcı Bilgisi Kutusu
            ctx.save();
            ctx.beginPath();
            ctx.roundRect(width - 310, 15, 300, 100, 15);
            ctx.fillStyle = '#1A1D20';
            ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
            ctx.shadowBlur = 15;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.restore();

            // Kullanıcı avatarı ve adı
            const avatar = await loadImage(user.displayAvatarURL({ extension: 'png', size: 128 }));
            ctx.save();
            ctx.beginPath();
            ctx.arc(width - 60, 65, 40, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(avatar, width - 100, 25, 80, 80);
            ctx.restore();

            // Avatar çerçevesi
            ctx.save();
            ctx.beginPath();
            ctx.arc(width - 60, 65, 42, 0, Math.PI * 2, true);
            ctx.strokeStyle = '#FFD700';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.restore();
            
            ctx.font = 'bold 22px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'right';
            ctx.fillText(truncateText(ctx, user.user.tag, 180), width - 115, 60);
            ctx.font = '18px sans-serif';
            ctx.fillStyle = '#b9bbbe';
            ctx.fillText('Ceza Geçmişi', width - 115, 90);
            ctx.textAlign = 'left';

            // Ceza türü bilgisi (ortada)
            const selectedType = punishmentTypes.find(t => t.value === type);
            if (selectedType) {
                ctx.font = 'bold 24px sans-serif';
                ctx.fillStyle = selectedType.color;
                ctx.textAlign = 'center';
                ctx.fillText(selectedType.label, width / 2, 65);
                ctx.textAlign = 'left';
            }

            // Ceza puanı bilgisi
            if (cezaPuan) {
                ctx.font = 'bold 16px sans-serif';
                ctx.fillStyle = '#00ff00';
                ctx.fillText(`Ceza Puan: ${cezaPuan.totalPoints}/300`, 115, 90);
            }

            // Başlık çizgisi
            ctx.strokeStyle = '#FFD700';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(30, 130);
            ctx.lineTo(width - 30, 130);
            ctx.stroke();

            // Sayfa numarası
            const itemsPerPage = 5;
            const totalPages = Math.ceil(punishments.length / itemsPerPage);
            ctx.font = 'bold 16px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'right';
            ctx.fillText(`Sayfa ${page + 1}/${totalPages}`, width - 30, height - 20);
            ctx.textAlign = 'left';

            // Kutu başlıkları
            ctx.font = 'bold 18px sans-serif';
            ctx.fillStyle = '#fff';
            ctx.fillText('Tür', 60, 155);
            ctx.fillText('Sebep', 200, 155);
            ctx.fillText('Yetkili', 450, 155);
            ctx.fillText('Tarih', 680, 155);

            // Ceza kartları
            const start = page * itemsPerPage;
            const end = start + itemsPerPage;
            const currentPunishments = punishments.slice(start, end);
            
            for (let i = 0; i < itemsPerPage; i++) {
                const punishment = currentPunishments[i];
                const currentCardY = cardStartY + (i * (cardHeight + cardGap));

                // Kart arka planı
                ctx.save();
                ctx.beginPath();
                ctx.roundRect(30, currentCardY, width - 60, cardHeight, 10);
                ctx.globalAlpha = 0.85;
                ctx.fillStyle = i % 2 === 0 ? '#1A1D20' : '#2C2F33';
                ctx.shadowColor = '#000';
                ctx.shadowBlur = 8;
                ctx.fill();
                ctx.shadowBlur = 0;
                ctx.globalAlpha = 1;
                ctx.restore();

                if (punishment) {
                    // Ceza türü rozeti - seçilen türün rengini kullan
                    ctx.save();
                    ctx.font = 'bold 16px sans-serif';
                    ctx.fillStyle = selectedType ? selectedType.color : punishment.color;
                    ctx.beginPath();
                    ctx.arc(75, currentCardY + 20, 15, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.fillStyle = '#fff';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(punishment.type.charAt(0), 75, currentCardY + 20);
                    ctx.restore();

                    // Ceza türü - seçilen türün rengini kullan
                    ctx.font = 'bold 14px sans-serif';
                    ctx.fillStyle = selectedType ? selectedType.color : punishment.color;
                    ctx.textAlign = 'center';
                    ctx.fillText(truncateText(ctx, punishment.type, 80), 75, currentCardY + 45);

                    // Sebep
                    ctx.font = 'bold 16px sans-serif';
                    ctx.fillStyle = '#fff';
                    ctx.textAlign = 'left';
                    const reasonText = truncateText(ctx, punishment.reason, 200);
                    ctx.fillText(reasonText, 200, currentCardY + cardHeight / 2 + 5);

                    // Yetkili
                    const staffMember = message.guild.members.cache.get(punishment.staffId) || 'Bilinmeyen Yetkili';
                    ctx.font = 'bold 16px sans-serif';
                    ctx.fillStyle = '#fff';
                    ctx.textAlign = 'left';
                    const staffText = truncateText(ctx, staffMember.user ? staffMember.user.tag : staffMember, 200);
                    ctx.fillText(staffText, 450, currentCardY + cardHeight / 2 + 5);

                    // Tarih
                    ctx.font = 'bold 15px monospace';
                    ctx.fillStyle = punishment.isActive ? '#00ff00' : '#f0f0f0';
                    ctx.textAlign = 'left';
                    const dateText = truncateText(ctx, new Date(punishment.date).toLocaleString('tr-TR'), 180);
                    ctx.fillText(dateText, 680, currentCardY + cardHeight / 2 + 5);
                }
            }

            ctx.textAlign = 'left';
            return canvas.toBuffer();
        }

        // İlk sayfa görselini oluştur
        const buffer = await generateCanvas(currentPage, currentType);
        if (!buffer) {
            return message.reply('Bu kullanıcının sicilinde hiç ceza bulunmuyor!');
        }

        const attachment = new AttachmentBuilder(buffer, { name: 'sicil.png' });

        // Select menü oluştur
        const selectMenuOptions = punishmentTypes.map(type => ({
            label: type.label,
            value: type.value,
            default: type.value === currentType,
        }));

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('sicil_type_select')
            .setPlaceholder('Ceza Türü Seçin...')
            .addOptions(selectMenuOptions);

        // Sayfa navigasyon butonları
        const prevButton = new ButtonBuilder()
            .setCustomId('sicil_prev_page')
            .setLabel('◀️ Önceki')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === 0);

        const nextButton = new ButtonBuilder()
            .setCustomId('sicil_next_page')
            .setLabel('Sonraki ▶️')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage >= Math.ceil(getPunishmentsByType(currentType).length / 5) - 1);

        const selectRow = new ActionRowBuilder().addComponents(selectMenu);
        const buttonRow = new ActionRowBuilder().addComponents(prevButton, nextButton);

        const msg = await message.reply({
            content: `${user} kullanıcısının ceza geçmişi:`,
            files: [attachment],
            components: [selectRow, buttonRow]
        });

        // Koleksiyoncu
        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 60000
        });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'sicil_type_select') {
                currentType = interaction.values[0];
                currentPage = 0; // Tür değişince sayfayı sıfırla
                
                const buffer = await generateCanvas(currentPage, currentType);
                if (!buffer) {
                    await interaction.update({
                        content: 'Bu ceza türünde hiç ceza bulunmuyor!',
                        files: [],
                        components: []
                    });
                    return;
                }

                const attachment = new AttachmentBuilder(buffer, { name: 'sicil.png' });
                
                // Select menüyü güncelle
                const updatedSelectMenu = new StringSelectMenuBuilder()
                    .setCustomId('sicil_type_select')
                    .setPlaceholder('Ceza Türü Seçin...')
                    .addOptions(punishmentTypes.map(type => ({
                        label: type.label,
                        value: type.value,
                        default: type.value === currentType,
                    })));

                // Butonları güncelle
                const updatedPrevButton = new ButtonBuilder()
                    .setCustomId('sicil_prev_page')
                    .setLabel('◀️ Önceki')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === 0);

                const updatedNextButton = new ButtonBuilder()
                    .setCustomId('sicil_next_page')
                    .setLabel('Sonraki ▶️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage >= Math.ceil(getPunishmentsByType(currentType).length / 5) - 1);

                const updatedSelectRow = new ActionRowBuilder().addComponents(updatedSelectMenu);
                const updatedButtonRow = new ActionRowBuilder().addComponents(updatedPrevButton, updatedNextButton);

                await interaction.update({
                    content: `${user} kullanıcısının ceza geçmişi:`,
                    files: [attachment],
                    components: [updatedSelectRow, updatedButtonRow]
                });
            } else if (interaction.customId === 'sicil_prev_page') {
                if (currentPage > 0) {
                    currentPage--;
                    const buffer = await generateCanvas(currentPage, currentType);
                    const attachment = new AttachmentBuilder(buffer, { name: 'sicil.png' });
                    
                    // Butonları güncelle
                    const updatedPrevButton = new ButtonBuilder()
                        .setCustomId('sicil_prev_page')
                        .setLabel('◀️ Önceki')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage === 0);

                    const updatedNextButton = new ButtonBuilder()
                        .setCustomId('sicil_next_page')
                        .setLabel('Sonraki ▶️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage >= Math.ceil(getPunishmentsByType(currentType).length / 5) - 1);

                    const updatedButtonRow = new ActionRowBuilder().addComponents(updatedPrevButton, updatedNextButton);

                    await interaction.update({
                        content: `${user} kullanıcısının ceza geçmişi:`,
                        files: [attachment],
                        components: [selectRow, updatedButtonRow]
                    });
                }
            } else if (interaction.customId === 'sicil_next_page') {
                const maxPages = Math.ceil(getPunishmentsByType(currentType).length / 5);
                if (currentPage < maxPages - 1) {
                    currentPage++;
                    const buffer = await generateCanvas(currentPage, currentType);
                    const attachment = new AttachmentBuilder(buffer, { name: 'sicil.png' });
                    
                    // Butonları güncelle
                    const updatedPrevButton = new ButtonBuilder()
                        .setCustomId('sicil_prev_page')
                        .setLabel('◀️ Önceki')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage === 0);

                    const updatedNextButton = new ButtonBuilder()
                        .setCustomId('sicil_next_page')
                        .setLabel('Sonraki ▶️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(currentPage >= maxPages - 1);

                    const updatedButtonRow = new ActionRowBuilder().addComponents(updatedPrevButton, updatedNextButton);

                    await interaction.update({
                        content: `${user} kullanıcısının ceza geçmişi:`,
                        files: [attachment],
                        components: [selectRow, updatedButtonRow]
                    });
                }
            }
        });

        collector.on('end', () => {
            const disabledSelectMenu = selectMenu.setDisabled(true);
            const disabledPrevButton = prevButton.setDisabled(true);
            const disabledNextButton = nextButton.setDisabled(true);
            
            const disabledSelectRow = new ActionRowBuilder().addComponents(disabledSelectMenu);
            const disabledButtonRow = new ActionRowBuilder().addComponents(disabledPrevButton, disabledNextButton);
            
            msg.edit({ components: [disabledSelectRow, disabledButtonRow] }).catch(() => {});
        });
    }
}; 