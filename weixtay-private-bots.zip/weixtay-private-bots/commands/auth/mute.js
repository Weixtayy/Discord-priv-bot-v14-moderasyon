const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    PermissionsBitField 
} = require('discord.js');
const Settings = require('../../models/Settings');
const ChatMute = require('../../models/ChatMute');
const CezaPuan = require('../../models/CezaPuan');
const mongoose = require('mongoose');

module.exports = {
    name: 'mute',
    description: 'Kullanıcıyı chat mute yapar',
    aliases: ['sustur', 'chatmute'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı!');

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator) && 
            !message.member.roles.cache.has(settings.muteYetkiliRole)) {
            return message.reply('Bu komutu kullanmak için mute yetkilisi olmalısın!');
        }

        // Kullanıcı kontrolü
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Chat mute edilecek kullanıcıyı etiketle veya ID gir!');
        if (user.id === message.author.id) return message.reply('Kendini chat mute edemezsin!');
        if (user.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply('Yönetici yetkisi olan kullanıcıyı chat mute edemezsin!');

        // Aktif chat mute kontrolü
        const activeChatMute = await ChatMute.findOne({ 
            guildId: message.guild.id, 
            userId: user.id, 
            isActive: true 
        });

        if (activeChatMute) {
            const remainingTime = activeChatMute.endTime.getTime() - Date.now();
            if (remainingTime > 0) {
                const staffMember = message.guild.members.cache.get(activeChatMute.staffId) || 'Bilinmeyen Yetkili';
                const muteEmbed = new EmbedBuilder()
                    .setTitle('⚠️ Aktif Chat Mute Uyarısı')
                    .setDescription(`${user} kullanıcısının zaten aktif chat mute'u bulunmaktadır!`)
                    .addFields(
                        { name: '📝 Mute Sebebi', value: activeChatMute.reason, inline: true },
                        { name: '⏰ Kalan Süre', value: formatDuration(remainingTime), inline: true },
                        { name: '👮 Mute Atan', value: `${staffMember}`, inline: true },
                        { name: '🕐 Mute Bitişi', value: `<t:${Math.floor(activeChatMute.endTime.getTime() / 1000)}:R>`, inline: true }
                    )
                    .setColor(0xffa500)
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp();
                
                return message.reply({ embeds: [muteEmbed] });
            }
        }

        // Sebep kontrolü
        const reason = args.slice(1).join(' ');
        if (!reason) {
            return message.reply('Chat mute sebebini yazın! Örnek: .mute @kullanıcı Spam yapıyor');
        }

        // Süre seçim menüsü
        const durationMenu = new StringSelectMenuBuilder()
            .setCustomId(`mute_duration_${user.id}`)
            .setPlaceholder('Chat mute süresini seçin')
            .addOptions([
                { label: '10 Dakika', value: '600000', description: '10 dakika chat mute' },
                { label: '15 Dakika', value: '900000', description: '15 dakika chat mute' },
                { label: '20 Dakika', value: '1200000', description: '20 dakika chat mute' },
                { label: '25 Dakika', value: '1500000', description: '25 dakika chat mute' },
                { label: '30 Dakika', value: '1800000', description: '30 dakika chat mute' },
                { label: '45 Dakika', value: '2700000', description: '45 dakika chat mute' },
                { label: '1 Saat', value: '3600000', description: '1 saat chat mute' },
                { label: '1.30 Saat', value: '5400000', description: '1.5 saat chat mute' }
            ]);

        const durationRow = new ActionRowBuilder().addComponents(durationMenu);

        const durationEmbed = new EmbedBuilder()
            .setTitle('💬 Chat Mute Sistemi')
            .setDescription(`${user} kullanıcısı için chat mute işlemi`)
            .addFields(
                { name: '📝 Sebep', value: reason, inline: false },
                { name: '⏰ Süre Seçimi', value: 'Aşağıdaki menüden süre seçin', inline: false }
            )
            .setColor(0x4ecdc4)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }));

        const msg = await message.reply({ embeds: [durationEmbed], components: [durationRow] });

        try {
            // Süre seçim handler
            const durationFilter = i => i.customId === `mute_duration_${user.id}` && i.user.id === message.author.id;
            const durationResponse = await msg.awaitMessageComponent({ filter: durationFilter, time: 60000 });
            const duration = parseInt(durationResponse.values[0]);

            // Chat mute uygula
            await applyChatMute(client, message, user, reason, duration, settings, durationResponse);

        } catch (error) {
            if (error.code === 'INTERACTION_COLLECTOR_ERROR') {
                await message.reply('Mute işlemi zaman aşımına uğradı!');
            } else {
                console.error('Mute hatası:', error);
                await message.reply('Mute işlemi sırasında bir hata oluştu!');
            }
        }
    }
};

// Chat mute uygula fonksiyonu
async function applyChatMute(client, message, user, reason, duration, settings, interaction) {
    const endTime = new Date(Date.now() + duration);
    
    try {
        // Önce eski aktif chat mute'u pasif yap
        await ChatMute.updateMany(
            { 
                guildId: message.guild.id, 
                userId: user.id, 
                isActive: true 
            },
            { isActive: false }
        );

        // Yeni chat mute kaydı oluştur
        const newMute = new ChatMute({
            guildId: message.guild.id,
            userId: user.id,
            staffId: message.author.id,
            reason: reason,
            duration: duration,
            endTime: endTime,
            isActive: true
        });
        await newMute.save();
        
    } catch (error) {
        console.error('Chat mute kayıt hatası:', error);
        
        // Fallback: MongoDB'ye direkt ekle
        try {
            const db = mongoose.connection.db;
            
            // Önce eski kayıtları pasif yap
            await db.collection('chat_mutes').updateMany(
                { 
                    guildId: message.guild.id, 
                    userId: user.id, 
                    isActive: true 
                },
                { $set: { isActive: false } }
            );
            
            const muteData = {
                guildId: message.guild.id,
                userId: user.id,
                staffId: message.author.id,
                reason: reason,
                duration: duration,
                endTime: endTime,
                isActive: true,
                createdAt: new Date()
            };
            await db.collection('chat_mutes').insertOne(muteData);
        } catch (fallbackError) {
            console.error('Fallback chat mute kayıt hatası:', fallbackError);
        }
    }

    // Ceza puanı ekle
    await addCezaPuan(user.id, message.guild.id, 'chat_mute', 5, reason, message.author.id, message);

    // Chat mute uygula
    if (settings.muteRole) {
        try {
            await user.roles.add(settings.muteRole, reason);
        } catch (error) {
            console.error('Chat mute hatası:', error);
        }
    }

    // Log gönder
    const logChannel = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === 'Mute-log');
    if (logChannel) {
        const logEmbed = new EmbedBuilder()
            .setTitle('💬 Chat Mute Uygulandı')
            .setDescription(`${user} kullanıcısı chat mute edildi`)
            .addFields(
                { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                { name: '⏰ Süre', value: formatDuration(duration), inline: true },
                { name: '📝 Sebep', value: reason, inline: false },
                { name: '👮 Yetkili', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
                { name: '🕐 Bitiş', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true }
            )
            .setColor(0x4ecdc4)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
    }

    // Başarı mesajı
    const successEmbed = new EmbedBuilder()
        .setTitle('✅ Chat Mute Başarılı')
        .setDescription(`${user} kullanıcısı chat mute edildi`)
        .addFields(
            { name: '⏰ Süre', value: formatDuration(duration), inline: true },
            { name: '🕐 Bitiş', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true }
        )
        .setColor(0x00ff00)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }));

    await interaction.update({ embeds: [successEmbed], components: [] });

    // Timeout ayarla
    setTimeout(async () => {
        await unmuteChatUser(client, user.id, message.guild.id, settings);
    }, duration);
}

// Süre formatla
function formatDuration(ms) {
    const minutes = Math.floor(ms / 60000);
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (hours > 0) {
        return `${hours} saat ${remainingMinutes > 0 ? remainingMinutes + ' dakika' : ''}`;
    } else {
        return `${minutes} dakika`;
    }
}

// Chat mute kaldır
async function unmuteChatUser(client, userId, guildId, settings) {
    try {
        const guild = client.guilds.cache.get(guildId);
        const user = guild.members.cache.get(userId);
        
        if (!user) return;

        // Chat mute kaydını güncelle
        await ChatMute.findOneAndUpdate(
            { guildId, userId, isActive: true },
            { isActive: false }
        );

        // Chat mute kaldır
        if (settings.muteRole && user.roles.cache.has(settings.muteRole)) {
            await user.roles.remove(settings.muteRole, 'Chat mute süresi doldu');
        }

        // Log gönder
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'Mute-log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setTitle('✅ Chat Mute Kaldırıldı')
                .setDescription(`${user} kullanıcısının chat mute süresi doldu`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                    { name: '⏰ Mute Türü', value: 'Chat', inline: true }
                )
                .setColor(0x00ff00)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    } catch (error) {
        console.error('Chat unmute hatası:', error);
    }
}

// Ceza puanı ekleme fonksiyonu
async function addCezaPuan(userId, guildId, type, points, reason, staffId, message) {
    try {
        let cezaPuan = await CezaPuan.findOne({ userId, guildId });
        if (!cezaPuan) {
            cezaPuan = new CezaPuan({ userId, guildId });
        }

        // Ceza geçmişine ekle
        cezaPuan.punishments.push({
            type: type,
            points: points,
            reason: reason,
            staffId: staffId,
            date: new Date(),
            isActive: true
        });

        // Toplam puanı güncelle
        cezaPuan.totalPoints += points;
        cezaPuan.updatedAt = new Date();

        // 300 puanı geçerse otomatik jail
        if (cezaPuan.totalPoints >= 300 && !cezaPuan.isAutoJailed) {
            cezaPuan.isAutoJailed = true;
            
            // Otomatik jail uygula
            const guild = await message.client.guilds.fetch(guildId);
            const member = await guild.members.fetch(userId);
            const settings = await Settings.findOne({ id: guildId });
            
            if (member && settings && settings.jailRole) {
                // Tüm rolleri al
                const userRoles = member.roles.cache.filter(role => role.id !== guildId).map(role => role.id);
                const adminRoles = member.roles.cache.filter(role => 
                    role.permissions.has(PermissionsBitField.Flags.Administrator) ||
                    role.permissions.has(PermissionsBitField.Flags.ManageChannels) ||
                    role.permissions.has(PermissionsBitField.Flags.ManageMessages) ||
                    role.permissions.has(PermissionsBitField.Flags.ManageRoles)
                ).map(role => role.id);

                // Jail rolünü ver
                await member.roles.set([settings.jailRole]);

                // Jail kaydı oluştur
                const Jail = require('../../models/Jail');
                const jail = new Jail({
                    userId: userId,
                    guildId: guildId,
                    reason: `Otomatik Jail - ${cezaPuan.totalPoints} ceza puanı`,
                    duration: 0, // Sınırsız
                    roles: userRoles,
                    adminRoles: adminRoles,
                    jailedBy: 'Sistem',
                    releaseAt: null
                });
                await jail.save();

                // Log gönder
                const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('🔒 Otomatik Jail Uygulandı')
                        .setDescription(`${member} kullanıcısı 300 puanı geçtiği için otomatik jail'e alındı`)
                        .addFields(
                            { name: '👤 Kullanıcı', value: `${member} (\`${member.id}\`)`, inline: true },
                            { name: '📊 Toplam Puan', value: `${cezaPuan.totalPoints}`, inline: true },
                            { name: '🔒 Jail Türü', value: 'Otomatik (Sınırsız)', inline: true }
                        )
                        .setColor(0xff0000)
                        .setThumbnail(member.displayAvatarURL({ dynamic: true }))
                        .setTimestamp();

                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
        }

        await cezaPuan.save();

        // Ceza puan logu gönder
        const guild = await message.client.guilds.fetch(guildId);
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
        if (logChannel) {
            const member = await guild.members.fetch(userId);
            await logChannel.send(`${member} kullanıcısına +${points} puan eklendi. Toplam: **${cezaPuan.totalPoints}/300**`);
        }

    } catch (error) {
        console.error('Ceza puanı ekleme hatası:', error);
    }
} 