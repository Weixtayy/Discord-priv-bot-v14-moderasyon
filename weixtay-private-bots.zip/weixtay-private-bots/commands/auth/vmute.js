const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    PermissionsBitField 
} = require('discord.js');
const Settings = require('../../models/Settings');
const VoiceMute = require('../../models/VoiceMute');
const CezaPuan = require('../../models/CezaPuan');
const mongoose = require('mongoose');

module.exports = {
    name: 'vmute',
    description: 'Kullanıcıyı ses mute yapar',
    aliases: ['sesmute', 'voicemute'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı!');

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator) && 
            !message.member.roles.cache.has(settings.muteYetkiliRole)) {
            return message.reply('Bu komutu kullanmak için mute yetkilisi olmalısın!');
        }

        // Kullanıcı kontrolü
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Ses mute edilecek kullanıcıyı etiketle veya ID gir!');
        if (user.id === message.author.id) return message.reply('Kendini ses mute edemezsin!');
        if (user.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply('Yönetici yetkisi olan kullanıcıyı ses mute edemezsin!');



        // Aktif ses mute kontrolü
        const activeVoiceMute = await VoiceMute.findOne({ 
            guildId: message.guild.id, 
            userId: user.id, 
            isActive: true 
        });

        if (activeVoiceMute) {
            const remainingTime = activeVoiceMute.endTime.getTime() - Date.now();
            if (remainingTime > 0) {
                const staffMember = message.guild.members.cache.get(activeVoiceMute.staffId) || 'Bilinmeyen Yetkili';
                const muteEmbed = new EmbedBuilder()
                    .setTitle('⚠️ Aktif Ses Mute Uyarısı')
                    .setDescription(`${user} kullanıcısının zaten aktif ses mute'u bulunmaktadır!`)
                    .addFields(
                        { name: '📝 Mute Sebebi', value: activeVoiceMute.reason, inline: true },
                        { name: '⏰ Kalan Süre', value: formatDuration(remainingTime), inline: true },
                        { name: '👮 Mute Atan', value: `${staffMember}`, inline: true },
                        { name: '🕐 Mute Bitişi', value: `<t:${Math.floor(activeVoiceMute.endTime.getTime() / 1000)}:R>`, inline: true }
                    )
                    .setColor(0xffa500)
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp();
                
                return message.reply({ embeds: [muteEmbed] });
            }
        }

        // Sebep kontrolü
        const reason = args.slice(1).join(' ');
        if (!reason) {
            return message.reply('Ses mute sebebini yazın! Örnek: .vmute @kullanıcı Spam yapıyor');
        }

        // Süre seçim menüsü
        const durationMenu = new StringSelectMenuBuilder()
            .setCustomId(`vmute_duration_${user.id}`)
            .setPlaceholder('Ses mute süresini seçin')
            .addOptions([
                { label: '10 Dakika', value: '600000', description: '10 dakika ses mute' },
                { label: '15 Dakika', value: '900000', description: '15 dakika ses mute' },
                { label: '20 Dakika', value: '1200000', description: '20 dakika ses mute' },
                { label: '25 Dakika', value: '1500000', description: '25 dakika ses mute' },
                { label: '30 Dakika', value: '1800000', description: '30 dakika ses mute' },
                { label: '45 Dakika', value: '2700000', description: '45 dakika ses mute' },
                { label: '1 Saat', value: '3600000', description: '1 saat ses mute' },
                { label: '1.30 Saat', value: '5400000', description: '1.5 saat ses mute' }
            ]);

        const durationRow = new ActionRowBuilder().addComponents(durationMenu);

        const durationEmbed = new EmbedBuilder()
            .setTitle('🔇 Ses Mute Sistemi')
            .setDescription(`${user} kullanıcısı için ses mute işlemi`)
            .addFields(
                { name: '📝 Sebep', value: reason, inline: false },
                { name: '⏰ Süre Seçimi', value: 'Aşağıdaki menüden süre seçin', inline: false }
            )
            .setColor(0xff6b6b)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }));

        const msg = await message.reply({ embeds: [durationEmbed], components: [durationRow] });

        try {
            // Süre seçim handler
            const durationFilter = i => i.customId === `vmute_duration_${user.id}` && i.user.id === message.author.id;
            const durationResponse = await msg.awaitMessageComponent({ filter: durationFilter, time: 60000 });
            const duration = parseInt(durationResponse.values[0]);

            // Ses mute uygula
            await applyVoiceMute(client, message, user, reason, duration, settings, durationResponse);

        } catch (error) {
            if (error.code === 'INTERACTION_COLLECTOR_ERROR') {
                await message.reply('Ses mute işlemi zaman aşımına uğradı!');
            } else {
                console.error('Ses mute hatası:', error);
                await message.reply('Ses mute işlemi sırasında bir hata oluştu!');
            }
        }
    }
};

// Ses mute uygula fonksiyonu
async function applyVoiceMute(client, message, user, reason, duration, settings, interaction) {
    const endTime = new Date(Date.now() + duration);
    
    try {
        // Önce eski aktif ses mute'u pasif yap
        await VoiceMute.updateMany(
            { 
                guildId: message.guild.id, 
                userId: user.id, 
                isActive: true 
            },
            { isActive: false }
        );

        // Yeni ses mute kaydı oluştur
        const newMute = new VoiceMute({
            guildId: message.guild.id,
            userId: user.id,
            staffId: message.author.id,
            reason: reason,
            duration: duration,
            endTime: endTime,
            isActive: true
        });
        await newMute.save();
        
    } catch (error) {
        console.error('Ses mute kayıt hatası:', error);
        
        // Fallback: MongoDB'ye direkt ekle
        try {
            const db = mongoose.connection.db;
            
            // Önce eski kayıtları pasif yap
            await db.collection('voice_mutes').updateMany(
                { 
                    guildId: message.guild.id, 
                    userId: user.id, 
                    isActive: true 
                },
                { $set: { isActive: false } }
            );
            
            const muteData = {
                guildId: message.guild.id,
                userId: user.id,
                staffId: message.author.id,
                reason: reason,
                duration: duration,
                endTime: endTime,
                isActive: true,
                createdAt: new Date()
            };
            await db.collection('voice_mutes').insertOne(muteData);
        } catch (fallbackError) {
            console.error('Fallback ses mute kayıt hatası:', fallbackError);
        }
    }

    // Ceza puanı ekle
    await addCezaPuan(user.id, message.guild.id, 'voice_mute', 5, reason, message.author.id, message);

    // Voice mute rolü uygula
    if (settings.voiceMuteRole) {
        try {
            // Eğer kullanıcının zaten bu rolü yoksa ekle
            if (!user.roles.cache.has(settings.voiceMuteRole)) {
                await user.roles.add(settings.voiceMuteRole, reason);
            }
        } catch (error) {
            console.error('Voice mute rolü verme hatası:', error);
        }
    }

    // Log gönder
    const logChannel = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === 'Mute-log');
    if (logChannel) {
        const logEmbed = new EmbedBuilder()
            .setTitle('🔇 Ses Mute Uygulandı')
            .setDescription(`${user} kullanıcısı ses mute edildi`)
            .addFields(
                { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                { name: '⏰ Süre', value: formatDuration(duration), inline: true },
                { name: '📝 Sebep', value: reason, inline: false },
                { name: '👮 Yetkili', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
                { name: '🕐 Bitiş', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true }
            )
            .setColor(0xff6b6b)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
    }

    // Başarı mesajı
    const successEmbed = new EmbedBuilder()
        .setTitle('✅ Ses Mute Başarılı')
        .setDescription(`${user} kullanıcısı ses mute edildi`)
        .addFields(
            { name: '⏰ Süre', value: formatDuration(duration), inline: true },
            { name: '🕐 Bitiş', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true }
        )
        .setColor(0x00ff00)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }));

    await interaction.update({ embeds: [successEmbed], components: [] });

    // Timeout ayarla
    setTimeout(async () => {
        await unmuteVoiceUser(client, user.id, message.guild.id, settings);
    }, duration);
}

// Süre formatla
function formatDuration(ms) {
    const minutes = Math.floor(ms / 60000);
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (hours > 0) {
        return `${hours} saat ${remainingMinutes > 0 ? remainingMinutes + ' dakika' : ''}`;
    } else {
        return `${minutes} dakika`;
    }
}

// Ses mute kaldır
async function unmuteVoiceUser(client, userId, guildId, settings) {
    try {
        const guild = client.guilds.cache.get(guildId);
        const user = guild.members.cache.get(userId);
        
        if (!user) return;

        // Ses mute kaydını güncelle
        await VoiceMute.findOneAndUpdate(
            { guildId, userId, isActive: true },
            { isActive: false }
        );

        // Voice mute rolünü kaldır
        if (settings.voiceMuteRole && user.roles.cache.has(settings.voiceMuteRole)) {
            await user.roles.remove(settings.voiceMuteRole, 'Voice mute süresi doldu');
        }

        // Log gönder
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'Mute-log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setTitle('✅ Ses Mute Kaldırıldı')
                .setDescription(`${user} kullanıcısının ses mute süresi doldu`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                    { name: '⏰ Mute Türü', value: 'Ses', inline: true }
                )
                .setColor(0x00ff00)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }
    } catch (error) {
        console.error('Ses unmute hatası:', error);
    }
}

// Ceza puanı ekleme fonksiyonu
async function addCezaPuan(userId, guildId, type, points, reason, staffId, message) {
    try {
        let cezaPuan = await CezaPuan.findOne({ userId, guildId });
        if (!cezaPuan) {
            cezaPuan = new CezaPuan({ userId, guildId });
        }

        // Ceza geçmişine ekle
        cezaPuan.punishments.push({
            type: type,
            points: points,
            reason: reason,
            staffId: staffId,
            date: new Date(),
            isActive: true
        });

        // Toplam puanı güncelle
        cezaPuan.totalPoints += points;
        cezaPuan.updatedAt = new Date();

        await cezaPuan.save();

        // Ceza puan logu gönder
        const guild = await message.client.guilds.fetch(guildId);
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
        if (logChannel) {
            const member = await guild.members.fetch(userId);
            await logChannel.send(`${member} kullanıcısına +${points} puan eklendi. Toplam: **${cezaPuan.totalPoints}/300**`);
        }

    } catch (error) {
        console.error('Ceza puanı ekleme hatası:', error);
    }
} 