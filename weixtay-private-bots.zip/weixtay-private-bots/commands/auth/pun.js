const { EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Settings = require('../../models/Settings');
const CezaPuan = require('../../models/CezaPuan');

module.exports = {
    name: 'pun',
    description: 'Kullanıcının ceza puanlarını gösterir',
    aliases: ['puan', 'cezapuan'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı!');

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Sadece yönetici kontrolü
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('Bu komutu kullanmak için yönetici yetkisine sahip olmalısın!');
        }

        // Kullanıcı kontrolü
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Ceza puanı görüntülenecek kullanıcıyı etiketle veya ID gir!');

        // Ceza puanı bul
        let cezaPuan = await CezaPuan.findOne({ userId: user.id, guildId: message.guild.id });
        if (!cezaPuan) {
            cezaPuan = new CezaPuan({ userId: user.id, guildId: message.guild.id });
            await cezaPuan.save();
        }

        // Aktif cezaları filtrele
        const activePunishments = cezaPuan.punishments.filter(p => p.isActive);
        const totalActivePoints = activePunishments.reduce((sum, p) => sum + p.points, 0);

        const embed = new EmbedBuilder()
            .setTitle('📊 Ceza Puan Sistemi')
            .setDescription(`${user} kullanıcısının ceza puan bilgileri`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setColor(cezaPuan.totalPoints >= 300 ? 0xff0000 : cezaPuan.totalPoints >= 200 ? 0xff6600 : 0x00ff00)
            .addFields(
                { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                { name: '📊 Toplam Puan', value: `${cezaPuan.totalPoints}/300`, inline: true },
                { name: '⚡ Aktif Puan', value: `${totalActivePoints}`, inline: true },
                { name: '🔒 Otomatik Jail', value: cezaPuan.isAutoJailed ? '✅ Evet' : '❌ Hayır', inline: true },
                { name: '📅 Son Güncelleme', value: `<t:${Math.floor(cezaPuan.updatedAt.getTime() / 1000)}:R>`, inline: true }
            )
            .setFooter({ text: `Sorgulayan: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        // Ceza geçmişi (son 10 ceza)
        if (cezaPuan.punishments.length > 0) {
            const recentPunishments = cezaPuan.punishments
                .sort((a, b) => b.date - a.date)
                .slice(0, 10);

            const punishmentList = recentPunishments.map((p, index) => {
                const status = p.isActive ? '🟢' : '🔴';
                const date = Math.floor(p.date.getTime() / 1000);
                return `${status} **${index + 1}.** ${p.type.toUpperCase()} (+${p.points}p) - ${p.reason} <t:${date}:R>`;
            }).join('\n');

            embed.addFields({
                name: '📜 Son Ceza Geçmişi (10)',
                value: punishmentList || 'Ceza geçmişi yok',
                inline: false
            });
        }

        // Puan durumu uyarısı
        if (cezaPuan.totalPoints >= 300) {
            embed.addFields({
                name: '⚠️ Uyarı',
                value: 'Bu kullanıcı 300 puanı geçtiği için otomatik jail sisteminde! Sadece yöneticiler çıkarabilir.',
                inline: false
            });
        } else if (cezaPuan.totalPoints >= 200) {
            embed.addFields({
                name: '⚠️ Uyarı',
                value: 'Bu kullanıcı 200+ puanı var! Dikkatli olun.',
                inline: false
            });
        }

        // Sıfırlama butonu
        const resetButton = new ButtonBuilder()
            .setCustomId(`pun_reset_${user.id}`)
            .setLabel('Ceza Puanını Sıfırla')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('🗑️');

        const buttonRow = new ActionRowBuilder().addComponents(resetButton);

        const msg = await message.reply({ embeds: [embed], components: [buttonRow] });

        // Buton handler
        try {
            const filter = i => i.customId === `pun_reset_${user.id}` && i.user.id === message.author.id;
            const response = await msg.awaitMessageComponent({ filter, time: 60000 });

            // Ceza puanını sıfırla
            cezaPuan.punishments = [];
            cezaPuan.totalPoints = 0;
            cezaPuan.isAutoJailed = false;
            cezaPuan.updatedAt = new Date();
            await cezaPuan.save();

            const successEmbed = new EmbedBuilder()
                .setTitle('✅ Ceza Puanı Sıfırlandı')
                .setDescription(`${user} kullanıcısının tüm ceza puanları sıfırlandı`)
                .setColor(0x00ff00)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await response.update({ embeds: [successEmbed], components: [] });

        } catch (error) {
            if (error.code === 'INTERACTION_COLLECTOR_ERROR') {
                await message.reply('Sıfırlama işlemi zaman aşımına uğradı!');
            } else {
                console.error('Pun sıfırlama hatası:', error);
                await message.reply('Sıfırlama işlemi sırasında bir hata oluştu!');
            }
        }
    }
}; 