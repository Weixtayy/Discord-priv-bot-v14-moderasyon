const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    PermissionsBitField 
} = require('discord.js');
const Settings = require('../../models/Settings');
const ChatMute = require('../../models/ChatMute');
const VoiceMute = require('../../models/VoiceMute');

module.exports = {
    name: 'unmute',
    description: 'Kullanıcının mute\'unu kaldırır',
    aliases: ['susturma'],
    async execute(client, message, args) {
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı!');

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Yetki kontrolü
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator) && 
            !message.member.roles.cache.has(settings.muteYetkiliRole)) {
            return message.reply('Bu komutu kullanmak için mute yetkilisi olmalısın!');
        }

        // Kullanıcı kontrolü
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return message.reply('Unmute edilecek kullanıcıyı etiketle veya ID gir!');

        // Sebep kontrolü
        const reason = args.slice(1).join(' ');
        if (!reason) {
            return message.reply('Unmute sebebini yazın! Örnek: .unmute @kullanıcı Özür diledi');
        }

        // Aktif mute kontrolü - hem voice hem chat için kontrol et
        const activeVoiceMutes = await VoiceMute.find({ 
            guildId: message.guild.id, 
            userId: user.id, 
            isActive: true 
        });

        const activeChatMutes = await ChatMute.find({ 
            guildId: message.guild.id, 
            userId: user.id, 
            isActive: true 
        });

        if (activeVoiceMutes.length === 0 && activeChatMutes.length === 0) {
            return message.reply('Bu kullanıcının aktif mute\'u yok!');
        }

        // Hangi türde mute var kontrol et
        const voiceMute = activeVoiceMutes[0]; // İlk aktif ses mute
        const chatMute = activeChatMutes[0]; // İlk aktif chat mute

        // Mute türü butonları
        const voiceButton = new ButtonBuilder()
            .setCustomId(`unmute_voice_${user.id}`)
            .setLabel('🔊 Ses Unmute')
            .setStyle(voiceMute ? ButtonStyle.Danger : ButtonStyle.Secondary)
            .setEmoji('🔊')
            .setDisabled(!voiceMute);

        const chatButton = new ButtonBuilder()
            .setCustomId(`unmute_chat_${user.id}`)
            .setLabel('💬 Chat Unmute')
            .setStyle(chatMute ? ButtonStyle.Primary : ButtonStyle.Secondary)
            .setEmoji('💬')
            .setDisabled(!chatMute);

        const buttonRow = new ActionRowBuilder().addComponents(voiceButton, chatButton);

        // Mute bilgilerini hazırla
        const muteInfo = [];
        if (voiceMute) {
            const remainingTime = voiceMute.endTime.getTime() - Date.now();
            const remainingText = remainingTime > 0 ? `(Kalan: ${formatDuration(remainingTime)})` : '(Süresi dolmuş)';
            muteInfo.push(`🔇 **Ses Mute:** ${formatDuration(voiceMute.duration)} - ${voiceMute.reason} ${remainingText}`);
        }
        if (chatMute) {
            const remainingTime = chatMute.endTime.getTime() - Date.now();
            const remainingText = remainingTime > 0 ? `(Kalan: ${formatDuration(remainingTime)})` : '(Süresi dolmuş)';
            muteInfo.push(`💬 **Chat Mute:** ${formatDuration(chatMute.duration)} - ${chatMute.reason} ${remainingText}`);
        }

        const unmuteEmbed = new EmbedBuilder()
            .setTitle('🔊 Unmute Sistemi')
            .setDescription(`${user} kullanıcısının mute\'unu kaldır`)
            .addFields(
                { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                { name: '📝 Unmute Sebebi', value: reason, inline: false },
                { name: '🎯 Aktif Mute\'lar', value: muteInfo.join('\n') || 'Mute bulunamadı', inline: false }
            )
            .setColor(0x00ff00)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: `Unmute eden: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

        const msg = await message.reply({ embeds: [unmuteEmbed], components: [buttonRow] });

        try {
            // Buton seçim handler
            const filter = i => (i.customId.startsWith('unmute_voice_') || i.customId.startsWith('unmute_chat_')) && 
                               i.customId.includes(`_${user.id}`) && 
                               i.user.id === message.author.id;

            const response = await msg.awaitMessageComponent({ filter, time: 60000 });
            const unmuteType = response.customId.startsWith('unmute_voice_') ? 'voice' : 'chat';

            // Unmute uygula
            const muteRecord = unmuteType === 'voice' ? voiceMute : chatMute;
            await applyUnmute(client, message, user, reason, unmuteType, settings, response, muteRecord);

        } catch (error) {
            // Collector hiç interaction almazsa bu hatayı fırlatır
            if (
                error.message?.includes('Collector received no interactions before ending') ||
                error.code === 'INTERACTION_COLLECTOR_ERROR' ||
                error.code === 'INTERACTION_COLLECTOR_TIMEOUT'
            ) {
                // Sessizce butonları temizle
                await msg.edit({ components: [] }).catch(() => {});
            } else {
                console.error('Unmute hatası:', error);
                await message.reply('Unmute işlemi sırasında bir hata oluştu!');
            }
        }
    }
};

// Unmute uygula fonksiyonu
async function applyUnmute(client, message, user, reason, unmuteType, settings, interaction, muteRecord) {
    try {
        if (!muteRecord) {
            await interaction.update({ content: 'Mute kaydı bulunamadı!', embeds: [], components: [] });
            return;
        }

        // Mute kaydını pasif yap
        muteRecord.isActive = false;
        await muteRecord.save();

        // Eğer süresi dolmuşsa pasif yap
        const remainingTime = muteRecord.endTime.getTime() - Date.now();
        if (remainingTime <= 0) {
            console.log(`${user.user.tag} kullanıcısının ${unmuteType} mute süresi dolmuş, pasif yapıldı`);
        }

        // Unmute uygula
        if (unmuteType === 'voice') {
            // Voice unmute - rol kaldır
            if (settings.voiceMuteRole && user.roles.cache.has(settings.voiceMuteRole)) {
                await user.roles.remove(settings.voiceMuteRole, reason);
            }
        } else {
            // Chat unmute
            if (settings.muteRole && user.roles.cache.has(settings.muteRole)) {
                await user.roles.remove(settings.muteRole, reason);
            }
        }

        // Log gönder
        const logChannel = message.guild.channels.cache.find(ch => ch.name.toLowerCase() === 'Mute-log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setTitle(`🔊 ${unmuteType === 'voice' ? 'Ses' : 'Chat'} Unmute Uygulandı`)
                .setDescription(`${user} kullanıcısının mute'u kaldırıldı`)
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (\`${user.id}\`)`, inline: true },
                    { name: '📝 Sebep', value: reason, inline: false },
                    { name: '👮 Yetkili', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
                    { name: '🎯 Mute Türü', value: unmuteType === 'voice' ? 'Ses' : 'Chat', inline: true }
                )
                .setColor(0x00ff00)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await logChannel.send({ embeds: [logEmbed] });
        }

        // Başarı mesajı
        const successEmbed = new EmbedBuilder()
            .setTitle('✅ Unmute Başarılı')
            .setDescription(`${user} kullanıcısının ${unmuteType === 'voice' ? 'ses' : 'chat'} mute'u kaldırıldı`)
            .addFields(
                { name: '📝 Sebep', value: reason, inline: true },
                { name: '👮 Yetkili', value: `${message.author}`, inline: true }
            )
            .setColor(0x00ff00)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        await interaction.update({ embeds: [successEmbed], components: [] });

    } catch (error) {
        console.error('Unmute uygulama hatası:', error);
        await interaction.update({ content: 'Unmute işlemi sırasında bir hata oluştu!', embeds: [], components: [] });
    }
}

// Süre formatla fonksiyonu
function formatDuration(ms) {
    if (ms <= 0) return '0 dakika';
    
    const minutes = Math.floor(ms / 60000);
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (hours > 0) {
        return `${hours} saat ${remainingMinutes > 0 ? remainingMinutes + ' dakika' : ''}`;
    } else {
        return `${minutes} dakika`;
    }
} 