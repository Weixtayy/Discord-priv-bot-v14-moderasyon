const { PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const Settings = require('../../models/Settings');
const Jail = require('../../models/Jail');
const CezaPuan = require('../../models/CezaPuan');

module.exports = {
    name: 'jail',
    description: 'Belirtilen kullanıcıyı jail sistemine alır.',
    category: 'auth',
    async execute(client, message, args) {
        // Yetki kontrolü
        const settings = await Settings.findOne({ id: message.guild.id });
        if (!settings) return message.reply('Sunucu ayarları bulunamadı! Lütfen `.setup` komutunu kullanın.');

        const hasPermission = message.member.permissions.has(PermissionFlagsBits.Administrator) || 
                            (settings.jailHammer && message.member.roles.cache.has(settings.jailHammer));
        
        if (!hasPermission) {
            return message.reply('Bu komutu kullanmak için "Yönetici" yetkisine veya Jail Hammer rolüne sahip olmalısın!');
        }

        // Komut kanalı kontrolü
        if (!settings.commandChannel) {
            return message.reply('Komut kanalı ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }
        if (message.channel.id !== settings.commandChannel) {
            return message.reply(`Bu komutu sadece <#${settings.commandChannel}> kanalında kullanabilirsin!`);
        }

        // Jail rolü kontrolü
        if (!settings.jailRole) {
            return message.reply('Jail rolü ayarlanmamış! Lütfen `.setup` komutunu kullanın.');
        }

        const targetUser = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
        if (!targetUser) {
            return message.reply('Lütfen jail atmak istediğiniz kullanıcıyı etiketleyin veya ID\'sini girin.');
        }

        const member = await message.guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) {
            return message.reply('Bu kullanıcı sunucuda bulunamadı!');
        }

        // Bot kontrolü
        if (member.user.bot) {
            return message.reply('Botları jail\'e atamazsın!');
        }

        if (member.roles.cache.has(settings.jailRole)) {
            return message.reply('Bu kullanıcı zaten jail sisteminde!');
        }

        // Bot yetki kontrolü
        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply('Bot\'un rol yönetme yetkisi yok! Lütfen bot\'a rol yönetme yetkisi verin.');
        }

        // Jail rolü kontrolü
        const jailRole = message.guild.roles.cache.get(settings.jailRole);
        if (!jailRole) {
            return message.reply('Jail rolü bulunamadı! Lütfen `.setup` komutunu kullanarak jail rolünü ayarlayın.');
        }

        // Bot'un rolü jail rolünden yüksek mi kontrol et
        if (message.guild.members.me.roles.highest.position <= jailRole.position) {
            return message.reply('Bot\'un rolü jail rolünden düşük! Lütfen bot\'un rolünü jail rolünden yukarı taşıyın.');
        }

        // Sebep kontrolü
        const reason = args.slice(1).join(' ');
        if (!reason) {
            return message.reply('Jail sebebini yazın! Örnek: `.jail @kullanıcı Sebep`');
        }

        // Jail süreleri menüsü
        const jailMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('jailDuration')
                .setPlaceholder('Jail süresini seçin')
                .addOptions([
                    { 
                        label: "1 Gün",
                        value: "1",
                        description: "24 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "2 Gün",
                        value: "2",
                        description: "48 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "3 Gün",
                        value: "3",
                        description: "72 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "4 Gün",
                        value: "4",
                        description: "96 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "5 Gün",
                        value: "5",
                        description: "120 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "6 Gün",
                        value: "6",
                        description: "144 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "7 Gün",
                        value: "7",
                        description: "168 saat",
                        emoji: "⏰"
                    },
                    { 
                        label: "Sınırsız Jail",
                        value: "0",
                        description: "Süresiz",
                        emoji: "⛔"
                    }
                ])
        );

        const msg = await message.reply({
            content: `${targetUser} kullanıcısı için jail süresini seçin:\n**Sebep:** ${reason}`,
            components: [jailMenu]
        });

        const filter = i => i.user.id === message.author.id && i.customId === 'jailDuration';
        const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (interaction) => {
            const duration = parseInt(interaction.values[0]);

            try {
                // Kullanıcının rollerini kaydet
                const userRoles = member.roles.cache.filter(role => role.id !== message.guild.id).map(role => role.id);
                const adminRoles = member.roles.cache.filter(role => 
                    role.permissions.has(PermissionFlagsBits.Administrator) ||
                    role.permissions.has(PermissionFlagsBits.ManageChannels) ||
                    role.permissions.has(PermissionFlagsBits.ManageMessages) ||
                    role.permissions.has(PermissionFlagsBits.ManageRoles)
                ).map(role => role.id);

                // Rolleri al ve jail rolünü ver
                await member.roles.set([settings.jailRole]);

                // Jail kaydını oluştur
                const releaseAt = duration === 0 ? null : new Date(new Date().setDate(new Date().getDate() + duration));

                const jail = new Jail({
                    userId: targetUser.id,
                    guildId: message.guild.id,
                    reason: reason,
                    duration: duration,
                    roles: userRoles,
                    adminRoles: adminRoles,
                    jailedBy: message.author.id,
                    releaseAt: releaseAt
                });
                await jail.save();

                // Ceza puanı ekle
                await addCezaPuan(targetUser.id, message.guild.id, 'jail', 15, reason, message.author.id, message);

                // Log mesajı
                const logChannel = message.guild.channels.cache.find(c => c.name === 'jail-log');
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setColor('#FFA500')
                        .setTitle('Kullanıcı Jail\'e Alındı')
                        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
                        .addFields(
                            { name: 'Kullanıcı', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                            { name: 'Yetkili', value: `${message.author.tag} (${message.author.id})`, inline: true },
                            { name: 'Sebep', value: reason, inline: false },
                            { name: 'Süre', value: duration === 0 ? 'Sınırsız' : `${duration} Gün`, inline: true },
                            { name: 'Bitiş Tarihi', value: duration === 0 ? 'Sınırsız' : releaseAt.toLocaleString('tr-TR'), inline: true }
                        )
                        .setFooter({ text: 'Jail Sistemi' });

                    await logChannel.send({ embeds: [embed] });
                }

                await interaction.update({
                    content: `${targetUser} kullanıcısı ${duration === 0 ? 'sınırsız' : duration + ' gün'} süreyle jail'e alındı!\nSebep: ${reason}`,
                    components: []
                });

            } catch (error) {
                console.error('Jail hatası:', error);
                await interaction.update({
                    content: 'Jail işlemi sırasında bir hata oluştu!',
                    components: []
                });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                msg.edit({
                    content: 'Jail işlemi iptal edildi!',
                    components: []
                });
            }
        });
    },
};

// Ceza puanı ekleme fonksiyonu
async function addCezaPuan(userId, guildId, type, points, reason, staffId, message) {
    try {
        let cezaPuan = await CezaPuan.findOne({ userId, guildId });
        if (!cezaPuan) {
            cezaPuan = new CezaPuan({ userId, guildId });
        }

        // Ceza geçmişine ekle
        cezaPuan.punishments.push({
            type: type,
            points: points,
            reason: reason,
            staffId: staffId,
            date: new Date(),
            isActive: true
        });

        // Toplam puanı güncelle
        cezaPuan.totalPoints += points;
        cezaPuan.updatedAt = new Date();

        // 300 puanı geçerse otomatik jail
        if (cezaPuan.totalPoints >= 300 && !cezaPuan.isAutoJailed) {
            cezaPuan.isAutoJailed = true;
            
            // Otomatik jail uygula
            const guild = await message.client.guilds.fetch(guildId);
            const member = await guild.members.fetch(userId);
            const settings = await Settings.findOne({ id: guildId });
            
            if (member && settings && settings.jailRole) {
                // Tüm rolleri al
                const userRoles = member.roles.cache.filter(role => role.id !== guildId).map(role => role.id);
                const adminRoles = member.roles.cache.filter(role => 
                    role.permissions.has(PermissionFlagsBits.Administrator) ||
                    role.permissions.has(PermissionFlagsBits.ManageChannels) ||
                    role.permissions.has(PermissionFlagsBits.ManageMessages) ||
                    role.permissions.has(PermissionFlagsBits.ManageRoles)
                ).map(role => role.id);

                // Jail rolünü ver
                await member.roles.set([settings.jailRole]);

                // Jail kaydı oluştur
                const Jail = require('../../models/Jail');
                const jail = new Jail({
                    userId: userId,
                    guildId: guildId,
                    reason: `Otomatik Jail - ${cezaPuan.totalPoints} ceza puanı`,
                    duration: 0, // Sınırsız
                    roles: userRoles,
                    adminRoles: adminRoles,
                    jailedBy: 'Sistem',
                    releaseAt: null
                });
                await jail.save();

                // Log gönder
                const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('🔒 Otomatik Jail Uygulandı')
                        .setDescription(`${member} kullanıcısı 300 puanı geçtiği için otomatik jail'e alındı`)
                        .addFields(
                            { name: '👤 Kullanıcı', value: `${member} (\`${member.id}\`)`, inline: true },
                            { name: '📊 Toplam Puan', value: `${cezaPuan.totalPoints}`, inline: true },
                            { name: '🔒 Jail Türü', value: 'Otomatik (Sınırsız)', inline: true }
                        )
                        .setColor(0xff0000)
                        .setThumbnail(member.displayAvatarURL({ dynamic: true }))
                        .setTimestamp();

                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
        }

        await cezaPuan.save();

        // Ceza puan logu gönder
        const guild = await message.client.guilds.fetch(guildId);
        const logChannel = guild.channels.cache.find(ch => ch.name.toLowerCase() === 'ceza-puan-log');
        if (logChannel) {
            const member = await guild.members.fetch(userId);
            await logChannel.send(`${member} kullanıcısına +${points} puan eklendi. Toplam: **${cezaPuan.totalPoints}/300**`);
        }

    } catch (error) {
        console.error('Ceza puanı ekleme hatası:', error);
    }
} 