const mongoose = require('mongoose');
const UserStats = require('./models/UserStats');
const config = require('./config');

async function fixInvitesData() {
    try {
        await mongoose.connect(config.mongoURL);
        console.log('MongoDB bağlantısı başarılı');

        // Tüm UserStats kayıtlarını bul
        const allStats = await UserStats.find({});
        console.log(`${allStats.length} UserStats kaydı bulundu`);

        let fixedCount = 0;
        for (const stat of allStats) {
            let needsUpdate = false;
            
            // Eğer invites bir obje ise, total değerini al
            if (stat.invites && typeof stat.invites === 'object') {
                stat.invites = stat.invites.total || 0;
                needsUpdate = true;
            }
            
            // Eğer invites undefined veya null ise, 0 yap
            if (stat.invites === undefined || stat.invites === null) {
                stat.invites = 0;
                needsUpdate = true;
            }

            // Eğer invitedUsers array değilse, boş array yap
            if (!Array.isArray(stat.invitedUsers)) {
                stat.invitedUsers = [];
                needsUpdate = true;
            }

            // Eğer lastInvitedBy undefined ise, null yap
            if (stat.lastInvitedBy === undefined) {
                stat.lastInvitedBy = null;
                needsUpdate = true;
            }

            // Eğer lastInviteCode undefined ise, null yap
            if (stat.lastInviteCode === undefined) {
                stat.lastInviteCode = null;
                needsUpdate = true;
            }

            if (needsUpdate) {
                await stat.save();
                fixedCount++;
                console.log(`Kayıt düzeltildi: ${stat.userId}`);
            }
        }

        console.log(`Toplam ${fixedCount} kayıt düzeltildi`);
        console.log('Veritabanı düzeltme işlemi tamamlandı!');

    } catch (error) {
        console.error('Hata:', error);
    } finally {
        await mongoose.disconnect();
        console.log('MongoDB bağlantısı kapatıldı');
    }
}

fixInvitesData(); 