module.exports = {
    token: "", // bot tokeni
    prefix: ".", // bot prefixi
    botStatus: "Weixtay", // bot durumunu belirle
    voiceChannelId: "",
    mongoURL: "", // mongodb bağlantısı
    owners: ["",""], // ownerların idleri
    embedColor: "#2f3136", // embed rengi
}; 

// not : level sistemimde kanal oto isim çekiyor level-up kanalının ismi olmalı. ona özel kanal açın .