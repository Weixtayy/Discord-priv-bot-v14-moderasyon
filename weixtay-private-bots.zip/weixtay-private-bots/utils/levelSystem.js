const { AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const { request } = require('undici');
const Level = require('../models/Level');

// Discord rozetlerini döndür (emoji veya unicode)
function getBadges(user) {
    if (!user || !user.user) return [];
    const flags = user.user.flags?.toArray ? user.user.flags.toArray() : [];
    const badgeMap = {
        'Staff': '🛡️',
        'Partner': '🤝',
        'Hypesquad': '🎉',
        'BugHunterLevel1': '🐞',
        'BugHunterLevel2': '🐞',
        'HypeSquadOnlineHouse1': '🏠',
        'HypeSquadOnlineHouse2': '🏠',
        'HypeSquadOnlineHouse3': '🏠',
        'PremiumEarlySupporter': '💎',
        'VerifiedBot': '🤖',
        'VerifiedDeveloper': '👨‍💻',
        'CertifiedModerator': '🧑‍⚖️',
        'ActiveDeveloper': '⚡',
    };
    // Nitro
    if (user.user.avatar && user.user.avatar.startsWith('a_')) flags.push('Nitro');
    // Sunucu boost
    if (user.premiumSince) flags.push('Booster');
    // Görevli
    if (user.user.flags && user.user.flags.has && user.user.flags.has(1 << 18)) flags.push('GuildEvents');
    // Bot
    if (user.user.bot) flags.push('Bot');
    // Early supporter
    if (user.user.flags && user.user.flags.has && user.user.flags.has(1 << 9)) flags.push('Early');
    // Map
    const customBadges = {
        'Nitro': '💠',
        'Booster': '🚀',
        'GuildEvents': '🗓️',
        'Bot': '🤖',
        'Early': '🌟',
    };
    return [
        ...flags.map(f => badgeMap[f] || customBadges[f] || '').filter(Boolean)
    ];
}

// XP ekle ve seviye atlat (yeni model)
async function addXP({ userId, guildId, type = 'message' }) {
    let levelData = await Level.findOne({ userId, guildId });
    if (!levelData) {
        levelData = new Level({ userId, guildId });
    }
    let leveledUp = false;
    let newLevel = 0;
    let activity = type;
    if (type === 'message') {
        const now = Date.now();
        if (levelData.lastMessageXP && now - new Date(levelData.lastMessageXP).getTime() < 30000) return { leveledUp: false, levelData, activity };
        levelData.lastMessageXP = new Date();
        levelData.messageXP += 15;
        let nextLevelXP = levelData.messageLevel * 100;
        while (levelData.messageXP >= nextLevelXP) {
            levelData.messageXP -= nextLevelXP;
            levelData.messageLevel++;
            leveledUp = true;
            newLevel = levelData.messageLevel;
            nextLevelXP = levelData.messageLevel * 100;
        }
    } else if (type === 'voice') {
        const now = Date.now();
        if (levelData.lastVoiceXP && now - new Date(levelData.lastVoiceXP).getTime() < 5 * 60 * 1000) return { leveledUp: false, levelData, activity };
        levelData.lastVoiceXP = new Date();
        levelData.voiceXP += 30;
        let nextLevelXP = levelData.voiceLevel * 100;
        while (levelData.voiceXP >= nextLevelXP) {
            levelData.voiceXP -= nextLevelXP;
            levelData.voiceLevel++;
            leveledUp = true;
            newLevel = levelData.voiceLevel;
            nextLevelXP = levelData.voiceLevel * 100;
        }
    }
    await levelData.save();
    return { leveledUp, levelData, activity, newLevel };
}

// Kullanıcı profil fotoğrafını buffer olarak çek
async function fetchUserAvatar(user) {
    let avatarUrl = (user.user || user).displayAvatarURL({ dynamic: false, format: 'png', size: 128 });
    try {
        const { body } = await request(avatarUrl);
        const avatarBuffer = await body.arrayBuffer();
        return await loadImage(Buffer.from(avatarBuffer));
    } catch {
        const { body } = await request('https://cdn.discordapp.com/embed/avatars/0.png');
        const avatarBuffer = await body.arrayBuffer();
        return await loadImage(Buffer.from(avatarBuffer));
    }
}

// Level up kartı (otomatik atılan)
async function createLevelUpCard({ user, activity, newLevel }) {
    const width = 720;
    const height = 260;
    const padding = 24;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Helpers
    const drawRoundedRect = (x, y, w, h, r) => {
        const radius = Math.min(r, h / 2, w / 2);
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + w - radius, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
        ctx.lineTo(x + w, y + h - radius);
        ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
        ctx.lineTo(x + radius, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    };

    // Background: diagonal gradient + subtle overlay
    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, '#1F1F2A');
    bg.addColorStop(1, '#2C2F3A');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Card container
    const cardX = padding;
    const cardY = padding;
    const cardW = width - padding * 2;
    const cardH = height - padding * 2;
    drawRoundedRect(cardX, cardY, cardW, cardH, 18);
    // Card gradient
    const cardGrad = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
    cardGrad.addColorStop(0, '#2A2E37');
    cardGrad.addColorStop(1, '#22252C');
    ctx.fillStyle = cardGrad;
    ctx.fill();

    // Decorative light
    const deco = ctx.createRadialGradient(cardX + 160, cardY + 110, 10, cardX + 160, cardY + 110, 260);
    deco.addColorStop(0, 'rgba(0, 255, 176, 0.18)');
    deco.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = deco;
    ctx.fillRect(cardX, cardY, cardW, cardH);

    // Avatar
    const avatar = await fetchUserAvatar(user);
    const avatarRadius = 64;
    const avatarCx = cardX + 32 + avatarRadius;
    const avatarCy = cardY + cardH / 2;
    ctx.save();
    ctx.beginPath();
    ctx.arc(avatarCx, avatarCy, avatarRadius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar, avatarCx - avatarRadius, avatarCy - avatarRadius, avatarRadius * 2, avatarRadius * 2);
    ctx.restore();
    // Avatar ring
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#00FFB0';
    ctx.beginPath();
    ctx.arc(avatarCx, avatarCy, avatarRadius + 4, 0, Math.PI * 2);
    ctx.stroke();

    // Text block
    const textX = avatarCx + avatarRadius + 28;
    const titleY = cardY + 70;
    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 34px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('SEVİYE ATLADIN!', textX, titleY);

    ctx.fillStyle = '#00FFB0';
    ctx.font = 'bold 22px Arial';
    ctx.fillText(activity === 'voice' ? 'Seste seviye atladın!' : 'Mesajda seviye atladın!', textX, titleY + 36);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 26px Arial';
    ctx.fillText(`Yeni Seviye: ${newLevel}`, textX, titleY + 36 + 34);

    // Badges top-right inside card
    const badges = getBadges(user);
    if (badges.length > 0) {
        const badgeSize = 30; // font size
        const gap = 10;
        let x = cardX + cardW - 16 - (badges.length * (badgeSize + gap));
        const y = cardY + 40;
        ctx.font = `${badgeSize}px Arial`;
        ctx.fillStyle = '#FFFFFF';
        for (const badge of badges) {
            ctx.fillText(badge, x, y);
            x += badgeSize + gap;
        }
    }

    // Date
    ctx.font = '18px Arial';
    ctx.fillStyle = '#9AA0A6';
    ctx.textAlign = 'right';
    ctx.fillText(new Date().toLocaleDateString('tr-TR'), cardX + cardW - 16, cardY + cardH - 16);
    ctx.textAlign = 'left';

    return new AttachmentBuilder(canvas.toBuffer(), { name: 'levelup-card.png' });
}

// Gelişmiş .level kartı
async function createLevelCard({ user, levelData }) {
    const width = 840;
    const height = 360;
    const padding = 28;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Helpers
    const drawRoundedRect = (x, y, w, h, r) => {
        const radius = Math.min(r, h / 2, w / 2);
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + w - radius, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
        ctx.lineTo(x + w, y + h - radius);
        ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
        ctx.lineTo(x + radius, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    };

    const drawProgressBar = (x, y, w, h, percent, bgColor, fgColor) => {
        // Track
        drawRoundedRect(x, y, w, h, h / 2);
        ctx.fillStyle = bgColor;
        ctx.fill();
        // Fill
        const fillW = Math.max(0, Math.min(w * percent, w));
        if (fillW > 0) {
            drawRoundedRect(x, y, fillW, h, h / 2);
            const grad = ctx.createLinearGradient(x, y, x + w, y);
            grad.addColorStop(0, fgColor);
            grad.addColorStop(1, '#E7C300');
            ctx.fillStyle = grad;
            ctx.fill();
        }
    };

    // Background
    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, '#1F1F2A');
    bg.addColorStop(1, '#2C2F3A');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Card container
    const cardX = padding;
    const cardY = padding;
    const cardW = width - padding * 2;
    const cardH = height - padding * 2;
    drawRoundedRect(cardX, cardY, cardW, cardH, 20);
    const cardGrad = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
    cardGrad.addColorStop(0, '#2A2E37');
    cardGrad.addColorStop(1, '#22252C');
    ctx.fillStyle = cardGrad;
    ctx.fill();

    // Decorative glow
    const glow = ctx.createRadialGradient(cardX + 200, cardY + 120, 10, cardX + 200, cardY + 120, 320);
    glow.addColorStop(0, 'rgba(0, 255, 176, 0.14)');
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(cardX, cardY, cardW, cardH);

    // Header
    ctx.font = 'bold 34px Arial';
    // Softer golden header color for better contrast
    ctx.fillStyle = '#EAC545';
    ctx.textAlign = 'left';
    ctx.fillText('SEVİYE PROFİLİ', cardX + 24, cardY + 48);

    // Avatar
    const avatar = await fetchUserAvatar(user);
    const avatarRadius = 78; // slightly larger for visual balance
    // Nudge avatar a bit right and move it down so it doesn't cover the header
    const avatarCx = cardX + 28 + avatarRadius;
    const avatarCy = cardY + 150;
    ctx.save();
    ctx.beginPath();
    ctx.arc(avatarCx, avatarCy, avatarRadius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar, avatarCx - avatarRadius, avatarCy - avatarRadius, avatarRadius * 2, avatarRadius * 2);
    ctx.restore();
    // Avatar ring
    ctx.lineWidth = 5;
    ctx.strokeStyle = '#1CF4A6'; // slightly softer neon green
    ctx.beginPath();
    ctx.arc(avatarCx, avatarCy, avatarRadius + 5, 0, Math.PI * 2);
    ctx.stroke();

    // Badges (top-right)
    const badges = getBadges(user);
    if (badges.length > 0) {
        const badgeSize = 30;
        const gap = 10;
        let x = cardX + cardW - 16 - (badges.length * (badgeSize + gap));
        const y = cardY + 44;
        ctx.font = `${badgeSize}px Arial`;
        ctx.fillStyle = '#FFFFFF';
        for (const badge of badges) {
            ctx.fillText(badge, x, y);
            x += badgeSize + gap;
        }
    }

    // Username
    ctx.font = 'bold 28px Arial';
    ctx.fillStyle = '#FFFFFF';
    const usernameX = avatarCx + avatarRadius + 28;
    const usernameY = avatarCy - 14; // keep above sections despite avatar shift
    ctx.fillText(user.user ? user.user.tag : user.displayName, usernameX, usernameY);

    // Sections
    const sectionTop = avatarCy + 26;
    const colGap = 36;
    const colWidth = (cardW - (usernameX - cardX) - colGap) / 2;
    const msgX = usernameX;
    const voiceX = usernameX + colWidth + colGap;

    // Message section title
    ctx.font = 'bold 22px Arial';
    // More readable teal for section headers
    ctx.fillStyle = '#22D3A6';
    ctx.fillText('Mesaj', msgX, sectionTop);
    // Voice section title
    ctx.fillText('Ses', voiceX, sectionTop);

    // Levels & XP
    const msgLevel = levelData.messageLevel || 1;
    const msgXP = levelData.messageXP || 0;
    const msgNextXP = Math.max(100, (levelData.messageLevel || 1) * 100);
    const msgPercent = Math.min(msgXP / msgNextXP, 1);

    const voiceLevel = levelData.voiceLevel || 1;
    const voiceXP = levelData.voiceXP || 0;
    const voiceNextXP = Math.max(100, (levelData.voiceLevel || 1) * 100);
    const voicePercent = Math.min(voiceXP / voiceNextXP, 1);

    // Message values
    ctx.font = 'bold 22px Arial';
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(`Lv. ${msgLevel}`, msgX, sectionTop + 34);
    ctx.font = '18px Arial';
    ctx.fillStyle = '#B9BBBE';
    ctx.fillText(`${msgXP} / ${msgNextXP} XP`, msgX, sectionTop + 60);

    // Voice values
    ctx.font = 'bold 22px Arial';
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(`Lv. ${voiceLevel}`, voiceX, sectionTop + 34);
    ctx.font = '18px Arial';
    ctx.fillStyle = '#B9BBBE';
    ctx.fillText(`${voiceXP} / ${voiceNextXP} XP`, voiceX, sectionTop + 60);

    // Progress bars
    const barH = 22;
    const barY = sectionTop + 70;
    const barBG = '#2F3238';
    const barFG = '#F2C94C';
    drawProgressBar(msgX, barY, colWidth, barH, msgPercent, barBG, barFG);
    drawProgressBar(voiceX, barY, colWidth, barH, voicePercent, barBG, barFG);

    // Percent labels (right aligned to each bar)
    ctx.font = '18px Arial';
    ctx.fillStyle = '#00FFB0';
    ctx.textAlign = 'right';
    ctx.fillText(`%${(msgPercent * 100).toFixed(1)}`, msgX + colWidth - 6, barY + barH - 4);
    ctx.fillText(`%${(voicePercent * 100).toFixed(1)}`, voiceX + colWidth - 6, barY + barH - 4);
    ctx.textAlign = 'left';

    // Date
    ctx.font = '18px Arial';
    ctx.fillStyle = '#9AA0A6';
    ctx.textAlign = 'right';
    ctx.fillText(new Date().toLocaleDateString('tr-TR'), cardX + cardW - 16, cardY + cardH - 16);
    ctx.textAlign = 'left';

    return new AttachmentBuilder(canvas.toBuffer(), { name: 'level-profile.png' });
}

module.exports = {
    addXP,
    createLevelUpCard,
    createLevelCard
}; 